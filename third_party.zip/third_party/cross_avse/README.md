# Cross-AVSE expert source

This folder contains selected Cross-AVSE source copied from the uploaded archive. Checkpoint files, event logs, and duplicate copies are excluded. The adapter expects this `model.py`/`dataset.py` source plus the locally selected Lightning checkpoint at `weights/AVSE.ckpt`.

The saved AVSE pipeline uses 16-kHz audio, up to 75 grayscale frames at 25 fps, and a 3-second audio context. Keep its frame preprocessing and output scaling consistent with the validation run.
