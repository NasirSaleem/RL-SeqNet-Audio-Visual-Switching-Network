from __future__ import annotations

import numpy as np


def fixed_router(n_steps: int, action: int):
    return np.full(n_steps, int(action), dtype=np.int64)


def snr_threshold_router(snr_db, threshold_db: float):
    """Reviewer-requested simple heuristic: AVSE below threshold, AOSE otherwise."""
    snr = np.asarray(snr_db, dtype=np.float32)
    return np.where(snr < threshold_db, 1, 0).astype(np.int64)


def sequence_utility_oracle(utilities, action_costs, lambda_compute=0.0,
                            lambda_switch=0.0, initial_action=2):
    """Dynamic-programming labels; training upper-bound/supervision only."""
    u = np.asarray(utilities, dtype=np.float64)
    costs = np.asarray(action_costs, dtype=np.float64)
    if u.ndim != 2 or u.shape[1] != 3 or costs.shape != (3,):
        raise ValueError("Expected utilities [T,3] and costs [3]")
    tmax = u.shape[0]
    score = np.full((tmax, 3), -np.inf)
    back = np.zeros((tmax, 3), dtype=np.int64)
    for action in range(3):
        score[0, action] = u[0, action] - lambda_compute * costs[action]
        if action != initial_action:
            score[0, action] -= lambda_switch
    for t in range(1, tmax):
        for action in range(3):
            previous_scores = score[t - 1] - lambda_switch * (np.arange(3) != action)
            previous = int(np.argmax(previous_scores))
            back[t, action] = previous
            score[t, action] = previous_scores[previous] + u[t, action] - lambda_compute * costs[action]
    actions = np.zeros(tmax, dtype=np.int64)
    actions[-1] = int(np.argmax(score[-1]))
    for t in range(tmax - 1, 0, -1):
        actions[t - 1] = back[t, actions[t]]
    return actions


def soft_mix(waveforms, weights):
    """Blend candidate waveforms for a soft-gating baseline."""
    w = np.asarray(weights, dtype=np.float64)
    if w.shape != (3,) or np.any(w < 0) or not np.isclose(w.sum(), 1.0):
        raise ValueError("weights must be three non-negative values summing to one")
    signals = [np.asarray(waveforms[k], dtype=np.float64).reshape(-1)
               for k in ("AOSE", "AVSE", "NSE")]
    n = min(map(len, signals))
    return sum(w[i] * signals[i][:n] for i in range(3)).astype(np.float32)
