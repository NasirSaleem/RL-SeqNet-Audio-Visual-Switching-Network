from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from decord import VideoReader, cpu


def convert_video(path, frames=75, height=224, width=224):
    reader = VideoReader(str(path), ctx=cpu(0))
    take = min(len(reader), frames)
    images = reader.get_batch(list(range(take))).asnumpy()
    gray = []
    for frame in images:
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        frame = cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)
        gray.append(frame.astype(np.float32) / 255.0)
    if not gray:
        raise ValueError(f"Video contains no frames: {path}")
    while len(gray) < frames:
        gray.append(np.zeros((height, width), dtype=np.float32))
    return np.stack(gray, axis=0)[None, ...]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("video")
    p.add_argument("output_npy")
    p.add_argument("--frames", type=int, default=75)
    p.add_argument("--height", type=int, default=224)
    p.add_argument("--width", type=int, default=224)
    args = p.parse_args()
    out = Path(args.output_npy)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.save(out, convert_video(args.video, args.frames, args.height, args.width))
    print(f"saved {out}")


if __name__ == "__main__":
    main()
