"""Audit and prepare a separate subset with the existing expert preprocessing.
Does not modify existing splits or train models. Requires 25-fps video because
the original preparation takes the first 75 frames for a 3-second context.
Timing checks are metadata checks, not verification of lip/audio synchronization.
"""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import soundfile as sf
from decord import VideoReader, cpu
from create_decision_manifests import read_audio, convert_video, FIELDS, SR


def write_csv(path, rows, fields):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', default='Dev_Subset')
    p.add_argument('--allow-duration-mismatch', action='store_true',
                   help='Record duration differences as warnings, without claiming or correcting synchronization')
    p.add_argument('--out-dir', default='data/heldout_prepared')
    p.add_argument('--manifest-root', default='data/rl_msnet_prepared/manifests')
    args = p.parse_args()
    source = Path(args.source).resolve(); out = Path(args.out_dir).resolve()
    if not source.is_dir(): raise FileNotFoundError(source)
    if out.exists() and any(out.iterdir()):
        p.error('Use an empty output folder; existing results will not be overwritten')
    used = set()
    for split in ('train', 'validation', 'test'):
        path = Path(args.manifest_root)/(split+'.csv')
        with path.open(newline='', encoding='utf-8-sig') as f:
            used.update(r['episode_id'] for r in csv.DictReader(f))
    jobs, audit, seen = [], [], set()
    for mixed in sorted(source.rglob('*_mixed.wav')):
        episode = mixed.name.removesuffix('_mixed.wav')
        if episode in seen: raise ValueError(f'Duplicate scene ID: {episode}')
        seen.add(episode)
        if episode in used: raise ValueError(f'Scene overlaps an existing split: {episode}')
        target = mixed.with_name(episode+'_target.wav')
        video = mixed.with_name(episode+'_silent.mp4')
        row = dict(episode_id=episode, noisy_wav=str(mixed), clean_wav=str(target), video=str(video),
                   noisy_sr='', clean_sr='', noisy_channels='', clean_channels='',
                   noisy_seconds='', clean_seconds='', video_frames='', video_fps='',
                   video_seconds='', audio_padding_seconds='', video_padding_frames='',
                   status='ok', reason='')
        try:
            for file in (target, video):
                if not file.is_file(): raise ValueError('Missing '+file.name)
            ni, ci = sf.info(mixed), sf.info(target)
            vr = VideoReader(str(video), ctx=cpu(0))
            frames, fps = len(vr), float(vr.get_avg_fps())
            nd, cd = ni.frames/ni.samplerate, ci.frames/ci.samplerate
            row.update(noisy_sr=ni.samplerate, clean_sr=ci.samplerate,
                       noisy_channels=ni.channels, clean_channels=ci.channels,
                       noisy_seconds=nd, clean_seconds=cd, video_frames=frames,
                       video_fps=fps, video_seconds=frames/fps if fps>0 else '',
                       audio_padding_seconds=max(0,3-nd), video_padding_frames=max(0,75-frames))
            if min(ni.frames, ci.frames, frames)<=0: raise ValueError('Empty media')
            if not np.isfinite(fps) or abs(fps-25)>.05:
                raise ValueError('Video must be 25 fps to match the original first-75-frame preparation')
            if abs(nd-cd)>1/max(ni.samplerate,ci.samplerate)+1e-6:
                raise ValueError('Noisy and target audio durations differ')
            if abs(nd-frames/fps)>.08+1e-6:
                if not args.allow_duration_mismatch:
                    raise ValueError('Audio/video duration difference exceeds 80 ms; investigate alignment')
                row.update(status='warning', reason='Duration mismatch retained; synchronization unverified; no temporal shift applied')
            del vr
            jobs.append((episode,mixed,target,video))
        except Exception as exc:
            row.update(status='error', reason=str(exc))
        audit.append(row)
    if not audit: raise ValueError('No *_mixed.wav files found')
    out.mkdir(parents=True)
    write_csv(out/'media_audit.csv',audit,list(audit[0]))
    if any(r['status']=='error' for r in audit):
        raise RuntimeError(f'Media audit failed; no preparation performed. See {out / "media_audit.csv"}')
    audio_dir=out/'eval'/'audio'; video_dir=out/'eval'/'video'
    audio_dir.mkdir(parents=True); video_dir.mkdir(parents=True)
    rows=[]
    for index,(episode,mixed,target,video) in enumerate(jobs,1):
        noisy,clean,frames=read_audio(mixed),read_audio(target),convert_video(video)
        if noisy.shape!=(48000,) or clean.shape!=(48000,) or frames.shape!=(1,75,224,224):
            raise ValueError(f'{episode}: unexpected prepared shapes')
        if not all(np.isfinite(x).all() for x in (noisy,clean,frames)):
            raise ValueError(f'{episode}: nonfinite prepared data')
        npth=audio_dir/(episode+'_mixed_16k_3s.wav')
        cpth=audio_dir/(episode+'_target_16k_3s.wav')
        vpth=video_dir/(episode+'_silent_75x224.npy')
        sf.write(npth,noisy,SR,subtype='FLOAT'); sf.write(cpth,clean,SR,subtype='FLOAT')
        np.save(vpth,frames,allow_pickle=False)
        for step in range(3):
            r={k:'' for k in FIELDS}
            r.update(episode_id=episode,step=step,noisy_wav=str(npth),clean_wav=str(cpth),
                     video_npy=str(vpth),center_start_sample=step*16000,center_end_sample=(step+1)*16000)
            rows.append(r)
        if index%10==0 or index==len(jobs): print(f'Prepared {index}/{len(jobs)} clips',flush=True)
    manifests=out/'manifests'; manifests.mkdir()
    write_csv(manifests/'test.csv',rows,FIELDS)
    protocol=dict(source=str(source),clips=len(jobs),decision_rows=len(rows),
                  preprocessing='Existing create_decision_manifests read_audio/convert_video: first 3 seconds, 16 kHz mono, first 75 grayscale 224x224 frames; zero-pad short inputs; FLOAT WAV',
                  scope='Prepared 3-second contexts, not full source utterances',
                  overlap='No scene-ID overlap with the three supplied manifests; speaker/source recording and expert training provenance not automatically verified',
                  timing='25 fps checked; duration differences audited; content synchronization unverified; no temporal shift applied',
                  allow_duration_mismatch=args.allow_duration_mismatch,
                  warning_scenes=sum(r['status']=='warning' for r in audit),
                  state_features='Blank by design; compute with frozen input-feature and confidence pipeline before routing')
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    print(f'Wrote {len(rows)} rows: {manifests / "test.csv"}')
    print('Preparation only. No model training or performance evaluation performed.')


if __name__=='__main__': main()
