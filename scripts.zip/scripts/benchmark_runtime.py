from __future__ import annotations

import argparse
import csv
import time
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from rl_msnet.experts.adapters import AOSEExpert, load_avse_checkpoint, run_avse


def main():
    p = argparse.ArgumentParser(description="Measure AOSE/AVSE latency on the final 3-second context")
    p.add_argument("--aose", required=True, help="AOSE Lightning .ckpt or TorchScript .pt")
    p.add_argument("--aose-source", default="third_party/aose",
                   help="Archived AOSE source directory; required for .ckpt")
    p.add_argument("--avse-checkpoint", required=True)
    p.add_argument("--avse-source", required=True)
    p.add_argument("--audio", required=True, help="16 kHz mono, 3-second WAV")
    p.add_argument("--video-npy", required=True, help="Archived grayscale [1,75,H,W] frames")
    p.add_argument("--decision-seconds", type=float, default=1.0,
                   help="Duration of the central output segment per routed decision")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--warmup", type=int, default=10)
    p.add_argument("--repeats", type=int, default=100)
    p.add_argument("--out", default="expert_latency.csv")
    args = p.parse_args()
    if args.decision_seconds <= 0 or args.repeats < 1 or args.warmup < 0:
        p.error("Invalid timing settings")
    audio, sr = sf.read(args.audio, dtype="float32")
    if sr != 16000 or audio.ndim != 1 or len(audio) != 48000:
        p.error("Audio must be mono 16 kHz and exactly 3 seconds")
    frames = np.load(args.video_npy, allow_pickle=False).astype(np.float32)
    aose = AOSEExpert(args.aose, args.device, source_dir=args.aose_source)
    avse = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, args.device)
    functions = {"AOSE": lambda: aose(audio), "AVSE": lambda: run_avse(avse, audio, frames), "NSE": lambda: audio}
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        p.error("CUDA requested but unavailable")

    rows = []
    for name, fn in functions.items():
        for _ in range(args.warmup):
            fn()
        if args.device.startswith("cuda"):
            torch.cuda.synchronize()
        samples_ms = []
        for _ in range(args.repeats):
            if args.device.startswith("cuda"):
                torch.cuda.synchronize()
            start = time.perf_counter()
            fn()
            if args.device.startswith("cuda"):
                torch.cuda.synchronize()
            samples_ms.append((time.perf_counter() - start) * 1000.0)
        arr = np.asarray(samples_ms)
        mean_ms = float(arr.mean())
        rows.append({
            "action": name,
            "mean_latency_ms": mean_ms,
            "p95_latency_ms": float(np.percentile(arr, 95)),
            "median_latency_ms": float(np.median(arr)),
            "decision_segment_seconds": args.decision_seconds,
            "rtf_per_decision_segment": mean_ms / (1000.0 * args.decision_seconds),
            "context_seconds": 3.0,
            "warmup_runs": args.warmup,
            "timed_runs": args.repeats,
            "device": args.device,
        })
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote expert timing results to {out}; include controller, confidence, and preprocessing overhead separately.")


if __name__ == "__main__":
    main()
