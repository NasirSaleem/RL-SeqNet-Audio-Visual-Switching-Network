from __future__ import annotations

import numpy as np


def si_sdr(clean, estimate, eps=1e-8):
    clean = np.asarray(clean, dtype=np.float64).reshape(-1)
    estimate = np.asarray(estimate, dtype=np.float64).reshape(-1)
    n = min(clean.size, estimate.size)
    if n == 0:
        raise ValueError("Signals must be non-empty")
    clean, estimate = clean[:n], estimate[:n]
    clean = clean - clean.mean()
    estimate = estimate - estimate.mean()
    target = np.dot(estimate, clean) / (np.dot(clean, clean) + eps) * clean
    residual = estimate - target
    return float(10.0 * np.log10((np.dot(target, target) + eps) /
                                 (np.dot(residual, residual) + eps)))
