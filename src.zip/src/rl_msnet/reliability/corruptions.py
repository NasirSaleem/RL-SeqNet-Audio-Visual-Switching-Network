from __future__ import annotations

import numpy as np
from scipy.ndimage import gaussian_filter, rotate, shift, zoom


def corrupt_video(frames: np.ndarray, kind: str, severity: float, seed: int = 0) -> np.ndarray:
    """Corrupt grayscale [T,H,W] or [1,T,H,W] frames in [0,1].

    `pose` is an image-plane geometric misalignment proxy. It is not a
    substitute for real head-pose recordings; report that limitation.
    """
    if not 0 <= severity <= 1:
        raise ValueError("severity must be in [0,1]")
    rng = np.random.default_rng(seed)
    x = np.asarray(frames, dtype=np.float32).copy()
    channel_first = x.ndim == 4
    if channel_first:
        if x.shape[0] != 1:
            raise ValueError("Only grayscale clips [1,T,H,W] are supported")
        x = x[0]
    if x.ndim != 3:
        raise ValueError("Expected frames [T,H,W] or [1,T,H,W]")
    t, h, w = x.shape
    if kind == "occlusion":
        oh, ow = max(1, int(h * 0.05 + severity * h * 0.45)), max(1, int(w * 0.05 + severity * w * 0.45))
        y0, x0 = int(rng.integers(0, max(1, h - oh + 1))), int(rng.integers(0, max(1, w - ow + 1)))
        x[:, y0:y0 + oh, x0:x0 + ow] = 0.0
    elif kind == "blur":
        sigma = 0.15 + 2.0 * severity
        x = gaussian_filter(x, sigma=(0, sigma, sigma))
    elif kind == "low_light":
        gamma = 1.0 + 2.0 * severity
        gain = 1.0 - 0.8 * severity
        x = np.clip(x, 0, 1) ** gamma * gain
    elif kind == "frame_drop":
        drop_rate = 0.05 + 0.65 * severity
        dropped = rng.random(t) < drop_rate
        for i in np.flatnonzero(dropped):
            x[i] = x[max(i - 1, 0)] if i else 0.0
    elif kind == "pose":
        angle = float(rng.uniform(-1, 1) * (2 + 18 * severity))
        dy = float(rng.uniform(-1, 1) * severity * h * 0.18)
        dx = float(rng.uniform(-1, 1) * severity * w * 0.18)
        scale = 1.0 + float(rng.uniform(-1, 1) * severity * 0.2)
        for i in range(t):
            frame = zoom(x[i], scale, order=1)
            pad_y = max(0, (h - frame.shape[0]) // 2)
            pad_x = max(0, (w - frame.shape[1]) // 2)
            frame = np.pad(frame, ((pad_y, max(0, h - frame.shape[0] - pad_y)),
                                  (pad_x, max(0, w - frame.shape[1] - pad_x)), mode="constant")
            frame = frame[:h, :w]
            frame = rotate(frame, angle, reshape=False, order=1, mode="constant", cval=0.0)
            x[i] = shift(frame, (dy, dx), order=1, mode="constant", cval=0.0)
    else:
        raise ValueError(f"Unknown corruption kind: {kind}")
    x = np.clip(x, 0.0, 1.0).astype(np.float32)
    return x[None] if channel_first else x
