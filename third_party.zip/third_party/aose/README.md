# AOSE expert source

This folder contains the selected AOSE Python source and `config.yaml` copied from the uploaded AOSE archive. For Lightning checkpoint inference, put the `.ckpt` at `weights/AOSE.ckpt`; the loader reconstructs the archived Lightning module and uses its generator. A TorchScript `.pt` remains an optional alternative. The AOSE data loader normalizes noisy/clean signals by noisy-signal standard deviation; the adapter mirrors this preprocessing and restores the waveform scale.
