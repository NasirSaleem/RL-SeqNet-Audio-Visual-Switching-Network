from __future__ import annotations

import numpy as np

from rl_msnet.evaluation.metrics import si_sdr


def candidate_metric_gains(clean, noisy, enhanced_by_action, stoi_fn=None, sample_rate=16000):
    """Return per-action SI-SDR/STOI gains relative to the noisy segment.

    `enhanced_by_action` maps AOSE/AVSE/NSE to 1-D waveforms. Supply a callable
    `stoi_fn(clean, estimate, sample_rate)` for STOI. This helper intentionally
    does not silently substitute a proxy if STOI is unavailable.
    """
    if stoi_fn is None:
        raise ValueError("Provide the STOI implementation used in the experiment")
    base_s = si_sdr(clean, noisy)
    base_i = float(stoi_fn(clean, noisy, sample_rate))
    out = {}
    for name, estimate in enhanced_by_action.items():
        out[name] = {
            "sisdr_gain": si_sdr(clean, estimate) - base_s,
            "stoi_gain": float(stoi_fn(clean, estimate, sample_rate)) - base_i,
        }
    return out
