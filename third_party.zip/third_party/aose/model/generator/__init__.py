from .generator import LiSenNet
