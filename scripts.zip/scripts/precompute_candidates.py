from __future__ import annotations

import argparse
import csv
import warnings
from collections import Counter
from pathlib import Path

import numpy as np
import soundfile as sf
from pystoi import stoi
from pesq import pesq, PesqError

from rl_msnet.experts.adapters import AOSEExpert, load_avse_checkpoint, run_avse


SR = 16000
REQUIRED = {
    "episode_id", "step", "noisy_wav", "clean_wav", "video_npy",
    "center_start_sample", "center_end_sample", "snr_est_db", "snr_delta_db",
}


def read_mono(path: str) -> np.ndarray:
    audio, sr = sf.read(path, dtype="float32", always_2d=False)
    if sr != SR:
        raise ValueError(f"{path} has sample rate {sr}; expected {SR}")
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if audio.ndim != 1:
        raise ValueError(f"{path} is not mono audio")
    return audio.astype(np.float32)


def si_sdr(clean: np.ndarray, estimate: np.ndarray) -> float:
    eps = 1e-8
    clean = np.asarray(clean, dtype=np.float64)
    estimate = np.asarray(estimate, dtype=np.float64)
    if clean.shape != estimate.shape or clean.ndim != 1 or not clean.size:
        raise ValueError("SI-SDR requires equal, nonempty 1-D arrays")
    clean = clean - clean.mean()
    estimate = estimate - estimate.mean()
    target = (np.dot(estimate, clean) / (np.dot(clean, clean) + eps)) * clean
    noise = estimate - target
    return float(10.0 * np.log10((np.dot(target, target) + eps) / (np.dot(noise, noise) + eps)))


def crop_segment(signal: np.ndarray, start: int, end: int) -> np.ndarray:
    if not 0 <= start < end <= len(signal):
        raise ValueError(f"Invalid central crop [{start}:{end}] for signal length {len(signal)}")
    return signal[start:end]


FEATURES = ["snr_est_db", "snr_delta_db", "visual_confidence",
            "visual_uncertainty", "visual_confidence_delta"]
METRICS = ("sisdr", "stoi", "pesq")
ACTIONS = ("aose", "avse", "nse")


def score_pair(clean, estimate, min_reference_rms):
    """Return (value, valid, reason) per metric; invalid values stay blank.

    RMS screening is an explicit numerical eligibility rule, not a VAD.
    STOI/PESQ can still reject segments which pass it. No scores are clipped.
    """
    def failed(reason):
        return {m: ("", 0, reason) for m in METRICS}
    if clean.shape != estimate.shape or clean.ndim != 1 or clean.size == 0:
        return failed("invalid_shape")
    if not np.isfinite(clean).all() or not np.isfinite(estimate).all():
        return failed("nonfinite_audio")
    centered = clean.astype(np.float64) - np.mean(clean, dtype=np.float64)
    if np.sqrt(np.mean(centered ** 2)) <= min_reference_rms:
        return failed("silent_or_constant_reference")
    if np.max(np.abs(estimate)) == 0:
        return failed("zero_estimate")
    results = {}
    for metric in METRICS:
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                if metric == "sisdr":
                    value = si_sdr(clean, estimate)
                elif metric == "stoi":
                    value = float(stoi(clean, estimate, SR, extended=False))
                else:
                    value = float(pesq(SR, clean, estimate, "wb"))
            reasons = [str(w.message) for w in caught]
            if reasons:
                results[metric] = ("", 0, "warning: " + " | ".join(reasons))
            elif not np.isfinite(value):
                results[metric] = ("", 0, "nonfinite_score")
            else:
                results[metric] = (value, 1, "")
        except (PesqError, ValueError, RuntimeError, FloatingPointError) as exc:
            results[metric] = ("", 0, type(exc).__name__ + ": " + str(exc))
    return results


def waveform_stats(signal):
    x = np.asarray(signal, dtype=np.float64)
    return float(np.sqrt(np.mean(x*x))), float(np.max(np.abs(x)))


def main():
    p = argparse.ArgumentParser(description="Precompute frozen-expert quality utilities for RL episodes")
    p.add_argument("--manifest", required=True, help="CSV with one fixed-context decision segment per row")
    p.add_argument("--aose", required=True, help="AOSE Lightning .ckpt or TorchScript .pt")
    p.add_argument("--aose-source", default="third_party/aose",
                   help="Archived AOSE source directory; required for .ckpt")
    p.add_argument("--avse-checkpoint", required=True, help="AVSE Lightning checkpoint")
    p.add_argument("--avse-source", required=True, help="Extracted Cross-AVSE source directory")
    p.add_argument("--out", required=True, help="Output transition CSV for prepare_npz.py")
    p.add_argument("--device", default="cuda")
    p.add_argument("--no-aose-normalization", action="store_true",
                   help="Disable the AOSE training-pipeline standard-deviation normalization")
    p.add_argument("--min-reference-rms", type=float, default=1e-6,
                   help="Minimum DC-removed reference RMS for metrics (default: 1e-6)")
    p.add_argument("--diagnostic-audio-dir", help="Save flagged central segments as float WAVs")
    args = p.parse_args()
    if args.min_reference_rms < 0 or not np.isfinite(args.min_reference_rms):
        p.error("--min-reference-rms must be finite and nonnegative")

    aose = AOSEExpert(args.aose, args.device, normalize=not args.no_aose_normalization,
                      source_dir=args.aose_source)
    avse = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, args.device)
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)

    counts = Counter()
    with open(args.manifest, newline="", encoding="utf-8-sig") as src:
        reader = csv.DictReader(src)
        missing = REQUIRED - set(reader.fieldnames or [])
        if missing:
            p.error(f"Manifest is missing columns: {sorted(missing)}")
        fieldnames = [
            "episode_id", "step", "snr_est_db", "snr_delta_db", "visual_confidence",
            "visual_uncertainty", "visual_confidence_delta",
            "sisdr_gain_aose", "stoi_gain_aose", "sisdr_gain_avse", "stoi_gain_avse",
            "sisdr_gain_nse", "stoi_gain_nse",
        ]
        fieldnames += ["metric_scope", "center_start_sample", "center_end_sample",
                       "min_reference_rms", "clean_rms", "clean_peak",
                       "missing_state_features", "state_features_valid", "all_metrics_valid",
                       "diagnostic_flags", "diagnostic_audio_prefix"]
        for name in ACTIONS:
            fieldnames += [f"rms_{name}", f"peak_{name}"]
            for metric in METRICS:
                fieldnames += [f"{metric}_{name}", f"{metric}_valid_{name}",
                               f"{metric}_reason_{name}", f"{metric}_gain_valid_{name}"]
                if metric == "pesq":
                    fieldnames.append(f"pesq_gain_{name}")
        # Atomic publication: a failed run leaves a .partial file, not a final CSV.
        partial = output.with_suffix(output.suffix + ".partial")
        with partial.open("w", newline="", encoding="utf-8") as dst:
            writer = csv.DictWriter(dst, fieldnames=fieldnames)
            writer.writeheader()
            for index, row in enumerate(reader, 1):
                noisy = read_mono(row["noisy_wav"])
                clean = read_mono(row["clean_wav"])
                if noisy.shape != clean.shape:
                    raise ValueError(f"Noisy/clean lengths differ for episode {row['episode_id']}")
                if len(noisy) != 3 * SR:
                    raise ValueError("Each AVSE context must contain exactly 3 seconds (48,000 samples)")
                start = int(row["center_start_sample"])
                end = int(row["center_end_sample"])
                if end - start < SR:
                    raise ValueError("Use at least a 1-second output segment for stable segment-level STOI")
                noisy_center = crop_segment(noisy, start, end)
                clean_center = crop_segment(clean, start, end)

                frames = np.load(row["video_npy"], allow_pickle=False).astype(np.float32)
                frame_size = 96 if bool(avse.hparams.get("lips", False)) else 224
                if frames.shape != (1, 75, frame_size, frame_size):
                    raise ValueError(
                        f"Expected archived grayscale frames [1,75,{frame_size},{frame_size}], got {frames.shape}"
                    )
                out_a = aose(noisy)
                out_v = run_avse(avse, noisy, frames)
                candidates = {
                    "aose": crop_segment(out_a, start, end),
                    "avse": crop_segment(out_v, start, end),
                    "nse": noisy_center,
                }
                scores = {name: score_pair(clean_center, estimate, args.min_reference_rms)
                          for name, estimate in candidates.items()}
                result = {key: row.get(key, "") for key in ["episode_id", "step"] + FEATURES}
                missing_features = []
                for key in FEATURES:
                    try:
                        if not np.isfinite(float(row.get(key, ""))):
                            missing_features.append(key)
                    except (ValueError, TypeError):
                        missing_features.append(key)
                result.update(metric_scope="central_segment",
                              center_start_sample=start, center_end_sample=end,
                              min_reference_rms=args.min_reference_rms,
                              missing_state_features=";".join(missing_features),
                              state_features_valid=int(not missing_features))
                result["clean_rms"], result["clean_peak"] = waveform_stats(clean_center)
                flags = []
                all_valid = True
                for name, estimate in candidates.items():
                    result[f"rms_{name}"], result[f"peak_{name}"] = waveform_stats(estimate)
                    for metric in METRICS:
                        value, valid, reason = scores[name][metric]
                        baseline, baseline_valid, _ = scores["nse"][metric]
                        gain_valid = bool(valid and baseline_valid)
                        gain = value - baseline if gain_valid else ""
                        result.update({f"{metric}_{name}": value,
                                       f"{metric}_valid_{name}": valid,
                                       f"{metric}_reason_{name}": reason,
                                       f"{metric}_gain_{name}": gain,
                                       f"{metric}_gain_valid_{name}": int(gain_valid)})
                        if not gain_valid:
                            all_valid = False
                            counts[f"invalid_{metric}_gain_{name}"] += 1
                            flags.append(f"invalid_{metric}_{name}")
                        elif metric == "sisdr" and abs(gain) > 20:
                            # Diagnostic trigger only: do not delete/clip difficult cases.
                            flags.append(f"large_sisdr_gain_{name}")
                result["all_metrics_valid"] = int(all_valid)
                result["diagnostic_flags"] = ";".join(flags)
                result["diagnostic_audio_prefix"] = ""
                if flags and args.diagnostic_audio_dir:
                    diagnostic_dir = Path(args.diagnostic_audio_dir)
                    diagnostic_dir.mkdir(parents=True, exist_ok=True)
                    prefix = diagnostic_dir / f"row_{index:06d}"
                    result["diagnostic_audio_prefix"] = str(prefix.resolve())
                    for name, signal in {"clean": clean_center, **candidates}.items():
                        sf.write(str(prefix) + f"_{name}.wav", signal, SR, subtype="FLOAT")
                writer.writerow(result)
                counts["rows"] += 1
                counts["flagged_rows"] += bool(flags)
                counts["rows_missing_features"] += bool(missing_features)
                if index % 25 == 0:
                    dst.flush()
                    print(f"Processed {index} segments; flagged {counts['flagged_rows']}", flush=True)
        partial.replace(output)
    print("Summary:", dict(counts))
    if counts["rows_missing_features"]:
        print("NOT READY FOR ROUTER TRAINING: missing/nonfinite state features remain.")
    if any(counts[k] for k in counts if k.startswith("invalid_")):
        print("Invalid metric gains are blank: downstream reward code must use validity masks.")
    print("Scores are central-segment diagnostics, not full-utterance evaluation.")
    print(f"Wrote candidate utilities to {output}")


if __name__ == "__main__":
    main()
