from __future__ import annotations

import numpy as np


class SegmentRoutingEnv:
    """Small cached-expert environment for a sequential routing episode."""

    def __init__(self, states, utilities, action_costs, lambda_compute=0.0,
                 lambda_switch=0.0, initial_action=2):
        self.states = np.asarray(states, dtype=np.float32)
        self.utilities = np.asarray(utilities, dtype=np.float32)
        self.costs = np.asarray(action_costs, dtype=np.float32)
        if self.states.ndim != 2 or self.utilities.shape != (len(self.states), 3):
            raise ValueError("Expected states [T,D] and utilities [T,3]")
        if self.costs.shape != (3,):
            raise ValueError("action_costs must be [AOSE, AVSE, NSE]")
        self.lambda_compute = float(lambda_compute)
        self.lambda_switch = float(lambda_switch)
        self.initial_action = int(initial_action)
        self.reset()

    def reset(self):
        self.step_index = 0
        self.previous_action = self.initial_action
        return self.states[0].copy()

    def step(self, action: int):
        if self.step_index >= len(self.states):
            raise RuntimeError("Episode is finished; call reset()")
        action = int(action)
        if action not in (0, 1, 2):
            raise ValueError("Action must be 0=AOSE, 1=AVSE, or 2=NSE")
        q = float(self.utilities[self.step_index, action])
        cost = float(self.costs[action])
        switching = float(self.step_index > 0 and action != self.previous_action)
        reward = q - self.lambda_compute * cost - self.lambda_switch * switching
        self.previous_action = action
        self.step_index += 1
        done = self.step_index >= len(self.states)
        observation = None if done else self.states[self.step_index].copy()
        return observation, reward, done, {"quality_utility": q, "compute_cost": cost,
                                           "switching": switching}
