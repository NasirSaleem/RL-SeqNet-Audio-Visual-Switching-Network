from pathlib import Path
import re,csv,json,shutil,hashlib,statistics as st,zipfile
P=Path(__file__).resolve().parents[1];R=P.parent
# Preserve sources used by the earlier verified tables; detect any later changes.
prov=json.loads((R/'table_draft/provenance.json').read_text())
for f,h in prov.items():
 p=R/'upload'/f
 assert p.is_file(),f
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h,f
 shutil.copy2(p,P/'sources'/f)
for src in ['publication_figures','aose_figures','ppo_figures']:
 d=R/src
 for p in d.iterdir():
  if p.suffix in ['.pdf','.png','.svg']:shutil.copy2(p,P/'figures'/p.name)
 shutil.copytree(d,P/'reproduce'/src,dirs_exist_ok=True)
old=(R/'table_draft/verified_tables.tex').read_text();tables={}
for block in re.findall(r'\\begin\{table\*\}.*?\\end\{table\*\}',old,re.S):
 label=re.search(r'\\label\{([^}]+)\}',block)[1];tables[label]=block
# Only reuse populated results, never the computational placeholder.
tables.pop('tab:compute')
for k,b in list(tables.items()):
 b=b.replace('candidate held-out','held-out').replace('Held-out candidate','Held-out').replace('Held-out candidate:','Held-out:')
 b=b.replace('The trained clip-router summary must be added from its separate result export.','The independently trained clip router is compared on the final held-out set in Table~\\ref{tab:heldout1}.')
 if k=='tab:waveform':b=b.replace('Reconstructed-clip validation quality across ten corruption conditions.','Reconstructed-context validation quality for methods available in the validation waveform export, across ten corruption conditions.')
 tables[k]=b
held=(R/'final_results/Heldout_Tables.tex').read_text()
for block in re.findall(r'\\begin\{table\*\}.*?\\end\{table\*\}',held,re.S):
 k=re.search(r'\\label\{([^}]+)\}',block)[1]
 if k in ['tab:heldout3','tab:heldout4','tab:heldout5']:
  block=block.replace(' Learned scores are mean $\\pm$ sample SD across three seeds where shown.','')
 # Prevent enlargement of narrow tables; use natural-width centered typesetting.
 block=block.replace(r'\resizebox{\textwidth}{!}{\begin{tabular}',r'\begin{tabular}').replace(r'\end{tabular}}',r'\end{tabular}')
 if k=='tab:heldout4':block=block.replace(r'\centering\small',r'\centering\scriptsize\setlength{\tabcolsep}{3pt}')
 if k=='tab:heldout1':block=block.replace(r'\end{table*}',r'\par\smallskip\begin{minipage}{\textwidth}\footnotesize Learned methods use crossfade reconstruction; the one-decision router has no action changes. Entries are across-seed means and sample SDs, not confidence intervals. Scores refer to duration-trimmed prepared contexts.\end{minipage}'+'\n'+r'\end{table*}')
 tables[k]=block
# Additional descriptive hard/crossfade table from final source, no invented CIs.
rows=list(csv.DictReader((P/'sources/waveform_summary(1).csv').open()))
b=r'''\begin{table*}[t]
\centering\small
\caption{Held-out hard versus crossfade reconstruction. Mean scores across seeds 11, 22 and 33. Differences are descriptive; no paired reconstruction confidence interval is available in the aggregate summaries.}
\label{tab:heldout_crossfade}
\begin{tabular}{llrrr}
\toprule
Router & Reconstruction & PESQ & STOI & SI-SDR (dB) \\
\midrule
'''
for model in ['ppo','utility_router','supervised','clip_router']:
 for mode in ['hard','crossfade']:
  v=[st.mean(float(x['mean_score']) for x in rows if x['model']==model and x['reconstruction']==mode and x['condition']=='all' and x['metric']==met) for met in ['pesq','stoi','sisdr']]
  b+=model.replace('_',r'\_')+' & '+mode+' & '+' & '.join(f'{x:.5f}' for x in v)+r' \\'+'\n'
b+='\\bottomrule\n\\end{tabular}\n\\end{table*}\n';tables['tab:heldout_crossfade']=b
for k,b in tables.items():(P/'tables'/(k.replace('tab:','')+'.tex')).write_text(b+'\n')
# Numerical condition routing table supplemental, derived directly from final proportions.
rr=list(csv.DictReader((P/'sources/routing_proportions.csv').open()))
b=r'''\begin{table*}[t]
\centering\scriptsize
\caption{Held-out condition-specific action proportions for PPO and utility regression. Percentages are averaged over three seeds; each seed has 322 nonempty intervals per condition.}
\label{tab:heldout_condition_routing}
\begin{tabular}{llrrr}
\toprule
Condition & Router & AOSE (\%) & AVSE (\%) & NSE (\%) \\
\midrule
'''
for c in sorted(set(x['condition'] for x in rr)):
 for m in ['ppo','utility']:
  v=[100*st.mean(float(x[k]) for x in rr if x['condition']==c and x['model']==m) for k in ['p_aose','p_avse','p_nse']]
  b+=c.replace('_',r'\_')+' & '+m+' & '+' & '.join(f'{x:.3f}' for x in v)+r' \\'+'\n'
b+='\\bottomrule\n\\end{tabular}\n\\end{table*}\n';(P/'tables/heldout_condition_routing.tex').write_text(b)
(P/'sources/provenance.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (P/'sources').glob('*.csv')},indent=2))
print('Saved',len(tables)+1,'populated tables; copied all nine earlier figures and two new held-out figures.')
