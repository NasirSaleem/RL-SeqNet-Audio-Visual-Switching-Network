"""Train a fixed-epoch confidence MLP and clip-grouped out-of-fold predictions.

No expert inference. No PPO. All variants/segments of a clip stay in one fold.
External validation is used only for reporting, not fitting or epoch selection.
The fixed hyperparameters are pilot settings, not a validated optimum.
"""
from __future__ import annotations
import argparse
import csv
import json
import random
from pathlib import Path
import numpy as np
import torch
from torch import nn


class ConfidenceMLP(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(dim, 128), nn.ReLU(), nn.Dropout(0.2),
                                     nn.Linear(128, 64), nn.ReLU(), nn.Dropout(0.2), nn.Linear(64, 1))
    def forward(self, x):
        return self.network(x).squeeze(-1)


def load_data(path):
    with np.load(path, allow_pickle=False) as z:
        data = {k: z[k].copy() for k in z.files}
    required = ['features', 'target', 'episode_ids', 'steps', 'conditions', 'utilities',
                'action_order', 'target_definition', 'sisdr_scale_db', 'stoi_scale', 'feature_definition']
    if any(k not in data for k in required):
        raise ValueError(f'Missing dataset fields: {path}')
    x, y = data['features'], data['target']
    if x.ndim != 2 or y.shape != (len(x),) or not len(x):
        raise ValueError(f'Invalid array shapes: {path}')
    if not np.isfinite(x).all() or not np.isfinite(y).all() or not np.isin(y, [0, 1]).all():
        raise ValueError(f'Invalid features or binary targets: {path}')
    for k in ['episode_ids', 'steps', 'conditions']:
        if data[k].shape != y.shape:
            raise ValueError(f'Invalid {k} shape')
    keys = list(zip(data['episode_ids'].tolist(), data['steps'].tolist(), data['conditions'].tolist()))
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate episode/step/condition keys')
    if data['utilities'].shape != (len(x), 3) or not np.isfinite(data['utilities']).all():
        raise ValueError('Invalid utility array')
    if data['action_order'].tolist() != ['aose', 'avse', 'nse']:
        raise ValueError('Unexpected action order')
    if str(data['target_definition']) != 'avse_utility_gt_max_aose_nse_binary_v1':
        raise ValueError('Unexpected confidence target definition')
    q = data['utilities']
    # Targets were computed before float32 utility storage; near-tie rounding is allowed.
    margin = q[:, 1] - np.maximum(q[:, 0], q[:, 2])
    if np.any(((margin > 0) != y.astype(bool)) & (np.abs(margin) > 1e-5)):
        raise ValueError('Targets disagree with saved utilities')
    return data


def group_folds(episodes, folds, seed):
    groups = np.unique(episodes)
    if len(groups) < folds:
        raise ValueError('Fewer clips than folds')
    rng = np.random.default_rng(seed)
    groups = rng.permutation(groups)
    mapping = {str(group): i % folds for i, group in enumerate(groups)}
    return np.asarray([mapping[str(group)] for group in episodes], dtype=np.int64)


def normalization(x):
    mean = x.mean(axis=0, dtype=np.float64).astype(np.float32)
    std = x.std(axis=0, dtype=np.float64).astype(np.float32)
    # Constant/nearly constant training features remain centered, without amplification.
    std[std < 1e-6] = 1.0
    return mean, std


def fit(x, y, args, seed, label):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    mean, std = normalization(x)
    xt = torch.as_tensor((x-mean)/std, dtype=torch.float32, device=args.device)
    yt = torch.as_tensor(y, dtype=torch.float32, device=args.device)
    if len(np.unique(y)) != 2:
        raise ValueError(f'{label}: training requires both target classes')
    model = ConfidenceMLP(x.shape[1]).to(args.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-4)
    criterion = nn.BCEWithLogitsLoss()
    for epoch in range(1, args.epochs+1):
        model.train(); total = 0.0
        order = torch.randperm(len(xt), device=args.device)
        for start in range(0, len(xt), args.batch_size):
            index = order[start:start+args.batch_size]
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(xt[index]), yt[index])
            if not torch.isfinite(loss):
                raise ValueError(f'Nonfinite loss in {label}')
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            total += loss.item()*len(index)
        if epoch == 1 or epoch % 10 == 0 or epoch == args.epochs:
            print(f'{label} epoch={epoch}/{args.epochs} BCE={total/len(xt):.5f}', flush=True)
    return model, mean, std


def predict(model, x, mean, std, device):
    model.eval(); chunks = []
    with torch.inference_mode():
        for start in range(0, len(x), 512):
            t = torch.as_tensor((x[start:start+512]-mean)/std, dtype=torch.float32, device=device)
            chunks.append(torch.sigmoid(model(t)).cpu().numpy())
    return np.concatenate(chunks)


def scores(y, p):
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    safe = np.clip(p, 1e-7, 1-1e-7)
    pred = p >= 0.5
    recalls = [float(np.mean(pred[y == c] == c)) for c in [0, 1] if np.any(y == c)]
    # Ten fixed probability bins; calibration diagnostic, not a calibration fit.
    bins = np.minimum((p*10).astype(int), 9)
    ece = sum(np.mean(bins == b)*abs(np.mean(p[bins == b])-np.mean(y[bins == b]))
              for b in range(10) if np.any(bins == b))
    return dict(rows=len(y), positive_fraction=float(y.mean()), mean_probability=float(p.mean()),
                brier=float(np.mean((p-y)**2)), log_loss=float(-np.mean(y*np.log(safe)+(1-y)*np.log(1-safe))),
                accuracy=float(np.mean(pred == y)), balanced_accuracy=float(np.mean(recalls)), ece_10=float(ece))


def save_predictions(path, data, probabilities, baseline, fold_ids):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['episode_id', 'step', 'condition', 'fold', 'target', 'visual_confidence', 'baseline_probability'])
        for i in range(len(probabilities)):
            writer.writerow([data['episode_ids'][i], int(data['steps'][i]), data['conditions'][i],
                             int(fold_ids[i]), int(data['target'][i]), float(probabilities[i]), float(baseline[i])])


def save_model(path, model, mean, std, data, args, fit_groups):
    torch.save(dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},
                    mean=torch.from_numpy(mean), std=torch.from_numpy(std), input_dim=len(mean),
                    hidden_dims=[128,64], dropout=0.2, epochs=args.epochs,
                    target_definition=str(data['target_definition']),
                    feature_definition=str(data['feature_definition']),
                    sisdr_scale_db=float(data['sisdr_scale_db']), stoi_scale=float(data['stoi_scale']),
                    training_episode_ids=[str(v) for v in np.unique(fit_groups)],
                    probability_calibration='none'), path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train', required=True); p.add_argument('--validation', required=True)
    p.add_argument('--out-dir', required=True)
    p.add_argument('--folds', type=int, default=5); p.add_argument('--epochs', type=int, default=50)
    p.add_argument('--batch-size', type=int, default=256); p.add_argument('--lr', type=float, default=0.001)
    p.add_argument('--seed', type=int, default=11); p.add_argument('--device', default='cuda')
    args = p.parse_args()
    if args.folds < 2 or args.epochs < 1 or args.batch_size < 1 or args.lr <= 0:
        p.error('Invalid training settings')
    out = Path(args.out_dir)
    if out.exists() and any(out.iterdir()):
        p.error('Choose an empty output directory to preserve existing results')
    train, val = load_data(args.train), load_data(args.validation)
    if set(train['episode_ids']) & set(val['episode_ids']):
        raise ValueError('Training and validation episode IDs overlap')
    for key in ['target_definition', 'feature_definition', 'sisdr_scale_db', 'stoi_scale', 'action_order']:
        if not np.array_equal(train[key], val[key]):
            raise ValueError(f'Training/validation mismatch: {key}')
    if train['features'].shape[1] != val['features'].shape[1]:
        raise ValueError('Feature dimensions differ')
    if args.device.startswith('cuda') and not torch.cuda.is_available():
        raise ValueError('CUDA unavailable; activate your working environment or use --device cpu')
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    out.mkdir(parents=True, exist_ok=True)
    folds = group_folds(train['episode_ids'], args.folds, args.seed)
    oof = np.full(len(folds), np.nan, dtype=np.float32)
    prior = np.full(len(folds), np.nan, dtype=np.float32)
    print(f'Training: {len(folds)} rows, {len(np.unique(train["episode_ids"]))} clips; validation: {len(val["target"])} rows', flush=True)
    print('Clip-grouped folds; speaker/source-recording independence still requires provenance checks.', flush=True)
    for fold in range(args.folds):
        fit_indices, held_indices = folds != fold, folds == fold
        model, mean, std = fit(train['features'][fit_indices], train['target'][fit_indices], args, args.seed+fold, f'fold {fold+1}')
        oof[held_indices] = predict(model, train['features'][held_indices], mean, std, args.device)
        prior[held_indices] = train['target'][fit_indices].mean()
        save_model(out/f'confidence_fold_{fold+1}.ckpt', model, mean, std, train, args, train['episode_ids'][fit_indices])
        print(f'fold {fold+1} held-out Brier={scores(train["target"][held_indices], oof[held_indices])["brier"]:.5f}', flush=True)
    assert np.isfinite(oof).all()
    model, mean, std = fit(train['features'], train['target'], args, args.seed+args.folds, 'final model')
    vp = predict(model, val['features'], mean, std, args.device)
    vprior = np.full(len(vp), train['target'].mean(), dtype=np.float32)
    save_model(out/'visual_confidence.ckpt', model, mean, std, train, args, train['episode_ids'])
    save_predictions(out/'train_oof_predictions.csv', train, oof, prior, folds)
    save_predictions(out/'validation_predictions.csv', val, vp, vprior, np.full(len(vp), -1))
    report = []
    for split, data, prob, baseline in [('train_oof', train, oof, prior), ('validation', val, vp, vprior)]:
        for condition in ['all']+sorted(set(data['conditions'].tolist())):
            mask = np.ones(len(prob), dtype=bool) if condition == 'all' else data['conditions'] == condition
            for name, prediction in [('confidence_mlp', prob), ('training_prior', baseline)]:
                report.append(dict(split=split, condition=condition, model=name, **scores(data['target'][mask], prediction[mask])))
    with (out/'metrics.csv').open('w', newline='', encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(report[0]));writer.writeheader();writer.writerows(report)
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),
        architecture='D-128-64-1 ReLU dropout=0.2', loss='unweighted BCEWithLogitsLoss',
        normalization='mean/std fitted only on fitting partition', gradient_clip_norm=1.0, weight_decay=1e-4,
        epoch_selection='fixed before evaluation; held-out folds and external validation not used for fitting',
        grouping='episode_id across all steps and corruption conditions',
        scope='confidence training only; raw probabilities, no fitted calibration or PPO',
        limitation='OOF excludes confidence-label fitting, but experts were already fitted on training clips; not end-to-end cross-fitting'),indent=2),encoding='utf-8')
    for row in report:
        if row['condition']=='all':
            print(f'{row["split"]} {row["model"]}: Brier={row["brier"]:.5f}, log-loss={row["log_loss"]:.5f}, balanced accuracy={row["balanced_accuracy"]:.3f}')
    print(f'Saved confidence model, OOF predictions and metrics to {out}')
    print('Use train_oof_predictions.csv for eligible router-training rows, not predictions from the final model on its fitting data.')
    print('Filtered supervision is not a contiguous RL episode dataset. No calibrated-uncertainty or RL-performance claim yet.')


if __name__ == '__main__':
    main()
