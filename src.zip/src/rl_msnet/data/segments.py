from __future__ import annotations

import numpy as np


def centered_context(audio: np.ndarray, segment_start: int, context_samples: int = 48000,
                     output_samples: int = 16320):
    """Return a zero-padded context and crop offsets for one output segment."""
    x = np.asarray(audio, dtype=np.float32).reshape(-1)
    if output_samples > context_samples:
        raise ValueError("Output segment cannot exceed context duration")
    pad_context = (context_samples - output_samples) // 2
    context_start = int(segment_start) - pad_context
    context_end = context_start + context_samples
    src_start = max(0, context_start)
    src_end = min(len(x), context_end)
    left_pad = max(0, -context_start)
    right_pad = max(0, context_end - len(x))
    context = np.pad(x[src_start:src_end], (left_pad, right_pad))
    if context.size != context_samples:
        raise RuntimeError("Context padding produced an unexpected length")
    crop_start = pad_context
    return context, crop_start, crop_start + output_samples
