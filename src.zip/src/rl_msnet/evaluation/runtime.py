from __future__ import annotations

import numpy as np


def route_summary(actions):
    a = np.asarray(actions, dtype=np.int64).reshape(-1)
    if a.size == 0 or np.any((a < 0) | (a > 2)):
        raise ValueError("actions must be a non-empty vector of 0/1/2")
    return {
        "route_proportions": {"AOSE": float(np.mean(a == 0)),
                              "AVSE": float(np.mean(a == 1)),
                              "NSE": float(np.mean(a == 2))},
        "switches_per_decision": float(np.mean(a[1:] != a[:-1])) if a.size > 1 else 0.0,
    }
