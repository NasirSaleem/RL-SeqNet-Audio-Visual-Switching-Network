"""Evaluation metrics, baselines, statistics, and runtime summaries."""
