from __future__ import annotations

import argparse
import csv
from pathlib import Path


def read_map(path):
    with open(path, newline="", encoding="utf-8") as f:
        return {(r["episode_id"], r["step"]): r for r in csv.DictReader(f)}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--manifest", required=True)
    p.add_argument("--candidate-csv", required=True)
    p.add_argument("--confidence-csv", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args()
    metrics = read_map(args.candidate_csv)
    confidence = read_map(args.confidence_csv)
    with open(args.manifest, newline="", encoding="utf-8") as f:
        manifest = list(csv.DictReader(f))
    fields = ["episode_id", "step", "snr_est_db", "snr_delta_db", "visual_confidence",
              "visual_uncertainty", "visual_confidence_delta", "sisdr_gain_aose", "stoi_gain_aose",
              "sisdr_gain_avse", "stoi_gain_avse", "sisdr_gain_nse", "stoi_gain_nse"]
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in manifest:
            key = (row["episode_id"], row["step"])
            if key not in metrics or key not in confidence:
                raise ValueError(f"Missing candidate metrics or confidence for {key}")
            joined = {k: row[k] for k in ("episode_id", "step", "snr_est_db", "snr_delta_db")}
            joined.update({k: confidence[key][k] for k in
                           ("visual_confidence", "visual_uncertainty", "visual_confidence_delta")})
            joined.update({k: metrics[key][k] for k in fields if k.startswith("sisdr_gain_") or k.startswith("stoi_gain_")})
            writer.writerow(joined)
    print(f"Wrote complete RL transition table: {out}")


if __name__ == "__main__":
    main()
