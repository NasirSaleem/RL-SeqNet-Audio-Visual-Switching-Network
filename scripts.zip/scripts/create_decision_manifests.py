from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly
from decord import VideoReader, cpu
import cv2


SR = 16000
CONTEXT_SAMPLES = 3 * SR
STEP_SAMPLES = SR
SPLITS = {"train": "train", "dev": "validation", "eval": "test"}
FIELDS = [
    "episode_id", "step", "noisy_wav", "clean_wav", "video_npy",
    "center_start_sample", "center_end_sample", "snr_est_db", "snr_delta_db",
    "visual_confidence", "visual_uncertainty", "visual_confidence_delta",
]


def read_audio(path: Path) -> np.ndarray:
    audio, sr = sf.read(str(path), dtype="float32", always_2d=False)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if audio.ndim != 1:
        raise ValueError(f"Expected mono/stereo audio at {path}, got shape {audio.shape}")
    if sr != SR:
        # Rational polyphase conversion keeps the prepared context at the model's 16 kHz rate.
        from math import gcd
        divisor = gcd(SR, int(sr))
        audio = resample_poly(audio, SR // divisor, int(sr) // divisor).astype(np.float32)
    if len(audio) < CONTEXT_SAMPLES:
        audio = np.pad(audio, (0, CONTEXT_SAMPLES - len(audio)))
    else:
        audio = audio[:CONTEXT_SAMPLES]
    return audio.astype(np.float32)


def convert_video(path: Path) -> np.ndarray:
    reader = VideoReader(str(path), ctx=cpu(0))
    take = min(len(reader), 75)
    if take == 0:
        raise ValueError(f"Video contains no frames: {path}")
    frames = reader.get_batch(list(range(take))).asnumpy()
    gray = []
    for frame in frames:
        image = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
        image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)
        gray.append(image.astype(np.float32) / 255.0)
    while len(gray) < 75:
        gray.append(np.zeros((224, 224), dtype=np.float32))
    return np.stack(gray, axis=0)[None, ...].astype(np.float32)


def read_snr_metadata(path: Path | None) -> dict[tuple[str, str, int], float]:
    if path is None:
        return {}
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {"split", "episode_id", "step", "snr_est_db"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"SNR metadata is missing columns: {sorted(missing)}")
        return {
            (row["split"], row["episode_id"], int(row["step"])): float(row["snr_est_db"])
            for row in reader
        }


def write_split(data_root: Path, output_root: Path, split_dir: str, output_name: str,
                snr_values: dict[tuple[str, str, int], float]) -> int:
    scenes = data_root / split_dir / "scenes"
    if not scenes.is_dir():
        raise FileNotFoundError(f"Expected dataset split folder: {scenes}")
    split_output = output_root / split_dir
    audio_dir = split_output / "audio"
    video_dir = split_output / "video"
    audio_dir.mkdir(parents=True, exist_ok=True)
    video_dir.mkdir(parents=True, exist_ok=True)

    output_manifest = output_root / "manifests" / f"{output_name}.csv"
    output_manifest.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    skipped: list[dict[str, str]] = []
    with output_manifest.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for mixed in sorted(scenes.glob("*_mixed.wav")):
            episode_id = mixed.name.removesuffix("_mixed.wav")
            target = scenes / f"{episode_id}_target.wav"
            silent = scenes / f"{episode_id}_silent.mp4"
            missing = [p.name for p in (target, silent) if not p.is_file()]
            if missing:
                skipped.append({
                    "split": split_dir,
                    "episode_id": episode_id,
                    "mixed_wav": str(mixed.resolve()),
                    "missing_files": ";".join(missing),
                })
                print(f"Skipping {split_dir}/{episode_id}: missing {', '.join(missing)}")
                continue

            prepared_noisy = audio_dir / f"{episode_id}_mixed_16k_3s.wav"
            prepared_clean = audio_dir / f"{episode_id}_target_16k_3s.wav"
            prepared_video = video_dir / f"{episode_id}_silent_75x224.npy"
            sf.write(str(prepared_noisy), read_audio(mixed), SR, subtype="FLOAT")
            sf.write(str(prepared_clean), read_audio(target), SR, subtype="FLOAT")
            np.save(prepared_video, convert_video(silent), allow_pickle=False)

            previous_snr = None
            for step in range(3):
                snr = snr_values.get((split_dir, episode_id, step))
                delta = "" if snr is None or previous_snr is None else snr - previous_snr
                writer.writerow({
                    "episode_id": episode_id,
                    "step": step,
                    "noisy_wav": prepared_noisy.resolve(),
                    "clean_wav": prepared_clean.resolve(),
                    "video_npy": prepared_video.resolve(),
                    "center_start_sample": step * STEP_SAMPLES,
                    "center_end_sample": (step + 1) * STEP_SAMPLES,
                    "snr_est_db": "" if snr is None else snr,
                    "snr_delta_db": delta,
                    "visual_confidence": "",
                    "visual_uncertainty": "",
                    "visual_confidence_delta": "",
                })
                previous_snr = snr
                count += 1
    print(f"Wrote {count} decision rows: {output_manifest}")
    skipped_manifest = output_root / "manifests" / f"skipped_{output_name}.csv"
    with skipped_manifest.open("w", newline="", encoding="utf-8") as f:
        fields = ["split", "episode_id", "mixed_wav", "missing_files"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(skipped)
    print(f"Wrote incomplete-scene audit ({len(skipped)} scenes): {skipped_manifest}")
    if count == 0:
        raise RuntimeError(f"No complete paired scenes found in {scenes}; see {skipped_manifest}")
    return count


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Prepare RL-MSNet manifests from AVSE data/{train,dev,eval}/scenes"
    )
    parser.add_argument("--data-root", required=True,
                        help="Folder containing train/scenes, dev/scenes, and eval/scenes")
    parser.add_argument("--output-root", default="data/rl_msnet_prepared",
                        help="Where normalized 3-second audio, video NPYs, and manifests go")
    parser.add_argument("--snr-csv", help=(
        "Optional estimated-SNR table with columns split,episode_id,step,snr_est_db; "
        "split values must be train, dev, or eval. Without it, SNR fields stay blank."
    ))
    args = parser.parse_args()
    data_root = Path(args.data_root).expanduser().resolve()
    output_root = Path(args.output_root).expanduser().resolve()
    snr_values = read_snr_metadata(Path(args.snr_csv).expanduser().resolve() if args.snr_csv else None)
    total = 0
    for split_dir, output_name in SPLITS.items():
        total += write_split(data_root, output_root, split_dir, output_name, snr_values)
    if not snr_values:
        print("SNR columns are blank. Fill them with inference-time SNR estimates before precompute_candidates.py.")
    print(f"Prepared {total} decision rows across train/validation/test.")


if __name__ == "__main__":
    main()
