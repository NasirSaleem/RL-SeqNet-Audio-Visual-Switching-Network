from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'savefig.facecolor':'white'})
BLUE='#0072B2';TEAL='#009E73';ORANGE='#D55E00';GREY='#737B85'
def read(n):return list(csv.DictReader((ROOT/'data'/n).open()))
def save(fig,name):
 for ext in ('pdf','svg','png'):fig.savefig(ROOT/(name+'.'+ext),dpi=600,bbox_inches='tight',pad_inches=.10)
 plt.close(fig)
def panel(ax,label):ax.text(0,1.07,label,transform=ax.transAxes,fontweight='bold',fontsize=10)
# 1 score profiles: means + individual seeds, not inferred confidence bars
r=read('waveform_summary.csv');metrics=['pesq','stoi','sisdr']
methods=[('always_nse','fixed','Bypass'),('always_aose','fixed','AOSE'),('always_avse','fixed','AVSE'),('utility_router','hard','Utility / hard'),('utility_router','crossfade','Utility / fade'),('ppo','hard','PPO / hard'),('ppo','crossfade','PPO / fade')]
fig,axs=plt.subplots(1,3,figsize=(7.16,3.55),sharey=True,layout='constrained')
for j,(ax,m) in enumerate(zip(axs,metrics)):
 for i,(model,mode,name) in enumerate(methods):
  v=np.array([float(x['mean_score']) for x in r if x['model']==model and x['reconstruction']==mode and x['condition']=='all' and x['metric']==m])
  color=ORANGE if model=='ppo' else TEAL if model=='utility_router' else BLUE if model=='always_avse' else GREY
  ax.scatter(v,np.full(len(v),i)+np.linspace(-.10,.10,len(v)) if len(v)>1 else [i],s=22,facecolors='white',edgecolors=color,zorder=3)
  ax.scatter(v.mean(),i,s=35,marker='D',color=color,zorder=4)
 base=float(next(x['mean_score'] for x in r if x['model']=='always_avse' and x['metric']==m and x['condition']=='all'))
 ax.axvline(base,ls='--',color=BLUE,alpha=.5,lw=1)
 ax.grid(axis='x',alpha=.18);ax.set_xlabel({'pesq':'PESQ (higher is better)','stoi':'STOI (higher is better)','sisdr':'SI-SDR (dB)'}[m]);panel(ax,chr(97+j)+')')
axs[0].set_yticks(range(len(methods)),[x[2] for x in methods]);axs[0].invert_yaxis()
fig.suptitle('Validation waveform quality: metric trade-offs',fontsize=11,fontweight='bold')
save(fig,'Fig1_Waveform_Quality')
#2 AVSE changes relative to clean (each metric own scale, include signed values)
allr=read('summary.csv')+read('summary(2).csv')
conds=['occlusion','motion_blur','low_light','frame_drop','visual_dropout','clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean']
labels=['Occlusion','Motion blur','Low light','Frame dropping','Full visual dropout','Clean / dropout / clean','Dropout / clean / dropout','Clean / low light / clean','Clean / blur / clean']
a=np.empty((len(conds),3))
for j,m in enumerate(metrics):
 base=float(next(x['mean'] for x in allr if x['condition']=='clean' and x['action']=='avse' and x['metric']==m))
 for i,c in enumerate(conds):a[i,j]=float(next(x['mean'] for x in allr if x['condition']==c and x['action']=='avse' and x['metric']==m))-base
fig,axs=plt.subplots(1,3,figsize=(7.16,3.95),sharey=True,layout='constrained')
for j,(ax,m) in enumerate(zip(axs,metrics)):
 limit=max(abs(a[:,j]).max(),1e-9)
 ax.imshow(a[:,j,None],cmap='RdBu',vmin=-limit,vmax=limit,aspect='auto')
 for i,v in enumerate(a[:,j]):ax.text(0,i,f'{v:+.3f}',ha='center',va='center',color='white' if abs(v)>.55*limit else '#202020',fontsize=9)
 ax.set_xticks([]);ax.set_title(['Δ PESQ','Δ STOI','Δ SI-SDR (dB)'][j]);ax.set_yticks(range(len(conds)))
 ax.axhline(4.5,color='white',lw=2);ax.spines['left'].set_visible(False);ax.spines['bottom'].set_visible(False)
axs[0].set_yticklabels(labels)
fig.suptitle('AVSE response to visual corruption on validation',fontsize=11,fontweight='bold')
save(fig,'Fig2_Visual_Corruption_Response')
#3 stacked action distribution across conditions PPO & utility
r=read('validation_summary(5).csv');cs=['clean']+conds
lab=['Clean']+labels
fig,axs=plt.subplots(1,2,figsize=(7.16,4.7),sharey=True,layout='constrained')
for ax,model,title in zip(axs,['ppo','utility_regression_mlp'],['a) PPO','b) Utility-regression router']):
 vals=np.array([[np.mean([float(x[k]) for x in r if x['model']==model and x['condition']==c])*100 for k in ['p_aose','p_avse','p_nse']] for c in cs])
 left=np.zeros(len(cs))
 for j,(name,color) in enumerate(zip(['AOSE','AVSE','Bypass'],[TEAL,BLUE,'#B6BCC4'])):
  ax.barh(range(len(cs)),vals[:,j],left=left,height=.68,label=name,color=color,edgecolor='white',linewidth=.5)
  for i,v in enumerate(vals[:,j]):
   if v>=9:ax.text(left[i]+v/2,i,f'{v:.0f}',ha='center',va='center',color='white' if j<2 else '#202020',fontsize=8)
  left+=vals[:,j]
 ax.set_xlim(0,100);ax.set_xlabel('Selected segments (%)');ax.set_title(title,loc='left',fontweight='bold');ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
axs[0].set_yticks(range(len(cs)),lab);axs[0].invert_yaxis()
handles,labs=axs[0].get_legend_handles_labels();fig.legend(handles,labs,loc='outside lower center',ncol=3,frameon=False)
fig.suptitle('Learned routing behaviour across validation conditions',fontsize=11,fontweight='bold')
save(fig,'Fig3_Routing_Behaviour')
#4 forest switching compared with holding first, same policy, not trained clip baseline
r=read('single_decision_summary.csv')
fig,axs=plt.subplots(1,3,figsize=(7.16,2.6),sharey=True,layout='constrained')
for ax,m in zip(axs,metrics):
 for i,seed in enumerate(['11','22','33']):
  x=next(x for x in r if x['model']=='ppo' and x['seed']==seed and x['condition']=='all' and x['metric']==m and x['reconstruction']=='crossfade' and x['comparison']=='switching_minus_held_first')
  v,lo,hi=[float(x[k]) for k in ['paired_delta','ci_low','ci_high']]
  ax.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='o',color=ORANGE,capsize=3,lw=1.5,ms=5)
 ax.axvline(0,color=GREY,ls='--',lw=1);ax.grid(axis='x',alpha=.2);ax.set_xlabel({'pesq':'Δ PESQ','stoi':'Δ STOI','sisdr':'Δ SI-SDR (dB)'}[m]);ax.set_ylim(2.6,-.6)
axs[0].set_yticks([0,1,2],['Seed 11','Seed 22','Seed 33'])
fig.suptitle('Sequential routing versus holding the first action',fontsize=11,fontweight='bold')
save(fig,'Fig4_Sequential_Decision_Ablation')
print('Four figures exported as 600 dpi PNG, vector PDF and SVG.')
