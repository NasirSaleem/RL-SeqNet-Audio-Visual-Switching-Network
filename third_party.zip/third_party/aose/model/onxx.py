import torch
import sys
import os


class TraceableGenerator(torch.nn.Module):
    """A traceable version of the generator that returns only the enhanced audio"""

    def __init__(self, original_generator):
        super().__init__()
        self.original_generator = original_generator

    def forward(self, src, tgt=None):
        if tgt is None:
            tgt = src

        # Call the original generator but only return the enhanced audio
        results = self.original_generator(src, tgt)
        return results['est']


def export_as_torchscript(checkpoint_path, output_path="speech_enhancer.pt"):
    """Export the model as TorchScript (most reliable method)"""

    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)

    # Model config
    config = {
        'num_channels': 16,
        'n_blocks': 2,
        'n_fft': 512,
        'hop_length': 256,
        'compress_factor': 0.3
    }

    # Add model directory to path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    model_dir = os.path.join(current_dir, "model")
    sys.path.insert(0, model_dir)

    from generator.generator import LiSenNet

    # Create original model
    original_generator = LiSenNet(**config)

    # Extract generator weights
    state_dict = checkpoint['state_dict']
    generator_state_dict = {}

    for key, value in state_dict.items():
        if key.startswith('generator.'):
            generator_state_dict[key[10:]] = value

    # Load weights
    original_generator.load_state_dict(generator_state_dict)
    original_generator.eval()

    # Create traceable version
    traceable_generator = TraceableGenerator(original_generator)
    traceable_generator.eval()

    # Trace with example input
    print("Tracing model...")
    dummy_audio = torch.randn(1, 16000)

    # Use torch.jit.trace to create a traced model
    traced_model = torch.jit.trace(traceable_generator, (dummy_audio, dummy_audio))

    # Save the traced model
    traced_model.save(output_path)
    print(f"✓ Model successfully exported as TorchScript: {output_path}")

    return traced_model


def verify_torchscript_model(model_path):
    """Verify the TorchScript model works correctly"""
    print("\nVerifying TorchScript model...")

    # Load the model
    model = torch.jit.load(model_path)
    model.eval()

    # Test with dummy input
    test_audio = torch.randn(1, 16000)

    with torch.no_grad():
        enhanced_audio = model(test_audio, test_audio)

    print(f"✓ Model loaded successfully")
    print(f"✓ Input shape: {test_audio.shape}")
    print(f"✓ Output shape: {enhanced_audio.shape}")
    print(f"✓ Output range: [{enhanced_audio.min():.3f}, {enhanced_audio.max():.3f}]")

    return model


# Install required packages if missing
def check_dependencies():
    """Check and install required packages"""
    try:
        import onnx
    except ImportError:
        print("ONNX is not installed. Installing...")
        os.system("pip install onnx")

    try:
        import onnxruntime
    except ImportError:
        print("ONNX Runtime is not installed. Installing...")
        os.system("pip install onnxruntime")


# Main execution
if __name__ == "__main__":
    checkpoint_path = r"C:\AVSE\Speech Enhancement\log\ckpts\version_0\epoch=99-last.ckpt"

    print("Starting model export...")

    # First, try TorchScript export (most reliable)
    try:
        model = export_as_torchscript(
            checkpoint_path=checkpoint_path,
            output_path="speech_enhancer.pt"
        )

        # Verify the model
        verified_model = verify_torchscript_model("speech_enhancer.pt")

        print("\n" + "=" * 50)
        print("SUCCESS! Your model has been exported as 'speech_enhancer.pt'")
        print("=" * 50)
        print("\nUsage:")
        print("1. Load the model:")
        print("   model = torch.jit.load('speech_enhancer.pt')")
        print("2. Enhance audio:")
        print("   enhanced_audio = model(noisy_audio, noisy_audio)")
        print("\nThe model takes two inputs (both can be the same noisy audio)")
        print("and returns enhanced audio.")

    except Exception as e:
        print(f"TorchScript export failed: {e}")

        # Try ONNX export as backup
        print("\nTrying ONNX export...")
        try:
            # Install dependencies if needed
            check_dependencies()

            # Import and run ONNX export
            from onxx_export import export_feature_based_onnx

            model = export_feature_based_onnx(
                checkpoint_path=checkpoint_path,
                output_path="speech_enhancer.onnx"
            )
            print("✓ ONNX model exported as 'speech_enhancer.onnx'")

        except Exception as e2:
            print(f"ONNX export also failed: {e2}")
            print("\nPlease install required packages:")
            print("pip install onnx onnxruntime")