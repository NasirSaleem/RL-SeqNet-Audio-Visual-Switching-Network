from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from rl_msnet.reliability.corruptions import corrupt_video


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input_npy")
    p.add_argument("output_npy")
    p.add_argument("--kind", required=True,
                   choices=["occlusion", "blur", "low_light", "frame_drop", "pose"])
    p.add_argument("--severity", type=float, required=True)
    p.add_argument("--seed", type=int, default=1143)
    args = p.parse_args()
    frames = np.load(args.input_npy, allow_pickle=False)
    result = corrupt_video(frames, args.kind, args.severity, args.seed)
    out = Path(args.output_npy)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.save(out, result)
    print(f"saved {out}")


if __name__ == "__main__":
    main()
