from __future__ import annotations

import numpy as np


def bootstrap_mean_ci(values, confidence=0.95, n_bootstrap=10000, seed=1143):
    x = np.asarray(values, dtype=np.float64).reshape(-1)
    if x.size == 0 or not 0 < confidence < 1:
        raise ValueError("Provide non-empty values and confidence in (0,1)")
    rng = np.random.default_rng(seed)
    samples = rng.choice(x, size=(n_bootstrap, x.size), replace=True).mean(axis=1)
    alpha = (1.0 - confidence) / 2.0
    return float(x.mean()), tuple(np.quantile(samples, [alpha, 1.0 - alpha]).tolist())


def paired_permutation_test(a, b, n_permutations=10000, seed=1143):
    """Two-sided paired sign-flip permutation test; pair by utterance ID first."""
    a = np.asarray(a, dtype=np.float64).reshape(-1)
    b = np.asarray(b, dtype=np.float64).reshape(-1)
    if a.shape != b.shape or a.size == 0:
        raise ValueError("Paired arrays must be non-empty and have equal length")
    diff = a - b
    observed = abs(diff.mean())
    rng = np.random.default_rng(seed)
    signs = rng.choice((-1.0, 1.0), size=(n_permutations, diff.size))
    null = np.abs((signs * diff).mean(axis=1))
    p = (1.0 + np.count_nonzero(null >= observed)) / (n_permutations + 1.0)
    return float(diff.mean()), float(p)
