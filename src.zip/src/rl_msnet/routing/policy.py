from __future__ import annotations

import torch
from torch import nn


class ActorCritic(nn.Module):
    """MLP actor-critic; previous action is appended as a 3-way one-hot."""

    def __init__(self, state_dim: int = 5, hidden_dim: int = 128, n_actions: int = 3):
        super().__init__()
        self.state_dim = state_dim
        self.n_actions = n_actions
        self.shared = nn.Sequential(
            nn.Linear(state_dim + n_actions, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
        )
        self.actor = nn.Linear(hidden_dim, n_actions)
        self.critic = nn.Linear(hidden_dim, 1)

    def forward(self, state: torch.Tensor, previous_action: torch.Tensor):
        prev = torch.nn.functional.one_hot(previous_action.long(), self.n_actions).to(state.dtype)
        h = self.shared(torch.cat((state, prev), dim=-1))
        return self.actor(h), self.critic(h).squeeze(-1)

    @torch.no_grad()
    def choose(self, state: torch.Tensor, previous_action: torch.Tensor, deterministic: bool = True):
        logits, value = self(state, previous_action)
        distribution = torch.distributions.Categorical(logits=logits)
        action = logits.argmax(dim=-1) if deterministic else distribution.sample()
        return action, distribution.log_prob(action), value
