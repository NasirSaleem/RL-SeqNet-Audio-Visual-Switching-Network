"""Pilot utility-regression router on cached, valid decision segments.

Inputs: noisy-audio spectral proxy, its change, and predicted AVSE confidence.
Targets: AOSE and AVSE utility minus NSE utility, using scales stored in NPZ.
No corruption labels, clean audio, or expert scores enter router inputs.
Fixed epochs and seeds; validation reports are not test-set results.
"""
from __future__ import annotations
import argparse
import csv
import json
import random
from pathlib import Path
import numpy as np
import torch
from torch import nn

ACTIONS = ('aose', 'avse', 'nse')


def load_split(npz_path, csv_path, require_oof):
    with np.load(npz_path, allow_pickle=False) as z:
        d = {k: z[k].copy() for k in z.files}
    required = ['features','target','utilities','episode_ids','steps','conditions',
                'action_order','feature_definition','target_definition','sisdr_scale_db','stoi_scale']
    if any(k not in d for k in required):
        raise ValueError('Missing NPZ fields')
    n = len(d['target'])
    if not n or d['features'].ndim != 2 or d['features'].shape[0] != n or d['features'].shape[1] < 3:
        raise ValueError('Invalid features')
    if str(d['feature_definition']) != 'full_context_visual_encoder_segment_mean_plus_audio_proxy_v2':
        raise ValueError('Unexpected feature order/definition')
    if d['action_order'].tolist() != list(ACTIONS) or d['utilities'].shape != (n,3):
        raise ValueError('Unexpected utility action order or shape')
    if not np.isfinite(d['features']).all() or not np.isfinite(d['utilities']).all():
        raise ValueError('Nonfinite features/utilities')
    keys = list(zip(d['episode_ids'].astype(str), d['steps'].astype(int), d['conditions'].astype(str)))
    if len(set(keys)) != n:
        raise ValueError('Duplicate NPZ decision keys')
    with open(csv_path, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    index = {}
    group_fold = {}
    for r in rows:
        k = (r['episode_id'], int(r['step']), r['condition'])
        if k in index:
            raise ValueError('Duplicate prediction keys')
        fold = int(r['fold'])
        if require_oof and fold < 0:
            raise ValueError('Training must use OOF predictions')
        if not require_oof and fold != -1:
            raise ValueError('Validation must use external-validation predictions')
        if k[0] in group_fold and group_fold[k[0]] != fold:
            raise ValueError('Clip spans multiple confidence folds')
        group_fold[k[0]] = fold
        index[k] = r
    if set(index) != set(keys):
        raise ValueError('Confidence predictions and NPZ keys differ')
    confidence = np.asarray([float(index[k]['visual_confidence']) for k in keys], dtype=np.float32)
    labels = np.asarray([float(index[k]['target']) for k in keys])
    if not np.array_equal(labels, d['target']):
        raise ValueError('Confidence labels differ from NPZ')
    if not np.isfinite(confidence).all() or np.any((confidence<0)|(confidence>1)):
        raise ValueError('Invalid confidence predictions')
    if require_oof and len(set(group_fold.values())) < 2:
        raise ValueError('At least two OOF folds required')
    # Builder stores the two audio-only inputs at the end of each feature vector.
    d['router_features'] = np.column_stack([d['features'][:,-2:], confidence]).astype(np.float32)
    d['selection_labels'] = np.argmax(d['utilities'], axis=1).astype(np.int64)
    return d


class Router(nn.Module):
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(3,64), nn.ReLU(), nn.Linear(64,32), nn.ReLU(), nn.Linear(32,2))
    def forward(self,x):
        return self.network(x)


def fit(data, args, seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    x = data['router_features']
    mean = x.mean(axis=0, dtype=np.float64).astype(np.float32)
    std = x.std(axis=0, dtype=np.float64).astype(np.float32)
    std[std<1e-6] = 1.0
    xt = torch.as_tensor((x-mean)/std, device=args.device)
    advantages = data['utilities'][:,:2] - data['utilities'][:,2:3]
    yt = torch.as_tensor(advantages, dtype=torch.float32, device=args.device)
    model = Router().to(args.device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-4)
    loss_fn = nn.MSELoss()
    for epoch in range(1,args.epochs+1):
        model.train(); total=0.0
        order=torch.randperm(len(xt),device=args.device)
        for start in range(0,len(xt),args.batch_size):
            idx=order[start:start+args.batch_size]
            optimizer.zero_grad(set_to_none=True)
            loss=loss_fn(model(xt[idx]),yt[idx])
            if not torch.isfinite(loss): raise ValueError('Nonfinite training loss')
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.0);optimizer.step()
            total+=loss.item()*len(idx)
        if epoch==1 or epoch%10==0 or epoch==args.epochs:
            print(f'seed={seed} epoch={epoch}/{args.epochs} advantage_MSE={total/len(xt):.5f}',flush=True)
    return model,mean,std


def bootstrap_clip_delta(values, groups, seed):
    # Paired differences, averaged within clip before bootstrap. Equal clip weights.
    clip=np.asarray([values[groups==g].mean() for g in np.unique(groups)])
    if len(clip)<2: return float(clip.mean()), float('nan'), float('nan')
    rng=np.random.default_rng(seed)
    draws=rng.choice(clip,size=(2000,len(clip)),replace=True).mean(axis=1)
    lo,hi=np.quantile(draws,[.025,.975])
    return float(clip.mean()),float(lo),float(hi)


def evaluate(data, actions, seed, label):
    q=data['utilities']; rows=[]
    for condition in ['all']+sorted(set(data['conditions'].tolist())):
        mask=np.ones(len(q),dtype=bool) if condition=='all' else data['conditions']==condition
        u=q[mask]; a=actions[mask]; selected=u[np.arange(len(u)),a]
        delta,lo,hi=bootstrap_clip_delta(selected-u[:,1],data['episode_ids'][mask],12345)
        rows.append(dict(seed=seed,condition=condition,model=label,segments=len(u),
            clips=len(np.unique(data['episode_ids'][mask])),mean_utility=float(selected.mean()),
            oracle_regret=float((u.max(axis=1)-selected).mean()),
            oracle_label_accuracy=float(np.mean(a==u.argmax(axis=1))),
            p_aose=float(np.mean(a==0)),p_avse=float(np.mean(a==1)),p_nse=float(np.mean(a==2)),
            clip_mean_delta_vs_avse=delta,clip_bootstrap_ci_low=lo,clip_bootstrap_ci_high=hi))
    return rows


def write_csv(path, rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',required=True);p.add_argument('--validation',required=True)
    p.add_argument('--train-confidence',required=True);p.add_argument('--validation-confidence',required=True)
    p.add_argument('--out-dir',required=True)
    p.add_argument('--epochs',type=int,default=50);p.add_argument('--batch-size',type=int,default=256)
    p.add_argument('--lr',type=float,default=.001);p.add_argument('--seeds',type=int,nargs='+',default=[11,22,33])
    p.add_argument('--device',default='cuda');args=p.parse_args()
    if min(args.epochs,args.batch_size,args.lr)<=0 or len(set(args.seeds))!=len(args.seeds):
        p.error('Invalid training parameters')
    out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Choose an empty output directory')
    train=load_split(args.train,args.train_confidence,True)
    val=load_split(args.validation,args.validation_confidence,False)
    if set(train['episode_ids']) & set(val['episode_ids']):raise ValueError('Train/validation clip overlap')
    for k in ['sisdr_scale_db','stoi_scale','target_definition','feature_definition']:
        if not np.array_equal(train[k],val[k]):raise ValueError(f'Dataset mismatch: {k}')
    if args.device.startswith('cuda') and not torch.cuda.is_available():raise ValueError('CUDA is unavailable')
    torch.set_num_threads(2)
    out.mkdir(parents=True,exist_ok=True)
    print('Training oracle labels:',dict(zip(ACTIONS,np.bincount(train['selection_labels'],minlength=3).tolist())),flush=True)
    results=[]
    for a,name in enumerate(ACTIONS):results.extend(evaluate(val,np.full(len(val['target']),a),-1,'always_'+name))
    results.extend(evaluate(val,val['selection_labels'],-1,'reference_oracle_upper_bound'))
    for seed in args.seeds:
        model,mean,std=fit(train,args,seed);model.eval()
        with torch.inference_mode():
            x=torch.as_tensor((val['router_features']-mean)/std,device=args.device)
            predicted_advantages=model(x).cpu().numpy()
        if not np.isfinite(predicted_advantages).all(): raise ValueError('Nonfinite predicted advantages')
        predicted_utilities=np.column_stack([predicted_advantages,np.zeros(len(x),dtype=np.float32)])
        actions=predicted_utilities.argmax(axis=1)
        results.extend(evaluate(val,actions,seed,'utility_regression_mlp'))
        torch.save(dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},
            mean=torch.from_numpy(mean),std=torch.from_numpy(std),input_names=['snr_proxy','snr_proxy_delta','visual_confidence'],
            action_order=list(ACTIONS),architecture=[3,64,32,2],output_names=['aose_minus_nse','avse_minus_nse'],
            selection_rule='argmax(predicted_aose_advantage,predicted_avse_advantage,0)',seed=seed,epochs=args.epochs,
            sisdr_scale_db=float(train['sisdr_scale_db']),stoi_scale=float(train['stoi_scale'])),out/f'utility_router_seed_{seed}.ckpt')
        predictions=[]
        for i,a in enumerate(actions):
            predictions.append(dict(episode_id=str(val['episode_ids'][i]),step=int(val['steps'][i]),condition=str(val['conditions'][i]),
                action=ACTIONS[a],predicted_aose_advantage=float(predicted_advantages[i,0]),
                predicted_avse_advantage=float(predicted_advantages[i,1]),predicted_nse_advantage=0.0,
                selected_utility=float(val['utilities'][i,a])))
        write_csv(out/f'validation_predictions_seed_{seed}.csv',predictions)
    write_csv(out/'validation_summary.csv',results)
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),
        objective='unweighted MSE on AOSE-minus-NSE and AVSE-minus-NSE utility; selection ties use aose,avse,nse order',
        input_features=['snr_proxy','snr_proxy_delta','oof_or_external_visual_confidence'],
        normalization='training rows only',training_selection='fixed epochs, no validation checkpoint selection',
        baseline_scope='memoryless utility-regression pilot; no switching or computation cost',
        bootstrap='2000 paired clip-level resamples; all corruption variants kept together; 95% percentile interval',
        limitations=['validation only, 21 clips','filtered valid supervision segments, not full utterances',
                     'seed variation covers router only; confidence model held fixed',
                     'speaker/source disjointness not verified','clip bootstrap is not speaker bootstrap',
                     'no end-to-end waveform, continuity, timing or PPO evaluation']),indent=2),encoding='utf-8')
    for r in results:
        if r['condition']=='all':
            print(f'{r["model"]} seed={r["seed"]}: utility={r["mean_utility"]:.4f}, regret={r["oracle_regret"]:.4f}, AOSE/AVSE/NSE={r["p_aose"]:.3f}/{r["p_avse"]:.3f}/{r["p_nse"]:.3f}')
    print(f'Wrote {out / "validation_summary.csv"}')
    print('Utility-regression baseline completed. This is supervised learning, not PPO or full-utterance evaluation.')


if __name__=='__main__':main()
