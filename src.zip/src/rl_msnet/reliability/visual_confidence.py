from __future__ import annotations

import torch
from torch import nn


class VisualReliabilityEstimator(nn.Module):
    """Predict task-conditioned visual usefulness from AVSE visual embeddings.

    Targets should be derived on training speakers from the relative AVSE vs
    AOSE utility, not solely from whether a synthetic corruption was applied.
    Corruption labels can be used as an auxiliary target if desired.
    """

    def __init__(self, input_dim: int = 130, hidden_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.network(features).squeeze(-1)

    @torch.no_grad()
    def predict_with_uncertainty(self, features: torch.Tensor, samples: int = 20):
        """MC-dropout mean and variance; calibrate probabilities on validation data."""
        if samples < 2:
            raise ValueError("Use at least two stochastic passes for uncertainty")
        self.eval()
        for module in self.modules():
            if isinstance(module, nn.Dropout):
                module.train()
        probabilities = torch.stack([torch.sigmoid(self(features)) for _ in range(samples)])
        self.eval()
        return probabilities.mean(dim=0), probabilities.var(dim=0, unbiased=False)
