import torch
import onnxruntime as ort
import numpy as np


def convert_pt_to_onnx(pt_path, onnx_path="speech_enhancer.onnx"):
    """Convert TorchScript .pt file to ONNX format"""

    print("Loading TorchScript model...")
    # Load the .pt file
    model = torch.jit.load(pt_path)
    model.eval()

    print("Converting to ONNX...")
    # Create dummy input
    dummy_audio = torch.randn(1, 16000)

    # Export to ONNX with opset 17 for STFT support
    torch.onnx.export(
        model,
        (dummy_audio, dummy_audio),  # (src, tgt)
        onnx_path,
        export_params=True,
        opset_version=17,  # Must use opset 17 for STFT
        input_names=['noisy_audio', 'reference_audio'],
        output_names=['enhanced_audio'],
        dynamic_axes={
            'noisy_audio': {0: 'batch_size', 1: 'sequence_length'},
            'reference_audio': {0: 'batch_size', 1: 'sequence_length'},
            'enhanced_audio': {0: 'batch_size', 1: 'sequence_length'}
        },
        do_constant_folding=True,
        verbose=True
    )

    print(f"✅ Successfully converted to ONNX: {onnx_path}")
    return onnx_path


def verify_onnx_model(onnx_path):
    """Verify the converted ONNX model works"""
    print("\nVerifying ONNX model...")

    # Load ONNX model
    session = ort.InferenceSession(onnx_path)

    # Test inference
    test_audio = np.random.randn(1, 16000).astype(np.float32)

    outputs = session.run(None, {
        'noisy_audio': test_audio,
        'reference_audio': test_audio
    })

    print(f"✅ ONNX model verification successful!")
    print(f"   Input shape: {test_audio.shape}")
    print(f"   Output shape: {outputs[0].shape}")
    print(f"   Output range: [{outputs[0].min():.3f}, {outputs[0].max():.3f}]")


if __name__ == "__main__":
    # Convert your .pt file to ONNX
    pt_file = "speech_enhancer.pt"  # Your existing .pt file
    onnx_file = "speech_enhancer_from_pt.onnx"

    # Convert
    onnx_path = convert_pt_to_onnx(pt_file, onnx_file)

    # Verify
    verify_onnx_model(onnx_path)

    print(f"\n🎉 Conversion complete!")
    print(f"   Input: {pt_file}")
    print(f"   Output: {onnx_path}")