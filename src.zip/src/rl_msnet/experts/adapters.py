from __future__ import annotations

import importlib.util
import hashlib
import sys
from pathlib import Path

import numpy as np
import torch


class TorchScriptAOSE:
    """Adapter for AOSE.zip/model/speech_enhancer.pt.

    The supplied AOSE data pipeline divides noisy and clean samples by the
    noisy-waveform standard deviation. This adapter mirrors that normalization
    and restores the input scale after inference. Set normalize=False only if
    your verified inference pipeline uses raw-amplitude audio.
    """

    def __init__(self, checkpoint: str, device: str = "cpu", normalize: bool = True):
        self.device = torch.device(device)
        self.normalize = normalize
        self.model = torch.jit.load(checkpoint, map_location=self.device).eval()

    @torch.inference_mode()
    def __call__(self, noisy_audio: np.ndarray) -> np.ndarray:
        x = torch.as_tensor(np.asarray(noisy_audio), dtype=torch.float32, device=self.device).reshape(1, -1)
        if x.numel() == 0 or not torch.isfinite(x).all():
            raise ValueError("AOSE input must be nonempty and finite")
        scale = (x.std(dim=-1, keepdim=True, unbiased=False) + 1e-8) if self.normalize else x.new_ones((1, 1))
        x_in = x / scale
        enhanced = self.model(x_in, x_in)
        if isinstance(enhanced, dict):
            enhanced = enhanced["est"]
        if isinstance(enhanced, (tuple, list)):
            enhanced = enhanced[0]
        enhanced = enhanced.reshape(1, -1) * scale
        if enhanced.shape != x.shape or not torch.isfinite(enhanced).all():
            raise ValueError("AOSE output must be finite and match the input length")
        return enhanced[0].detach().cpu().numpy()


class AOSEExpert(TorchScriptAOSE):
    """Load the archived LiSenNet Lightning .ckpt or TorchScript .pt.

    Lightning checkpoints are loaded as trusted local training artifacts.
    Only generator weights are needed for inference; the discriminator and
    optimizer are not constructed. Architecture settings come from the saved
    hyperparameters, or from source_dir/config.yaml when absent.
    """

    def __init__(self, checkpoint: str, device: str = "cpu",
                 normalize: bool = True, source_dir: str = "third_party/aose"):
        checkpoint_path = Path(checkpoint).resolve()
        if not checkpoint_path.is_file():
            raise FileNotFoundError(f"AOSE checkpoint not found: {checkpoint_path}")
        if checkpoint_path.suffix.lower() != ".ckpt":
            super().__init__(str(checkpoint_path), device, normalize)
            return

        self.device = torch.device(device)
        self.normalize = normalize
        source = Path(source_dir).resolve()
        package_dir = source / "model" / "generator"
        init_file = package_dir / "__init__.py"
        if not init_file.is_file():
            raise FileNotFoundError(
                f"Expected AOSE source at {init_file}. Extract the original "
                "AOSE archive directly into --aose-source."
            )
        # An isolated package name avoids collisions with the AVSE model.py.
        module_name = "rlmsnet_aose_generator_" + hashlib.sha256(
            str(package_dir).encode("utf-8")
        ).hexdigest()[:12]
        module = sys.modules.get(module_name)
        if module is None:
            spec = importlib.util.spec_from_file_location(
                module_name, init_file, submodule_search_locations=[str(package_dir)]
            )
            if spec is None or spec.loader is None:
                raise ImportError(f"Cannot import AOSE generator from {init_file}")
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            try:
                spec.loader.exec_module(module)
            except Exception:
                for name in list(sys.modules):
                    if name == module_name or name.startswith(module_name + "."):
                        del sys.modules[name]
                raise

        checkpoint_data = torch.load(
            str(checkpoint_path), map_location="cpu", weights_only=False
        )
        if not isinstance(checkpoint_data, dict) or "state_dict" not in checkpoint_data:
            raise ValueError("Expected an AOSE Lightning checkpoint with state_dict")
        hparams = checkpoint_data.get("hyper_parameters") or {}
        config = hparams.get("config") or {}
        model_config = config.get("model_config")
        if model_config is None:
            import yaml
            config_path = source / "config.yaml"
            if not config_path.is_file():
                raise ValueError(
                    "AOSE model_config missing from checkpoint; provide the original "
                    f"training config at {config_path}"
                )
            with config_path.open(encoding="utf-8") as handle:
                model_config = yaml.safe_load(handle)["model_config"]
        generator_weights = {
            key[len("generator."):]: value
            for key, value in checkpoint_data["state_dict"].items()
            if key.startswith("generator.")
        }
        if not generator_weights:
            raise ValueError("AOSE checkpoint has no generator.* weights")
        self.model = module.LiSenNet(**model_config)
        self.model.load_state_dict(generator_weights, strict=True)
        self.model.to(self.device).eval()
        self.model.requires_grad_(False)


def load_avse_checkpoint(checkpoint: str, source_dir: str, device: str = "cpu"):
    """Load the archived AVSE Lightning checkpoint and return an eval model.

    `source_dir` is the extracted Cross-AVSE.zip directory containing
    `model.py`, `dataset.py`, and `config.py`. The checkpoint's saved
    hyperparameters refer to the dataset module, so that source directory must
    be importable. The MobileNet weights are already stored in the checkpoint;
    this loader disables a redundant ImageNet weight download during model
    construction, then loads the checkpoint weights.
    """
    source = Path(source_dir).resolve()
    model_file = source / "model.py"
    if not model_file.is_file():
        raise FileNotFoundError(f"Expected archived AVSE source at {model_file}")
    sys.path.insert(0, str(source))
    try:
        # Needed when the Lightning checkpoint unpickles its saved val_dataset.
        import dataset  # noqa: F401
        module_name = "rlmsnet_archived_avse_model"
        spec = importlib.util.spec_from_file_location(module_name, model_file)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not import AVSE model from {model_file}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        # Avoid downloading initialization weights; checkpoint values replace them.
        import torchvision.models as tv_models
        original_factory = module.mobilenet_v3_small
        module.mobilenet_v3_small = lambda weights=None: tv_models.mobilenet_v3_small(weights=None)
        try:
            model = module.AVSEModule.load_from_checkpoint(
                checkpoint, map_location=device, strict=True
            )
        finally:
            module.mobilenet_v3_small = original_factory
        model.to(device).eval()
        return model
    finally:
        try:
            sys.path.remove(str(source))
        except ValueError:
            pass


def match_avse_level(enhanced: np.ndarray, noisy_audio: np.ndarray) -> np.ndarray:
    """Resolve AVSE's arbitrary output gain using the observed mixture only.

    For the complete inference context, minimize ||x - g*y||^2 with
    g = dot(x, y) / dot(y, y), after removing DC from both waveforms.
    This is a new inference policy, not the archive's peak normalization.
    It restores neither oracle clean amplitude nor guaranteed loudness: noise
    correlated with y can bias g. Use the same policy in all AVSE baselines
    and routing experiments. Never estimate this gain from clean references.
    Apply before taking decision crops. Context-to-context gain changes still
    require overlap/cross-fade treatment in the waveform assembly stage.
    """
    x = np.asarray(noisy_audio, dtype=np.float64)
    y = np.asarray(enhanced, dtype=np.float64)
    if x.ndim != 1 or x.shape != y.shape or not x.size:
        raise ValueError("Level matching requires equal nonempty 1-D waveforms")
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Level matching received nonfinite audio")
    x = x - x.mean()
    y = y - y.mean()
    # Normalize internally to avoid tiny/huge denominators. This cancels
    # algebraically and is not output peak normalization.
    peak = np.max(np.abs(y))
    if peak == 0:
        return np.zeros(x.shape, dtype=np.float32)
    unit = y / peak
    gain = np.dot(x, unit) / np.dot(unit, unit)
    result = unit * gain
    result = result.astype(np.float32)
    if not np.isfinite(result).all():
        raise ValueError("Nonfinite level-matched AVSE output")
    return result


@torch.inference_mode()
def run_avse(model, noisy_audio: np.ndarray, video_frames: np.ndarray,
             level_mode: str = "mixture_projection") -> np.ndarray:
    """Run AVSE on a single context; frames follow archived grayscale format.

    Expected video shape is [1,T,H,W] as returned by the archived dataset, or
    [T,H,W]. By default, estimate one mixture-referenced gain for the entire
    context before the caller crops decision segments. level_mode='raw'
    reproduces the previous adapter for diagnostic comparisons.
    """
    if level_mode not in {"mixture_projection", "raw"}:
        raise ValueError("level_mode must be 'mixture_projection' or 'raw'")
    device = next(model.parameters()).device
    audio = torch.as_tensor(np.asarray(noisy_audio), dtype=torch.float32, device=device).reshape(1, -1)
    frames_np = np.asarray(video_frames, dtype=np.float32)
    if frames_np.ndim == 3:
        frames_np = frames_np[None, ...]
    if frames_np.ndim != 4 or frames_np.shape[0] != 1:
        raise ValueError("video_frames must have shape [T,H,W] or [1,T,H,W]")
    frames = torch.as_tensor(frames_np, dtype=torch.float32, device=device).unsqueeze(0)
    enhanced = model({"noisy_audio": audio, "video_frames": frames})
    enhanced = enhanced.reshape(-1).detach().cpu().numpy()
    n = len(noisy_audio)
    if len(enhanced) != n:
        raise ValueError(f"AVSE returned {len(enhanced)} samples; expected {n}")
    if not np.isfinite(enhanced).all():
        raise ValueError("AVSE returned nonfinite audio")
    if level_mode == "raw":
        return enhanced
    return match_avse_level(enhanced, noisy_audio)
