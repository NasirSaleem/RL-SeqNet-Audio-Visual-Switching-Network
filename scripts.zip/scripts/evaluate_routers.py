from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch

from rl_msnet.routing.policy import ActorCritic


def load_data(path):
    z = np.load(path)
    states = np.asarray(z["states"], dtype=np.float32)
    utilities = np.asarray(z["utilities"], dtype=np.float32)
    lengths = np.asarray(z["lengths"], dtype=np.int64)
    if states.ndim != 3 or utilities.shape != (*states.shape[:2], 3):
        raise ValueError("Expected states [N,T,D] and utilities [N,T,3]")
    if lengths.shape != (states.shape[0],) or np.any(lengths < 1) or np.any(lengths > states.shape[1]):
        raise ValueError("Invalid episode lengths")
    return states, utilities, lengths


def policy_actions(states, lengths, checkpoint, device):
    ckpt = torch.load(checkpoint, map_location=device, weights_only=False)
    if states.shape[-1] != ckpt["state_dim"]:
        raise ValueError("Test state dimension does not match the checkpoint")
    policy = ActorCritic(ckpt["state_dim"], ckpt["hidden_dim"]).to(device)
    policy.load_state_dict(ckpt["policy_state_dict"])
    policy.eval()
    mean = torch.as_tensor(ckpt["state_mean"], dtype=torch.float32, device=device)
    std = torch.as_tensor(ckpt["state_std"], dtype=torch.float32, device=device)
    x = torch.as_tensor(states, dtype=torch.float32, device=device)
    x = torch.clamp((x - mean) / std, -10.0, 10.0)
    n, tmax, _ = x.shape
    actions = torch.full((n, tmax), 2, dtype=torch.long, device=device)
    previous = torch.full((n,), 2, dtype=torch.long, device=device)
    with torch.no_grad():
        for t in range(tmax):
            a, _, _ = policy.choose(x[:, t], previous, deterministic=True)
            active = torch.as_tensor(lengths > t, device=device)
            a = torch.where(active, a, previous)
            actions[:, t] = a
            previous = torch.where(active, a, previous)
    return actions.cpu().numpy()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="Held-out NPZ with states, utilities, lengths")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--out", required=True, help="Per-episode CSV path")
    p.add_argument("--action-costs", nargs=3, type=float, required=True,
                   metavar=("AOSE", "AVSE", "NSE"))
    p.add_argument("--lambda-compute", type=float, required=True)
    p.add_argument("--lambda-switch", type=float, required=True)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()

    states, utility, lengths = load_data(args.data)
    actions = policy_actions(states, lengths, args.checkpoint, args.device)
    costs = np.asarray(args.action_costs, dtype=np.float32)
    names = ("AOSE", "AVSE", "NSE")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    route_counts = np.zeros(3, dtype=np.int64)
    switches = 0
    total_steps = int(lengths.sum())
    episode_rows = []
    for i, length in enumerate(lengths):
        seq = actions[i, :length]
        q = utility[i, np.arange(length), seq]
        cost = costs[seq]
        switch = np.zeros(length, dtype=np.float32)
        if length > 1:
            switch[1:] = (seq[1:] != seq[:-1]).astype(np.float32)
        reward = q - args.lambda_compute * cost - args.lambda_switch * switch
        route_counts += np.bincount(seq, minlength=3)
        switches += int(switch.sum())
        episode_rows.append({
            "episode": i,
            "steps": int(length),
            "mean_quality_utility": float(q.mean()),
            "mean_compute_cost": float(cost.mean()),
            "switches": int(switch.sum()),
            "mean_objective_reward": float(reward.mean()),
            "route_AOSE": int((seq == 0).sum()),
            "route_AVSE": int((seq == 1).sum()),
            "route_NSE": int((seq == 2).sum()),
        })

    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(episode_rows[0]))
        writer.writeheader()
        writer.writerows(episode_rows)
    print("Route proportions:", {names[i]: float(route_counts[i] / max(total_steps, 1)) for i in range(3)})
    print("Switches per decision:", switches / max(total_steps, 1))
    print("Per-episode summary written to", out)


if __name__ == "__main__":
    main()
