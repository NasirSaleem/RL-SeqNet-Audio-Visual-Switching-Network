"""Score frozen experts on complete prepared training clips for clip-router labels.
Uses existing evaluate_routed_waveforms.py and precompute_candidates.py in scripts/.
Automatically resumes completed clip-condition jobs from atomic JSON cache files.
No expert or router is trained. No test data is read. Not a runtime benchmark.
"""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import numpy as np
import torch
from evaluate_routed_waveforms import ACTIONS, STATIC, DYNAMIC, resolve_file
from rl_msnet.experts.adapters import AOSEExpert, load_avse_checkpoint, run_avse
from precompute_candidates import read_mono, score_pair


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def atomic_json(path, obj):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temporary, path)


def jobs_from_manifest(path, condition, prepared_root):
    with path.open(newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    groups = {}
    for r in rows:
        groups.setdefault(r['episode_id'], []).append(r)
    jobs = []
    for episode, group in sorted(groups.items()):
        group.sort(key=lambda r: int(r['step']))
        if [int(r['step']) for r in group] != [0, 1, 2]:
            raise ValueError(f'{condition}/{episode}: expected three contiguous steps')
        for i, r in enumerate(group):
            if (int(r['center_start_sample']), int(r['center_end_sample'])) != (i*16000, (i+1)*16000):
                raise ValueError(f'{condition}/{episode}: unexpected segment bounds')
        paths = []
        for field in ('noisy_wav', 'clean_wav', 'video_npy'):
            values = [resolve_file(r[field], prepared_root).resolve() for r in group]
            if len(set(values)) != 1:
                raise ValueError(f'{condition}/{episode}: mixed {field} within clip')
            paths.append(values[0])
        # Metadata guard detects replaced/moved media on resume without hashing videos.
        signature = [(str(x), x.stat().st_size, x.stat().st_mtime_ns) for x in paths]
        jobs.append(dict(condition=condition, episode_id=episode,
                         paths=[str(x) for x in paths], file_signature=signature))
    return jobs


def score_rows(job, clean, experts):
    rows = []
    for action in ACTIONS:
        wave = np.asarray(experts[action])
        if wave.shape != (48000,) or not np.isfinite(wave).all():
            raise ValueError(f'Invalid waveform: {job["episode_id"]}/{action}')
        row = dict(condition=job['condition'], episode_id=job['episode_id'],
                   model='always_'+action, action=action, duration_seconds=3.0)
        for metric, (value, valid, reason) in score_pair(clean, wave, 1e-6).items():
            ok = bool(valid) and value is not None and np.isfinite(float(value))
            row[metric] = float(value) if ok else ''
            row[metric+'_valid'] = int(ok)
            row[metric+'_reason'] = str(reason)
        # Same composite units as the existing segment objective, now on whole clips.
        ok = row['sisdr_valid'] and row['stoi_valid']
        row['utility_valid'] = int(ok)
        row['utility'] = row['sisdr']/10.0 + row['stoi']/0.1 if ok else ''
        rows.append(row)
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--static-root', default='outputs/visual_corruption_training')
    p.add_argument('--dynamic-root', default='outputs/dynamic_visual_training_v2')
    p.add_argument('--prepared-root', default='data/rl_msnet_prepared')
    p.add_argument('--out-dir', default='outputs/clip_router_training_scores')
    p.add_argument('--aose', default='outputs/aose_finetune/AOSE_adapted.ckpt')
    p.add_argument('--aose-source', default='third_party/aose')
    p.add_argument('--avse-checkpoint', default='weights/avse/AVSE.ckpt')
    p.add_argument('--avse-source', default='third_party/cross_avse')
    p.add_argument('--device', default='cuda')
    p.add_argument('--check-only', action='store_true', help='Validate inputs without running experts')
    args = p.parse_args()
    jobs, manifests = [], {}
    for condition in STATIC+DYNAMIC:
        root = args.static_root if condition in STATIC else args.dynamic_root
        manifest = Path(root)/condition/'manifest.csv'
        jobs.extend(jobs_from_manifest(manifest, condition, args.prepared_root))
        manifests[str(manifest.resolve())] = digest(manifest)
    if not jobs:
        raise ValueError('No clips found')
    config = dict(version=1, manifests=manifests,
                  aose_sha256=digest(args.aose), avse_sha256=digest(args.avse_checkpoint),
                  aose_source=str(Path(args.aose_source).resolve()),
                  avse_source=str(Path(args.avse_source).resolve()), device=args.device,
                  jobs=jobs, scope='Complete prepared 3-second training clips',
                  objective='SI-SDR/10 + STOI/0.1; PESQ is diagnostic only',
                  invalid='Keep invalid metrics flagged; never replace them with zero utility',
                  gain='Existing adapters; AVSE mixture projection; no added clipping')
    # Include source fingerprints to prevent mixing caches after implementation changes.
    import inspect
    config['code_hashes'] = {str(Path(f).resolve()): digest(f) for f in set([
        __file__, inspect.getfile(AOSEExpert), inspect.getfile(score_pair), inspect.getfile(resolve_file)])}
    token = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()
    print(f'Validated {len(jobs)} clip-condition jobs; {len({j["episode_id"] for j in jobs})} source clips', flush=True)
    if args.check_only:
        print('Input check complete; no inference performed.')
        return
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    protocol = out/'protocol.json'
    if protocol.exists():
        if json.loads(protocol.read_text(encoding='utf-8'))['fingerprint'] != token:
            raise ValueError('Inputs or code changed: use a new output directory to avoid mixing scores')
    else:
        if any(out.iterdir()):
            raise ValueError('Unrecognized nonempty output directory')
        atomic_json(protocol, dict(fingerprint=token, configuration=config))
    cache = out/'cache'
    cache.mkdir(exist_ok=True)
    aose = avse = None
    audio_cache = {}
    results = []
    resumed = 0
    for index, job in enumerate(jobs, 1):
        key = hashlib.sha256(json.dumps([job['condition'], job['episode_id']]).encode()).hexdigest()
        target = cache/(key+'.json')
        if target.exists():
            payload = json.loads(target.read_text(encoding='utf-8'))
            if payload['fingerprint'] != token or len(payload['rows']) != 3:
                raise ValueError(f'Invalid cache: {target}')
            rows = payload['rows']
            resumed += 1
        else:
            if aose is None:
                aose = AOSEExpert(args.aose, args.device, source_dir=args.aose_source)
                avse = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, args.device)
            noisy_path, clean_path, video_path = job['paths']
            audio_key = (noisy_path, clean_path)
            if audio_key not in audio_cache:
                noisy, clean = read_mono(noisy_path), read_mono(clean_path)
                if noisy.shape != (48000,) or clean.shape != (48000,) or not np.isfinite(clean).all() or not np.isfinite(noisy).all():
                    raise ValueError('Expected finite 48000-sample mono audio')
                with torch.inference_mode():
                    ao = aose(noisy)
                audio_cache[audio_key] = (noisy, clean, ao)
            noisy, clean, ao = audio_cache[audio_key]
            frames = np.load(video_path, allow_pickle=False)
            with torch.inference_mode():
                av = run_avse(avse, noisy, frames)
            rows = score_rows(job, clean, dict(aose=ao, avse=av, nse=noisy))
            atomic_json(target, dict(fingerprint=token, rows=rows))
        results.extend(rows)
        if index % 10 == 0 or index == len(jobs):
            print(f'Completed {index}/{len(jobs)} jobs ({resumed} reused)', flush=True)
    temporary = out/'train_clip_metrics.tmp'
    with temporary.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    os.replace(temporary, out/'train_clip_metrics.csv')
    valid_jobs = sum(all(r['utility_valid'] for r in results[i:i+3]) for i in range(0, len(results), 3))
    atomic_json(out/'summary.json', dict(clip_condition_jobs=len(jobs), expert_rows=len(results),
                                       all_experts_utility_valid=valid_jobs,
                                       invalid_utility_jobs=len(jobs)-valid_jobs))
    print(f'Wrote {out / "train_clip_metrics.csv"}')
    print('Scoring complete. Next: fit the single-decision supervised router; no test data used.')


if __name__ == '__main__':
    main()
