"""Train a single-decision, offline 3-second supervised router.

Inputs: the three successive [audio proxy, proxy delta, OOF visual confidence]
observations concatenated in temporal order (9 features). No clean-reference
metrics or corruption labels enter the network. Training labels maximize full
clip SI-SDR/10 + STOI/0.1. Fixed 50 epochs, three seeds; no validation selection.
Requires complete finite three-step observations; exclusions are audited.
"""
import argparse
import csv
import json
import random
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from torch import nn

ACTIONS = ('aose', 'avse', 'nse')
METRICS = ('pesq', 'stoi', 'sisdr')


class ClipRouter(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(9, 64), nn.ReLU(), nn.Linear(64, 32),
                                 nn.ReLU(), nn.Linear(32, 3))
    def forward(self, x):
        return self.net(x)


def read_csv(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def write_csv(path, rows, fields=None):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def metric_valid(r, metric):
    return str(r[metric+'_valid']) == '1' and np.isfinite(float(r[metric]))


def fixed_scores(rows):
    scores = {}
    for r in rows:
        if not r['model'].startswith('always_'):
            continue
        a = r['model'][7:]
        if a not in ACTIONS:
            raise ValueError('Unknown action')
        key = (r['condition'], r['episode_id'], a)
        if key in scores:
            raise ValueError(f'Duplicate expert score: {key}')
        scores[key] = r
    if not scores:
        raise ValueError('No fixed expert scores')
    return scores


def assemble(npz, scores, split):
    with np.load(npz, allow_pickle=False) as d:
        obs = d['observations'].copy()
        ids = d['episode_ids'].copy()
        conditions = d['conditions'].copy()
        steps = d['steps'].copy()
        bounds = d['segment_bounds'].copy()
        names = d['observation_names'].tolist()
    if obs.shape != (len(ids), 3):
        raise ValueError('Expected three observation features')
    groups = defaultdict(dict)
    for i, (c, e, s) in enumerate(zip(conditions, ids, steps)):
        key = (str(c), str(e))
        if int(s) in groups[key]:
            raise ValueError(f'Duplicate observation: {key}/{s}')
        groups[key][int(s)] = i
    keys, features, labels, audit = [], [], [], []
    expected = sorted({(c, e) for c, e, a in scores})
    for c, e in expected:
        group = groups.get((c, e), {})
        reason = ''
        if set(group) != {0, 1, 2}:
            reason = 'missing_step_observation'
        elif not all(np.array_equal(bounds[group[s]], [s*16000, (s+1)*16000]) for s in range(3)):
            raise ValueError('Unexpected decision bounds')
        elif not np.isfinite(obs[[group[s] for s in range(3)]]).all():
            reason = 'nonfinite_observation'
        expert = [scores.get((c, e, a)) for a in ACTIONS]
        if any(r is None for r in expert):
            raise ValueError(f'Missing expert scores: {c}/{e}')
        if not reason and not all(metric_valid(r, m) for r in expert for m in ('sisdr', 'stoi')):
            reason = 'invalid_training_objective' if split == 'train' else 'invalid_validation_objective'
        if reason:
            audit.append(dict(split=split, condition=c, episode_id=e, reason=reason))
            continue
        x = obs[[group[s] for s in range(3)]].reshape(9)
        utilities = [float(r['sisdr'])/10 + float(r['stoi'])/.1 for r in expert]
        keys.append((c, e)); features.append(x); labels.append(int(np.argmax(utilities)))
    if not keys:
        raise ValueError(f'No usable {split} clips')
    return keys, np.asarray(features, dtype=np.float32), np.asarray(labels), audit, names


def summaries(predictions, references):
    result = []
    for seed in sorted({r['seed'] for r in predictions}):
        own = [r for r in predictions if r['seed'] == seed]
        for condition in ['all'] + sorted({r['condition'] for r in own}):
            subset = [r for r in own if condition == 'all' or r['condition'] == condition]
            for baseline, mapping in references(seed).items():
                for metric in METRICS:
                    pairs = []
                    for r in subset:
                        ref = mapping[(r['condition'], r['episode_id'])]
                        if metric_valid(r, metric) and metric_valid(ref, metric):
                            pairs.append((r['episode_id'], float(r[metric]), float(ref[metric])))
                    row = dict(seed=seed, condition=condition, metric=metric, baseline=baseline,
                               total_clips=len(subset), paired_valid_clips=len(pairs), independent_clips=0,
                               mean_router='', mean_baseline='', delta='', ci_low='', ci_high='')
                    if pairs:
                        grouped = defaultdict(list)
                        for e, x, y in pairs:
                            grouped[e].append(x-y)
                        deltas = np.array([np.mean(v) for v in grouped.values()])
                        boot = np.random.default_rng(12345).choice(deltas, (2000, len(deltas)), replace=True).mean(1)
                        lo, hi = np.quantile(boot, [.025, .975])
                        row.update(independent_clips=len(deltas), mean_router=float(np.mean([x for _,x,y in pairs])),
                                   mean_baseline=float(np.mean([y for _,x,y in pairs])),
                                   delta=float(np.mean([x-y for _,x,y in pairs])), ci_low=float(lo), ci_high=float(hi))
                    result.append(row)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train-episodes', default='outputs/ppo_data_combined/train_episodes.npz')
    p.add_argument('--validation-episodes', default='outputs/ppo_data_combined/validation_episodes.npz')
    p.add_argument('--train-metrics', default='outputs/clip_router_training_scores/train_clip_metrics.csv')
    p.add_argument('--validation-metrics', default='outputs/waveform_validation_combined/clip_metrics.csv')
    p.add_argument('--out-dir', default='outputs/supervised_clip_router')
    p.add_argument('--device', default='cpu')
    args = p.parse_args()
    out = Path(args.out_dir)
    if out.exists() and any(out.iterdir()):
        p.error('Use an empty output directory')
    train = fixed_scores(read_csv(args.train_metrics))
    val_rows = read_csv(args.validation_metrics)
    val = fixed_scores(val_rows)
    kt, xt, yt, at, nt = assemble(args.train_episodes, train, 'train')
    kv, xv, yv, av, nv = assemble(args.validation_episodes, val, 'validation')
    if nt != nv:
        raise ValueError('Observation names differ')
    if {e for c,e,a in train} & {e for c,e,a in val}:
        raise ValueError('Train/validation source clip IDs overlap')
    if av:
        raise ValueError('Incomplete validation coverage: fix features/scores before comparing routers')
    mean, std = xt.mean(0), xt.std(0)
    std = np.where(std < 1e-6, 1.0, std)
    tx = torch.tensor((xt-mean)/std, device=args.device)
    ty = torch.tensor(yt, dtype=torch.long, device=args.device)
    vx = torch.tensor((xv-mean)/std, device=args.device)
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out/'excluded_clips.csv', at+av, ['split','condition','episode_id','reason'])
    print(f'Training: {len(kt)} clip-condition cases; excluded: {len(at)}; validation: {len(kv)}', flush=True)
    predictions, log = [], []
    for seed in (11,22,33):
        random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
        model = ClipRouter().to(args.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=.001, weight_decay=1e-4)
        for epoch in range(1,51):
            model.train(); total = 0.
            order = torch.randperm(len(tx), device=args.device)
            for ix in order.split(256):
                optimizer.zero_grad()
                loss = nn.functional.cross_entropy(model(tx[ix]), ty[ix])
                loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step(); total += float(loss.item())*len(ix)
            log.append(dict(seed=seed, epoch=epoch, train_loss=total/len(tx)))
            if epoch % 10 == 0:
                print(f'seed={seed} epoch={epoch}/50 loss={total/len(tx):.5f}', flush=True)
        model.eval()
        with torch.inference_mode():
            choices = model(vx).argmax(1).cpu().numpy()
        torch.save(dict(state_dict={k:v.cpu() for k,v in model.state_dict().items()},
                        mean=torch.tensor(mean), std=torch.tensor(std), seed=seed,
                        feature_names=[f'step{s}_{n}' for s in range(3) for n in nt],
                        action_order=list(ACTIONS), epochs=50), out/f'clip_router_seed_{seed}.ckpt')
        for (c,e), choice, label in zip(kv, choices, yv):
            action = ACTIONS[int(choice)]; source = val[c,e,action]
            r = dict(seed=seed, condition=c, episode_id=e, action=action,
                     oracle_action=ACTIONS[int(label)])
            for m in METRICS:
                r[m] = source[m]; r[m+'_valid'] = source[m+'_valid']
            predictions.append(r)
    def references(seed):
        refs = {'always_avse':{(c,e):r for (c,e,a),r in val.items() if a=='avse'}}
        for mode in ('hard','crossfade'):
            mapping = {(r['condition'],r['episode_id']):r for r in val_rows
                       if r['model']=='ppo' and int(r['seed'])==seed and r['reconstruction']==mode}
            if set(mapping) != set(kv):
                raise ValueError(f'Missing PPO {mode} seed {seed} comparison rows')
            refs['ppo_'+mode] = mapping
        return refs
    write_csv(out/'validation_predictions.csv', predictions)
    write_csv(out/'validation_summary.csv', summaries(predictions, references))
    write_csv(out/'training_log.csv', log)
    atomic = dict(**vars(args), train_cases=len(kt), validation_cases=len(kv), excluded_train_cases=len(at),
                  train_label_counts={a:int((yt==i).sum()) for i,a in enumerate(ACTIONS)},
                  inputs='9 features: three temporal observations concatenated; training confidence must be OOF',
                  objective='Unweighted cross entropy of argmax whole-clip (SI-SDR/10 + STOI/0.1)',
                  optimizer='Adam lr=.001 weight_decay=.0001; batch=256; clip_grad_norm=1',
                  architecture='9-64-32-3 ReLU MLP', epochs=50, seeds=[11,22,33],
                  selection='Final fixed epoch; no validation checkpoint or seed selection',
                  limitations='Offline three-second clip baseline, no causal streaming. Complete-feature subset only; differs from PPO partial-run training coverage. Clip-ID separation checked; speaker/recording separation not verified.',
                  statistics='2000 source-clip bootstrap draws, corruption variants grouped; exploratory unadjusted 95% intervals')
    (out/'protocol.json').write_text(json.dumps(atomic,indent=2),encoding='utf-8')
    print(f'Complete: {out / "validation_summary.csv"}')
    print('Positive delta means the clip router beats the named baseline. No expert inference performed.')


if __name__ == '__main__':
    main()
