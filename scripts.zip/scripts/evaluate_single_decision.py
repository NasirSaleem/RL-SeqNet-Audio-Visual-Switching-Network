"""Compare saved switching scores with holding the first action for a whole clip.

No retraining or inference. Fixed-expert clip scores are exact scores for the
held action, provided all rows come from the SAME evaluate_routed_waveforms run.
This is a frozen-policy ablation, not a trained utterance-level routing baseline.
"""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

METRICS = ('pesq', 'stoi', 'sisdr')
ACTIONS = ('aose', 'avse', 'nse')


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def valid(row, metric):
    return row[metric + '_valid'] == '1' and np.isfinite(float(row[metric]))


def compare(rows, draws):
    fixed, routed = {}, {}
    for row in rows:
        key = (row['condition'], row['episode_id'])
        if float(row['duration_seconds']) != 3:
            raise ValueError('Expected prepared three-second clips')
        if row['model'].startswith('always_'):
            action = row['model'][7:]
            if action not in ACTIONS or row['reconstruction'] != 'fixed':
                raise ValueError('Unexpected fixed expert row')
            k = (*key, action)
            if k in fixed:
                raise ValueError(f'Duplicate fixed row: {k}')
            fixed[k] = row
        elif row['model'] in ('ppo', 'utility_router'):
            k = (row['model'], row['seed'], row['reconstruction'], *key)
            if k in routed:
                raise ValueError(f'Duplicate routing row: {k}')
            actions = row['actions'].split('|')
            if len(actions) != 3 or any(a not in ACTIONS for a in actions):
                raise ValueError('Expected three valid actions')
            routed[k] = row
    if not routed:
        raise ValueError('No PPO or utility-router rows found')
    expected = {(c, e) for c, e, a in fixed}
    variants = defaultdict(set)
    pairs = []
    for (model, seed, mode, condition, episode), row in routed.items():
        variants[model, seed, mode].add((condition, episode))
        if any((condition, episode, a) not in fixed for a in ACTIONS):
            raise ValueError(f'Missing expert scores: {condition}/{episode}')
        action = row['actions'].split('|')[0]
        held = fixed[condition, episode, action]
        avse = fixed[condition, episode, 'avse']
        pair = dict(model=model, seed=seed, reconstruction=mode,
                    condition=condition, episode_id=episode, held_action=action,
                    switching_actions=row['actions'], switches=int(row['switches']))
        for metric in METRICS:
            ok = all(valid(r, metric) for r in (row, held, avse))
            pair[metric + '_paired_valid'] = int(ok)
            for name, source in [('switching', row), ('held_first', held), ('always_avse', avse)]:
                pair[metric + '_' + name] = float(source[metric]) if ok else ''
        pairs.append(pair)
    if any(keys != expected for keys in variants.values()):
        raise ValueError('Clip-condition coverage differs between methods')
    summary = []
    for model, seed, mode in sorted(variants):
        own = [r for r in pairs if (r['model'], r['seed'], r['reconstruction']) == (model, seed, mode)]
        for condition in ['all'] + sorted({r['condition'] for r in own}):
            subset = [r for r in own if condition == 'all' or r['condition'] == condition]
            for metric in METRICS:
                usable = [r for r in subset if r[metric + '_paired_valid']]
                for left, right in [('switching', 'held_first'), ('held_first', 'always_avse')]:
                    entry = dict(model=model, seed=seed, reconstruction=mode, condition=condition,
                                 metric=metric, comparison=left + '_minus_' + right,
                                 total_clips=len(subset), paired_valid_clips=len(usable),
                                 independent_clips=0, mean_left='', mean_right='', paired_delta='',
                                 clip_mean_delta='', ci_low='', ci_high='')
                    if usable:
                        x = np.array([r[metric + '_' + left] for r in usable])
                        y = np.array([r[metric + '_' + right] for r in usable])
                        ids = np.array([r['episode_id'] for r in usable])
                        grouped = np.array([(x-y)[ids == g].mean() for g in np.unique(ids)])
                        rng = np.random.default_rng(12345)
                        boot = rng.choice(grouped, size=(draws, len(grouped)), replace=True).mean(axis=1)
                        lo, hi = np.quantile(boot, [.025, .975])
                        entry.update(independent_clips=len(grouped), mean_left=float(x.mean()),
                                     mean_right=float(y.mean()), paired_delta=float((x-y).mean()),
                                     clip_mean_delta=float(grouped.mean()), ci_low=float(lo), ci_high=float(hi))
                    summary.append(entry)
    return pairs, summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--metrics', default='outputs/waveform_validation_combined/clip_metrics.csv')
    p.add_argument('--out-dir', default='outputs/single_decision_validation')
    p.add_argument('--bootstrap-draws', type=int, default=2000)
    args = p.parse_args()
    if args.bootstrap_draws < 1:
        p.error('Bootstrap draws must be positive')
    out = Path(args.out_dir)
    if out.exists() and any(out.iterdir()):
        p.error('Use an empty output directory')
    with Path(args.metrics).open(newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    pairs, summary = compare(rows, args.bootstrap_draws)
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / 'single_decision_pairs.csv', pairs)
    write_csv(out / 'single_decision_summary.csv', summary)
    (out / 'protocol.json').write_text(json.dumps(dict(
        **vars(args), definition='Hold the saved first action for all 48000 samples',
        scope='Frozen-policy ablation on prepared 3-second clips; not a separately trained clip router',
        information='First action retains original full-context visual features; no streaming claim',
        scores='Exact fixed-expert scores from the same waveform-evaluation CSV; no score averaging to reconstruct audio',
        statistics='Paired source-clip bootstrap, corruption variants grouped; seeds reported separately',
        limitations='No inference timing. Validation only. Confidence intervals are exploratory, not multiplicity adjusted.'
    ), indent=2), encoding='utf-8')
    print(f'Compared {len(pairs)} router/clip/condition/reconstruction cases')
    print(f'Wrote {out / "single_decision_summary.csv"}')
    print('Positive switching_minus_held_first means switching improves that metric.')
    print('No model training or GPU inference performed.')


if __name__ == '__main__':
    main()
