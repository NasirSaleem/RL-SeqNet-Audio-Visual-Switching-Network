"""Frozen-model evaluation on actual within-clip corruption sequences.

Requires the earlier training scripts in the same scripts/ directory.
Uses cached expert metrics; runs only the frozen visual encoder and small routers.
All metrics are central-segment diagnostics, not reconstructed-waveform scores.
"""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np
import torch
from rl_msnet.experts.adapters import load_avse_checkpoint
from train_corruption_confidence import ConfidenceMLP, scores
from train_supervised_router import Router as ClassifierRouter
from train_utility_router import Router as UtilityRouter
from train_ppo_router import ActorCritic, select, report, outcomes, oracle_actions

ACTIONS=('aose','avse','nse')
CONDITIONS=('clean','clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean')


def read_index(path):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    result={}
    for row in rows:
        key=(row['episode_id'],int(row['step']))
        if key in result:raise ValueError(f'Duplicate key in {path}')
        result[key]=row
    if not result:raise ValueError(f'Empty file: {path}')
    return result


def checkpoint(path,model,device):
    # These newer checkpoints contain tensors and primitive metadata only.
    ck=torch.load(path,map_location='cpu',weights_only=True)
    model.load_state_dict(ck['state_dict'],strict=True);model.to(device).eval()
    mean=ck['mean'].cpu().numpy();std=ck['std'].cpu().numpy()
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std<=0):
        raise ValueError(f'Invalid checkpoint normalization: {path}')
    return model,ck,mean,std


def predict_confidence(model,x,mean,std,device):
    result=[]
    with torch.inference_mode():
        for start in range(0,len(x),256):
            t=torch.as_tensor((x[start:start+256]-mean)/std,dtype=torch.float32,device=device)
            result.append(torch.sigmoid(model(t)).cpu().numpy())
    return np.concatenate(result)


def build_data(args,scales,feature_dim):
    audio=read_index(args.audio_manifest);rows=[];metrics=[];offsets=[0]
    for condition in CONDITIONS:
        folder=Path(args.root)/condition
        manifest=read_index(folder/'manifest.csv');scores_index=read_index(folder/'metrics.csv')
        if set(manifest)!=set(audio) or set(scores_index)!=set(audio):raise ValueError(f'Key mismatch: {condition}')
        for episode in sorted({key[0] for key in manifest}):
            keys=sorted(key for key in manifest if key[0]==episode)
            if [k[1] for k in keys]!=[0,1,2]:raise ValueError('This evaluation requires complete 3-step validation clips')
            for key in keys:
                row=dict(manifest[key]);a=audio[key];m=scores_index[key]
                if a.get('snr_proxy_valid')!='1':raise ValueError(f'Invalid audio proxy: {condition} {key}; no silent deletion permitted')
                for name in ['snr_est_db','snr_delta_db']:row[name]=a[name]
                for field in ['center_start_sample','center_end_sample']:
                    if int(row[field])!=int(a[field]) or int(row[field])!=int(m[field]):raise ValueError('Segment bounds disagree')
                if int(row['center_start_sample'])!=key[1]*16000 or int(row['center_end_sample'])!=(key[1]+1)*16000:
                    raise ValueError('Expected one-second aligned decisions')
                for action in ACTIONS:
                    for metric in ['sisdr','stoi','pesq']:
                        if m.get(f'{metric}_valid_{action}')!='1' or not np.isfinite(float(m[f'{metric}_{action}'])):
                            raise ValueError(f'Invalid metric: {condition} {key} {metric} {action}; requires explicit missing-data protocol')
                row['condition']=condition;rows.append(row);metrics.append(m)
            offsets.append(len(rows))
    encoder=load_avse_checkpoint(args.avse_checkpoint,args.avse_source,args.device);encoder.eval()
    for param in encoder.parameters():param.requires_grad_(False)
    features=[];cached_path=None;encoded=None
    for i,row in enumerate(rows):
        if row['video_npy']!=cached_path:
            frames=np.load(row['video_npy'],allow_pickle=False).astype(np.float32)
            if frames.ndim!=4 or frames.shape[:2]!=(1,75) or not np.isfinite(frames).all() or frames.min()<0 or frames.max()>1:
                raise ValueError('Invalid input video')
            with torch.inference_mode():encoded=encoder.model.visual_encoder(torch.as_tensor(frames[None],device=args.device))[0].cpu().numpy()
            if encoded.ndim!=2 or encoded.shape[0]!=75:raise ValueError('Unexpected visual encoder shape')
            cached_path=row['video_npy']
        step=int(row['step'])
        feature=np.concatenate([encoded[step*25:(step+1)*25].mean(axis=0),[float(row['snr_est_db']),float(row['snr_delta_db'])]]).astype(np.float32)
        if feature.shape!=(feature_dim,) or not np.isfinite(feature).all():raise ValueError('Invalid feature shape/values')
        features.append(feature)
        if (i+1)%75==0:print(f'Extracted frozen features: {i+1}/{len(rows)}',flush=True)
    del encoder
    if args.device.startswith('cuda'):torch.cuda.empty_cache()
    utility=np.array([[float(m[f'sisdr_{a}'])/scales[0]+float(m[f'stoi_{a}'])/scales[1] for a in ACTIONS] for m in metrics],dtype=np.float32)
    d=dict(episode_ids=np.array([r['episode_id'] for r in rows]),steps=np.array([int(r['step']) for r in rows]),
           conditions=np.array([r['condition'] for r in rows]),offsets=np.array(offsets),lengths=np.diff(offsets),
           utilities=utility,action_rewards=utility-utility[:,2:3])
    return d,np.asarray(features),rows,metrics


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',default='outputs/dynamic_visual_validation')
    p.add_argument('--audio-manifest',default='data/rl_msnet_prepared/manifests/validation_features.csv')
    p.add_argument('--confidence',default='outputs/confidence_training/visual_confidence.ckpt')
    p.add_argument('--supervised-dir',default='outputs/supervised_router')
    p.add_argument('--utility-dir',default='outputs/utility_router')
    p.add_argument('--ppo-dir',default='outputs/ppo_router')
    p.add_argument('--ppo-zero-dir',default='outputs/ppo_router_no_switch_cost')
    p.add_argument('--avse-checkpoint',default='weights/avse/AVSE.ckpt');p.add_argument('--avse-source',default='third_party/cross_avse')
    p.add_argument('--out-dir',default='outputs/dynamic_router_evaluation')
    p.add_argument('--seeds',type=int,nargs='+',default=[11,22,33]);p.add_argument('--switch-cost',type=float,default=.05)
    p.add_argument('--device',default='cuda');args=p.parse_args()
    if args.switch_cost<0 or len(set(args.seeds))!=len(args.seeds):p.error('Invalid cost or seeds')
    out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Use an empty output directory')
    for seed in args.seeds:
        for folder,filename in [(args.supervised_dir,f'router_seed_{seed}.ckpt'),(args.utility_dir,f'utility_router_seed_{seed}.ckpt'),
                                (args.ppo_dir,f'ppo_seed_{seed}.ckpt'),(args.ppo_zero_dir,f'ppo_seed_{seed}.ckpt')]:
            if not (Path(folder)/filename).is_file():raise FileNotFoundError(Path(folder)/filename)
    meta=torch.load(args.confidence,map_location='cpu',weights_only=True)
    if meta['target_definition']!='avse_utility_gt_max_aose_nse_binary_v1':raise ValueError('Unexpected confidence target')
    if meta['feature_definition']!='full_context_visual_encoder_segment_mean_plus_audio_proxy_v2':raise ValueError('Unexpected confidence features')
    cm,ck,mean,std=checkpoint(args.confidence,ConfidenceMLP(meta['input_dim']),args.device)
    scales=(float(ck['sisdr_scale_db']),float(ck['stoi_scale']))
    d,features,rows,metrics=build_data(args,scales,meta['input_dim'])
    if set(d['episode_ids'])&set(ck['training_episode_ids']):raise ValueError('Evaluation clips overlap confidence fitting clips')
    confidence=predict_confidence(cm,features,mean,std,args.device)
    d['observations']=np.column_stack([features[:,-2:],confidence]).astype(np.float32)
    out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out/'frozen_features.npz',features=features,confidence=confidence,**d)
    q=d['utilities'];target=(q[:,1]>np.maximum(q[:,0],q[:,2])).astype(int)
    conf_report=[]
    for condition in CONDITIONS:
        for step in [-1,0,1,2]:
            mask=(d['conditions']==condition)&((d['steps']==step) if step>=0 else True)
            conf_report.append(dict(condition=condition,step=step,**scores(target[mask],confidence[mask])))
    write_csv(out/'confidence_summary.csv',conf_report)
    summary=[];position=[];decisions=[]
    def record(name,seed,actions):
        summary.extend(report(d,actions,args.switch_cost,name,seed))
        _,net,switched,eligible=outcomes(d,actions,args.switch_cost)
        for condition in CONDITIONS:
            for step in [0,1,2]:
                ids=np.flatnonzero((d['conditions']==condition)&(d['steps']==step));a=actions[ids]
                entry=dict(model=name,seed=seed,condition=condition,step=step,segments=len(ids),
                    visual_condition=rows[int(ids[0])]['segment_visual_condition'],mean_confidence=float(confidence[ids].mean()),
                    p_aose=float(np.mean(a==0)),p_avse=float(np.mean(a==1)),p_nse=float(np.mean(a==2)),
                    switches=int(switched[ids].sum()),eligible_transitions=int(eligible[ids].sum()),
                    mean_net_gain_vs_nse=float(net[ids].mean()))
                for metric in ['pesq','stoi','sisdr']:
                    entry['mean_selected_'+metric]=float(np.mean([float(metrics[i][f'{metric}_{ACTIONS[actions[i]]}']) for i in ids]))
                position.append(entry)
        for i,a in enumerate(actions):
            decisions.append(dict(model=name,seed=seed,episode_id=str(d['episode_ids'][i]),condition=str(d['conditions'][i]),
                step=int(d['steps'][i]),visual_condition=rows[i]['segment_visual_condition'],visual_confidence=float(confidence[i]),
                action=ACTIONS[a],switched=int(switched[i]),utility=float(q[i,a]),net_reward=float(net[i])))
    for a,name in enumerate(ACTIONS):record('always_'+name,-1,np.full(len(q),a))
    record('reference_dp_oracle',-1,oracle_actions(d,args.switch_cost))
    for seed in args.seeds:
        specs=[('supervised_mlp',Path(args.supervised_dir)/f'router_seed_{seed}.ckpt',ClassifierRouter()),
               ('utility_regression_mlp',Path(args.utility_dir)/f'utility_router_seed_{seed}.ckpt',UtilityRouter()),
               ('ppo_cost_005',Path(args.ppo_dir)/f'ppo_seed_{seed}.ckpt',ActorCritic()),
               ('ppo_cost_zero',Path(args.ppo_zero_dir)/f'ppo_seed_{seed}.ckpt',ActorCritic())]
        for name,path,model in specs:
            model,meta,mean,std=checkpoint(path,model,args.device)
            if meta['action_order']!=list(ACTIONS):raise ValueError('Action order mismatch')
            if not np.allclose([meta['sisdr_scale_db'],meta['stoi_scale']],scales):raise ValueError('Utility scales differ')
            normal=(d['observations']-mean)/std
            if name.startswith('ppo'):
                expected=0 if name=='ppo_cost_zero' else .05
                if not np.isclose(meta['switch_cost'],expected):raise ValueError('PPO training penalty differs from label')
                actions=select(model,d,normal,args.device)
            else:
                with torch.inference_mode():prediction=model(torch.as_tensor(normal,device=args.device)).cpu().numpy()
                if name=='utility_regression_mlp':prediction=np.column_stack([prediction,np.zeros(len(prediction))])
                actions=prediction.argmax(axis=1)
            record(name,seed,actions)
            print(f'Evaluated {name}, seed={seed}',flush=True)
    write_csv(out/'router_summary.csv',summary);write_csv(out/'position_summary.csv',position);write_csv(out/'decisions.csv',decisions)
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),
        scope='frozen models, dynamic validation sequences; central-segment metrics only',
        common_evaluation_switch_cost=args.switch_cost,position_index='0,1,2 corresponds to seconds 1,2,3',
        training='none; saved normalization statistics reused',
        inputs='no corruption condition, target, clean reference or expert utility provided to policy',
        limitations=['full-context noncausal visual encoder; no response-latency claim',
                     'same validation speakers/clips used earlier; not a new independent test set',
                     'no waveform reconstruction or end-to-end runtime evaluation',
                     'condition names in output are analysis labels only']),indent=2),encoding='utf-8')
    print(f'Wrote {out}/router_summary.csv and position_summary.csv')
    print('Frozen dynamic evaluation complete. No retraining or enhancement reruns performed.')


if __name__=='__main__':main()
