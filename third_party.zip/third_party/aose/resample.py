import os
from pathlib import Path
import librosa
import soundfile as sf
from tqdm import tqdm


def resample_se_dataset():
    """
    Resample your speech enhancement dataset directories
    """
    # Define your directories
    directories = {
        #'train_src': 'data/train/noisy',
        #'train_tgt': 'data/train/clean',
        #'val_src': 'data/val/clean',
        #'val_tgt': 'data/train/clean',
        'test_src': 'data/test/noisy',
        'test_tgt': 'data/test/clean'
    }
    for dir_name, dir_path in directories.items():
        input_dir = Path(dir_path)
        output_dir = Path(f"{dir_path}_16k")
        if not input_dir.exists():
            print(f"Directory {input_dir} does not exist, skipping...")
            continue
        print(f"Processing {dir_name}...")
        # Create output directory
        output_dir.mkdir(parents=True, exist_ok=True)
        # Get all WAV files
        wav_files = list(input_dir.glob("*.wav"))
        for wav_file in tqdm(wav_files, desc=f"Resampling {dir_name}"):
            try:
                # Load and resample
                y, sr = librosa.load(str(wav_file), sr=48000)
                y_16k = librosa.resample(y, orig_sr=sr, target_sr=16000)
                # Save
                output_file = output_dir / wav_file.name
                sf.write(str(output_file), y_16k, 16000)
            except Exception as e:
                print(f"Error with {wav_file}: {e}")
    print("All directories processed!")


if __name__ == "__main__":
    resample_se_dataset()
