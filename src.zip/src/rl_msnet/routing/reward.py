from __future__ import annotations

import numpy as np


def composite_quality_utility(
    sisdr_gain_db: np.ndarray,
    stoi_gain: np.ndarray,
    sisdr_scale_db: float,
    stoi_scale: float,
    stoi_weight: float = 1.0,
) -> np.ndarray:
    """Convert metric gains to a dimensionless quality utility.

    Inputs have a final action dimension ordered AOSE, AVSE, NSE. Gains are
    relative to the same noisy segment. Scales must be estimated on validation
    data and then frozen. This function does not compute PESQ/STOI/SI-SDR.
    """
    if sisdr_scale_db <= 0 or stoi_scale <= 0:
        raise ValueError("Metric scales must be positive and selected on validation data")
    return (sisdr_gain_db / sisdr_scale_db) + stoi_weight * (stoi_gain / stoi_scale)


def route_reward(
    quality_utility: np.ndarray,
    action: np.ndarray,
    previous_action: np.ndarray,
    action_costs: np.ndarray,
    lambda_compute: float,
    lambda_switch: float,
) -> np.ndarray:
    """Reward quality minus measured computation and action-switch costs."""
    quality_utility = np.asarray(quality_utility)
    action = np.asarray(action, dtype=np.int64)
    previous_action = np.asarray(previous_action, dtype=np.int64)
    action_costs = np.asarray(action_costs, dtype=np.float32)
    if quality_utility.shape[-1] != 3 or action_costs.shape != (3,):
        raise ValueError("Expected three action utilities and three action costs")
    q = np.take_along_axis(quality_utility, action[..., None], axis=-1)[..., 0]
    compute = action_costs[action]
    switching = (action != previous_action).astype(np.float32)
    return q - lambda_compute * compute - lambda_switch * switching
