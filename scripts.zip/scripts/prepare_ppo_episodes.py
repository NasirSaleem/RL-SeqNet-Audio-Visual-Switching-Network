"""Assemble contiguous, valid cached decision runs for a PPO pilot.

No speech enhancement or policy training. Missing metric rows terminate runs.
Rewards saved here are action utility improvements over NSE, without switching
cost: the environment must apply switching cost after the action is selected.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
ACTIONS = ('aose','avse','nse')

def load_split(npz_path, csv_path, require_oof):
    with np.load(npz_path, allow_pickle=False) as z:
        d = {k: z[k].copy() for k in z.files}
    required = ['features','target','utilities','episode_ids','steps','conditions',
                'action_order','feature_definition','target_definition','sisdr_scale_db','stoi_scale']
    if any(k not in d for k in required):
        raise ValueError('Missing NPZ fields')
    n = len(d['target'])
    if not n or d['features'].ndim != 2 or d['features'].shape[0] != n or d['features'].shape[1] < 3:
        raise ValueError('Invalid features')
    if str(d['feature_definition']) != 'full_context_visual_encoder_segment_mean_plus_audio_proxy_v2':
        raise ValueError('Unexpected feature order/definition')
    if d['action_order'].tolist() != list(ACTIONS) or d['utilities'].shape != (n,3):
        raise ValueError('Unexpected utility action order or shape')
    if not np.isfinite(d['features']).all() or not np.isfinite(d['utilities']).all():
        raise ValueError('Nonfinite features/utilities')
    keys = list(zip(d['episode_ids'].astype(str), d['steps'].astype(int), d['conditions'].astype(str)))
    if len(set(keys)) != n:
        raise ValueError('Duplicate NPZ decision keys')
    with open(csv_path, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    index = {}
    group_fold = {}
    for r in rows:
        k = (r['episode_id'], int(r['step']), r['condition'])
        if k in index:
            raise ValueError('Duplicate prediction keys')
        fold = int(r['fold'])
        if require_oof and fold < 0:
            raise ValueError('Training must use OOF predictions')
        if not require_oof and fold != -1:
            raise ValueError('Validation must use external-validation predictions')
        if k[0] in group_fold and group_fold[k[0]] != fold:
            raise ValueError('Clip spans multiple confidence folds')
        group_fold[k[0]] = fold
        index[k] = r
    if set(index) != set(keys):
        raise ValueError('Confidence predictions and NPZ keys differ')
    confidence = np.asarray([float(index[k]['visual_confidence']) for k in keys], dtype=np.float32)
    labels = np.asarray([float(index[k]['target']) for k in keys])
    if not np.array_equal(labels, d['target']):
        raise ValueError('Confidence labels differ from NPZ')
    if not np.isfinite(confidence).all() or np.any((confidence<0)|(confidence>1)):
        raise ValueError('Invalid confidence predictions')
    if require_oof and len(set(group_fold.values())) < 2:
        raise ValueError('At least two OOF folds required')
    # Builder stores the two audio-only inputs at the end of each feature vector.
    d['router_features'] = np.column_stack([d['features'][:,-2:], confidence]).astype(np.float32)
    d['selection_labels'] = np.argmax(d['utilities'], axis=1).astype(np.int64)
    return d

def assemble(data, manifest_path, out, split):
    with open(manifest_path, newline='', encoding='utf-8-sig') as f:
        manifest = list(csv.DictReader(f))
    original = {}
    for row in manifest:
        key = (row['episode_id'], int(row['step']))
        if key in original:
            raise ValueError(f'Duplicate manifest step: {key}')
        start, end = int(row['center_start_sample']), int(row['center_end_sample'])
        if not 0 <= start < end <= 48000:
            raise ValueError(f'Invalid segment bounds: {key}')
        original[key] = (start, end)
    if not original:
        raise ValueError('Empty source manifest')
    conditions = sorted(set(data['conditions'].tolist()))
    by_group = {}
    for i, (episode, step, condition) in enumerate(zip(data['episode_ids'],data['steps'],data['conditions'])):
        key = (str(episode), int(step))
        if key not in original:
            raise ValueError(f'Cached sample not in original manifest: {key}')
        by_group.setdefault((str(episode),str(condition)),[]).append(i)
    runs = []
    for (episode,condition), indices in sorted(by_group.items()):
        indices.sort(key=lambda i:int(data['steps'][i]))
        current = []
        for i in indices:
            step = int(data['steps'][i]); start,end = original[(episode,step)]
            if current:
                previous_step = int(data['steps'][current[-1]])
                previous_end = original[(episode,previous_step)][1]
                if step != previous_step+1 or start != previous_end:
                    runs.append((episode,condition,current));current=[]
            current.append(i)
        if current:runs.append((episode,condition,current))
    index = np.asarray([i for _,_,run in runs for i in run],dtype=np.int64)
    if len(index)!=len(data['target']) or len(set(index.tolist()))!=len(index):
        raise ValueError('Episode assembly lost or duplicated valid rows')
    lengths = np.asarray([len(run) for _,_,run in runs],dtype=np.int64)
    offsets = np.concatenate([np.array([0],dtype=np.int64),np.cumsum(lengths)])
    bounds = np.asarray([original[(str(data['episode_ids'][i]),int(data['steps'][i]))] for i in index],dtype=np.int64)
    utilities=data['utilities'][index]
    rewards=utilities-utilities[:,2:3]
    if not np.isfinite(rewards).all() or not np.all(rewards[:,2]==0):
        raise ValueError('Invalid relative rewards')
    np.savez_compressed(out/f'{split}_episodes.npz',
        observations=data['router_features'][index], action_rewards=rewards.astype(np.float32),
        utilities=utilities, offsets=offsets, lengths=lengths,
        episode_ids=data['episode_ids'][index],steps=data['steps'][index],conditions=data['conditions'][index],
        segment_bounds=bounds, run_source_ids=np.asarray([g for g,c,r in runs]),
        run_conditions=np.asarray([c for g,c,r in runs]),
        action_order=np.asarray(ACTIONS),observation_names=np.asarray(['snr_proxy','snr_proxy_delta','visual_confidence']),
        sisdr_scale_db=data['sisdr_scale_db'],stoi_scale=data['stoi_scale'],
        reward_definition='(SI-SDR_action-SI-SDR_NSE)/sisdr_scale+(STOI_action-STOI_NSE)/stoi_scale',
        normalization='raw; PPO must fit normalization on training observations only',
        episode_scope='contiguous valid runs; filtered pilot, not full utterances')
    retained={(str(data['episode_ids'][i]),int(data['steps'][i]),str(data['conditions'][i])) for i in index}
    missing=[dict(episode_id=e,step=s,condition=c,reason='not_in_valid_confidence_dataset;run_break_required')
             for e,s in sorted(original) for c in conditions if (e,s,c) not in retained]
    with (out/f'{split}_excluded_steps.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['episode_id','step','condition','reason']);w.writeheader();w.writerows(missing)
    stats=dict(valid_steps=len(index),runs=len(runs),unique_source_clips=len(set(data['episode_ids'].tolist())),
        excluded_steps=len(missing),run_length_counts={str(v):int(np.sum(lengths==v)) for v in np.unique(lengths)},
        multi_step_runs=int(np.sum(lengths>1)),conditions=conditions)
    print(f'{split}: {json.dumps(stats)}',flush=True)
    return stats


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',required=True);p.add_argument('--validation',required=True)
    p.add_argument('--train-confidence',required=True);p.add_argument('--validation-confidence',required=True)
    p.add_argument('--train-manifest',required=True);p.add_argument('--validation-manifest',required=True)
    p.add_argument('--out-dir',required=True)
    args=p.parse_args();out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Use an empty output directory')
    train=load_split(args.train,args.train_confidence,True)
    validation=load_split(args.validation,args.validation_confidence,False)
    if set(train['episode_ids']) & set(validation['episode_ids']):raise ValueError('Train/validation source clip overlap')
    for key in ['sisdr_scale_db','stoi_scale','target_definition','feature_definition']:
        if not np.array_equal(train[key],validation[key]):raise ValueError(f'Dataset mismatch: {key}')
    out.mkdir(parents=True,exist_ok=True)
    report={'train':assemble(train,args.train_manifest,out,'train'),
            'validation':assemble(validation,args.validation_manifest,out,'validation')}
    report['protocol']={
        'base_observations':['snr_proxy','snr_proxy_delta','visual_confidence'],
        'policy_state':'3 standardized observations + 3-dimensional previous-action one-hot',
        'initial_previous_action':'all zeros, including after a gap; no first-step switching cost',
        'audio_delta':'stored noisy-input delta preserved; no clean-reference or utility input',
        'reward':'cached utility improvement over NSE minus lambda_switch * changed_action',
        'switching_cost':'set explicitly at PPO training; not applied in this preparation',
        'compute_cost':'none; requires measured costs before adding compute-aware reward',
        'missing_steps':'excluded with audit; split at every missing step or nonadjacent sample bound',
        'scope':'static-corruption runs, maximum original context 3 seconds; no waveform stitching',
        'limitations':['clip-grouped confidence OOF, not end-to-end expert cross-fitting',
                       'filtered valid subset; exclusions may bias results',
                       'one-step runs provide no temporal-switching evidence',
                       'speaker/source-recording separation unverified']}
    (out/'episode_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(f'Prepared {out}/train_episodes.npz and validation_episodes.npz')
    print('Next: PPO training and matched switching-cost baseline evaluation. No policy trained by this script.')


if __name__=='__main__':main()
