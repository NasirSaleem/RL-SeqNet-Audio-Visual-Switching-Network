from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from torch.distributions import Categorical

from rl_msnet.routing.policy import ActorCritic


def load_data(path: str):
    z = np.load(path)
    states = np.asarray(z["states"], dtype=np.float32)
    utilities = np.asarray(z["utilities"], dtype=np.float32)
    lengths = np.asarray(z["lengths"], dtype=np.int64)
    if states.ndim != 3 or utilities.shape != (*states.shape[:2], 3):
        raise ValueError("Expected states [N,T,D] and utilities [N,T,3]")
    if lengths.shape != (states.shape[0],) or np.any(lengths < 1) or np.any(lengths > states.shape[1]):
        raise ValueError("lengths must contain one valid sequence length per episode")
    if not np.isfinite(states).all() or not np.isfinite(utilities).all():
        raise ValueError("Input arrays contain NaN or Inf")
    return states, utilities, lengths


def gae(rewards, values, lengths, gamma, lam):
    n, tmax = rewards.shape
    adv = torch.zeros_like(rewards)
    carry = torch.zeros(n, dtype=rewards.dtype, device=rewards.device)
    for t in reversed(range(tmax)):
        if t + 1 < tmax:
            alive_next = (lengths > (t + 1)).to(rewards.dtype)
            next_value = values[:, t + 1]
        else:
            alive_next = torch.zeros(n, dtype=rewards.dtype, device=rewards.device)
            next_value = torch.zeros(n, dtype=rewards.dtype, device=rewards.device)
        alive = (lengths > t).to(rewards.dtype)
        delta = rewards[:, t] + gamma * next_value * alive_next - values[:, t]
        carry = (delta + gamma * lam * alive_next * carry) * alive
        adv[:, t] = carry
    return adv, adv + values


def run_seed(args, seed: int, states_np, utilities_np, lengths_np):
    torch.manual_seed(seed)
    np.random.seed(seed)
    device = torch.device(args.device)
    n_episodes, max_steps, state_dim = states_np.shape
    valid_np = np.arange(max_steps)[None, :] < lengths_np[:, None]
    train_states = states_np[valid_np]
    mean = train_states.mean(axis=0).astype(np.float32)
    std = train_states.std(axis=0).astype(np.float32)
    std = np.maximum(std, 1e-5)
    normalized = np.clip((states_np - mean) / std, -10.0, 10.0)

    states_all = torch.as_tensor(normalized, dtype=torch.float32, device=device)
    utility_all = torch.as_tensor(utilities_np, dtype=torch.float32, device=device)
    lengths_all = torch.as_tensor(lengths_np, dtype=torch.long, device=device)
    costs = torch.as_tensor(args.action_costs, dtype=torch.float32, device=device)

    policy = ActorCritic(state_dim=state_dim, hidden_dim=args.hidden_dim).to(device)
    optimizer = torch.optim.Adam(policy.parameters(), lr=args.learning_rate)
    save_dir = Path(args.out)
    save_dir.mkdir(parents=True, exist_ok=True)

    for update in range(1, args.total_updates + 1):
        count = min(args.rollout_episodes, n_episodes)
        idx = torch.randint(0, n_episodes, (count,), device=device)
        s = states_all[idx]
        u = utility_all[idx]
        lens = lengths_all[idx]
        valid = torch.arange(max_steps, device=device)[None, :] < lens[:, None]

        old_actions = torch.zeros((count, max_steps), dtype=torch.long, device=device)
        old_logp = torch.zeros((count, max_steps), dtype=torch.float32, device=device)
        values = torch.zeros((count, max_steps), dtype=torch.float32, device=device)
        rewards = torch.zeros((count, max_steps), dtype=torch.float32, device=device)
        previous = torch.full((count,), 2, dtype=torch.long, device=device)  # Initial action: NSE.

        with torch.no_grad():
            for t in range(max_steps):
                logits, value = policy(s[:, t], previous)
                dist = Categorical(logits=logits)
                action = dist.sample()
                lp = dist.log_prob(action)
                active = valid[:, t]
                # Padded steps are ignored; keep previous action unchanged there.
                action = torch.where(active, action, previous)
                lp = torch.where(active, lp, torch.zeros_like(lp))
                q = u[:, t].gather(1, action[:, None]).squeeze(1)
                # Apply measured compute cost and switching cost directly.
                reward = q - args.lambda_compute * costs[action]
                if t > 0:
                    reward = reward - args.lambda_switch * (action != previous).float()
                reward = torch.where(active, reward, torch.zeros_like(reward))
                old_actions[:, t] = action
                old_logp[:, t] = lp
                values[:, t] = value
                rewards[:, t] = reward
                previous = torch.where(active, action, previous)

        advantages, returns = gae(rewards, values, lens, args.gamma, args.gae_lambda)
        flat_mask = valid.reshape(-1)
        flat_states = s.reshape(-1, state_dim)[flat_mask]
        flat_prev = torch.cat([
            torch.full((count, 1), 2, dtype=torch.long, device=device),
            old_actions[:, :-1],
        ], dim=1).reshape(-1)[flat_mask]
        flat_actions = old_actions.reshape(-1)[flat_mask]
        flat_logp = old_logp.reshape(-1)[flat_mask]
        flat_adv = advantages.reshape(-1)[flat_mask]
        flat_returns = returns.reshape(-1)[flat_mask]
        flat_adv = (flat_adv - flat_adv.mean()) / (flat_adv.std(unbiased=False) + 1e-8)

        order = torch.randperm(flat_states.shape[0], device=device)
        for _ in range(args.ppo_epochs):
            order = order[torch.randperm(order.numel(), device=device)]
            for start in range(0, order.numel(), args.minibatch_size):
                mb = order[start:start + args.minibatch_size]
                logits, value = policy(flat_states[mb], flat_prev[mb])
                dist = Categorical(logits=logits)
                new_logp = dist.log_prob(flat_actions[mb])
                ratio = (new_logp - flat_logp[mb]).exp()
                unclipped = ratio * flat_adv[mb]
                clipped = torch.clamp(ratio, 1.0 - args.clip_epsilon,
                                      1.0 + args.clip_epsilon) * flat_adv[mb]
                policy_loss = -torch.minimum(unclipped, clipped).mean()
                value_loss = 0.5 * (value - flat_returns[mb]).pow(2).mean()
                entropy = dist.entropy().mean()
                loss = (policy_loss + args.value_coefficient * value_loss
                        - args.entropy_coefficient * entropy)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(policy.parameters(), args.gradient_clip_norm)
                optimizer.step()

        if update % args.log_every == 0 or update == 1:
            mean_reward = (rewards * valid).sum() / valid.sum().clamp_min(1)
            print(f"seed={seed} update={update} mean_step_reward={mean_reward.item():.4f}")

    checkpoint = save_dir / f"seed_{seed}.pt"
    torch.save({
        "policy_state_dict": policy.state_dict(),
        "state_dim": state_dim,
        "hidden_dim": args.hidden_dim,
        "state_mean": mean,
        "state_std": std,
        "action_names": ["AOSE", "AVSE", "NSE"],
        "action_costs": np.asarray(args.action_costs, dtype=np.float32),
        "seed": seed,
        "training_args": vars(args),
    }, checkpoint)
    print(f"saved {checkpoint}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="NPZ with states, utilities, lengths")
    p.add_argument("--out", default="checkpoints")
    p.add_argument("--seeds", default="11,22,33,44,55")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--action-costs", nargs=3, type=float, required=True,
                   metavar=("AOSE", "AVSE", "NSE"), help="Measured normalized costs")
    p.add_argument("--lambda-compute", type=float, required=True)
    p.add_argument("--lambda-switch", type=float, required=True)
    p.add_argument("--hidden-dim", type=int, default=128)
    p.add_argument("--learning-rate", type=float, default=3e-4)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--gae-lambda", type=float, default=0.95)
    p.add_argument("--clip-epsilon", type=float, default=0.20)
    p.add_argument("--entropy-coefficient", type=float, default=0.01)
    p.add_argument("--value-coefficient", type=float, default=0.50)
    p.add_argument("--gradient-clip-norm", type=float, default=0.50)
    p.add_argument("--ppo-epochs", type=int, default=10)
    p.add_argument("--minibatch-size", type=int, default=256)
    p.add_argument("--rollout-episodes", type=int, default=32)
    p.add_argument("--total-updates", type=int, default=1000)
    p.add_argument("--log-every", type=int, default=20)
    args = p.parse_args()
    if len(args.action_costs) != 3 or min(args.action_costs) < 0:
        p.error("Provide three non-negative measured action costs")
    states, utilities, lengths = load_data(args.data)
    for seed in (int(x) for x in args.seeds.split(",") if x.strip()):
        run_seed(args, seed, states, utilities, lengths)


if __name__ == "__main__":
    main()
