from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from rl_msnet.reliability.visual_confidence import VisualReliabilityEstimator


def read_npz(path):
    z = np.load(path)
    x = np.asarray(z["features"], dtype=np.float32)
    y = np.asarray(z["target"], dtype=np.float32).reshape(-1)
    if x.ndim != 2 or x.shape[0] != y.shape[0] or np.any((y < 0) | (y > 1)):
        raise ValueError("Expected features [N,D] and target probabilities [N] in [0,1]")
    return x, y


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--train", required=True, help="NPZ: frozen visual embeddings + audio context + targets")
    p.add_argument("--validation", required=True, help="Speaker-disjoint validation NPZ")
    p.add_argument("--out", required=True)
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--learning-rate", type=float, default=1e-3)
    p.add_argument("--seed", type=int, default=11)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device(args.device)
    x_train, y_train = read_npz(args.train)
    x_val, y_val = read_npz(args.validation)
    if x_train.shape[1] != x_val.shape[1]:
        p.error("Training and validation feature dimensions differ")
    mean = x_train.mean(axis=0).astype(np.float32)
    std = np.maximum(x_train.std(axis=0), 1e-5).astype(np.float32)
    x_train = np.clip((x_train - mean) / std, -10, 10)
    x_val = np.clip((x_val - mean) / std, -10, 10)
    train_loader = DataLoader(
        TensorDataset(torch.from_numpy(x_train), torch.from_numpy(y_train)),
        batch_size=args.batch_size, shuffle=True, drop_last=False,
    )
    xv = torch.from_numpy(x_val).to(device)
    yv = torch.from_numpy(y_val).to(device)
    model = VisualReliabilityEstimator(input_dim=x_train.shape[1]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)
    criterion = nn.BCEWithLogitsLoss()
    best_brier = float("inf")
    best = None
    for epoch in range(1, args.epochs + 1):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            loss = criterion(model(xb), yb)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        model.eval()
        with torch.no_grad():
            prob = torch.sigmoid(model(xv))
            brier = torch.mean((prob - yv).pow(2)).item()
            loss_val = criterion(model(xv), yv).item()
        print(f"epoch={epoch} val_brier={brier:.6f} val_bce={loss_val:.6f}")
        if brier < best_brier:
            best_brier = brier
            best = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "state_dict": best,
        "input_dim": x_train.shape[1],
        "hidden_dim": 128,
        "dropout": 0.2,
        "feature_mean": mean,
        "feature_std": std,
        "best_validation_brier": best_brier,
        "seed": args.seed,
    }, out)
    print(f"saved {out} (best validation Brier={best_brier:.6f})")


if __name__ == "__main__":
    main()
