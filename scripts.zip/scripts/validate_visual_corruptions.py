"""Prepare and optionally evaluate a paired visual-corruption validation pilot.

Audio is unchanged. Occlusion is a random image block, NOT verified lip occlusion.
No true head-pose simulation or RL routing evaluation is claimed.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,os,subprocess,sys
from pathlib import Path
import numpy as np
from scipy.ndimage import convolve1d


def transform(frames,kind,severity,seed):
    if frames.ndim!=4 or frames.shape[:2]!=(1,75):
        raise ValueError(f'Expected grayscale [1,75,H,W], got {frames.shape}')
    if not np.isfinite(frames).all() or frames.min()<0 or frames.max()>1:
        raise ValueError('Frames must be finite and in [0,1]')
    if kind=='motion_blur':
        # Horizontal linear exposure kernel, odd length scaled to image width.
        length=max(3,int(round(frames.shape[-1]*0.10*severity))|1)
        return convolve1d(frames,np.ones(length,dtype=np.float32)/length,axis=-1,mode='reflect')
    if kind=='visual_dropout':return np.zeros_like(frames)
    x=frames.copy();rng=np.random.default_rng(seed)
    if kind=='low_light':
        x=x**(1+2*severity)*(1-.8*severity)
    elif kind=='occlusion':
        h,w=x.shape[-2:]
        oh=max(1,int(h*(.05+.45*severity)));ow=max(1,int(w*(.05+.45*severity)))
        y0=int(rng.integers(0,h-oh+1));x0=int(rng.integers(0,w-ow+1))
        x[:,:,y0:y0+oh,x0:x0+ow]=0
    elif kind=='frame_drop':
        dropped=rng.random(x.shape[1])<(.05+.65*severity)
        for i in np.flatnonzero(dropped):x[:,i]=x[:,i-1] if i else 0
    else:raise ValueError(f'Unknown corruption {kind}')
    return np.clip(x,0,1).astype(np.float32)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',default='data/rl_msnet_prepared/manifests/validation.csv')
    p.add_argument('--out-dir',default='outputs/visual_corruption_validation')
    p.add_argument('--severity',type=float,default=0.6)
    p.add_argument('--seed',type=int,default=1143)
    p.add_argument('--run-evaluation',action='store_true')
    p.add_argument('--aose',default='outputs/aose_finetune/AOSE_adapted.ckpt')
    p.add_argument('--aose-source',default='third_party/aose')
    p.add_argument('--avse-checkpoint',default='weights/avse/AVSE.ckpt')
    p.add_argument('--avse-source',default='third_party/cross_avse')
    p.add_argument('--device',default='cuda')
    args=p.parse_args()
    if not 0<args.severity<=1:p.error('Severity must be in (0,1]')
    root=Path(args.out_dir).resolve()
    if root.exists() and any(root.iterdir()):p.error('Choose an empty --out-dir to preserve earlier runs')
    root.mkdir(parents=True,exist_ok=True)
    with open(args.manifest,newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f);fields=list(reader.fieldnames or []);rows=list(reader)
    required={'episode_id','step','noisy_wav','clean_wav','video_npy'}
    if not rows or not required.issubset(fields):raise ValueError('Empty or incomplete manifest')
    keys=[(r['episode_id'],r['step']) for r in rows]
    if len(set(keys))!=len(keys):raise ValueError('Duplicate decision keys')
    for name in ['corruption','corruption_severity','corruption_seed']:
        if name not in fields:fields.append(name)
    conditions=['clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout']
    (root/'protocol.json').write_text(json.dumps({**vars(args),'conditions':conditions,
        'scope':'validation pilot, central-segment metrics',
        'occlusion':'random image block; not guaranteed mouth occlusion',
        'motion_blur':'horizontal uniform exposure kernel; length=max(3, round(width*0.10*severity) made odd)',
        'visual_dropout':'all frames zero, independent of severity',
        'head_pose':'not evaluated','selection_ratios':'no RL policy evaluated'},indent=2),encoding='utf-8')
    manifests=[]
    for kind in conditions:
        directory=root/kind;directory.mkdir()
        replacements={};written=[]
        for row in rows:
            r=dict(row)
            # Preserve waveform bytes and preprocessing for every condition.
            for k in ['noisy_wav','clean_wav']:r[k]=str(Path(r[k]).resolve())
            path=Path(row['video_npy']).resolve()
            if not path.is_file():raise FileNotFoundError(path)
            identity=str(path)
            if identity not in replacements:
                digest=hashlib.sha256((str(args.seed)+'|'+kind+'|'+identity).encode()).hexdigest()
                seed=int(digest[:8],16)
                if kind=='clean':new_path=path
                else:
                    frames=np.load(path,allow_pickle=False).astype(np.float32)
                    result=transform(frames,kind,args.severity,seed)
                    new_path=directory/(digest[:16]+'.npy')
                    np.save(new_path,result.astype(np.float32),allow_pickle=False)
                replacements[identity]=(str(new_path),seed)
            r['video_npy'],r['corruption_seed']=replacements[identity]
            r['corruption']=kind;r['corruption_severity']=0 if kind=='clean' else (1 if kind=='visual_dropout' else args.severity)
            written.append(r)
        manifest=directory/'manifest.csv'
        with manifest.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(written)
        manifests.append((kind,manifest))
        print(f'Prepared {kind}: {len(written)} rows, {len(replacements)} unique videos',flush=True)
    if not args.run_evaluation:
        print('Manifests prepared. Evaluation was not requested.');return
    env=os.environ.copy()
    env['TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD']='1' # User-owned archived checkpoints.
    summary=[];baseline=None
    for kind,manifest in manifests:
        output=manifest.parent/'metrics.csv'
        command=[sys.executable,'scripts/precompute_candidates.py','--manifest',str(manifest),
            '--aose',args.aose,'--aose-source',args.aose_source,
            '--avse-checkpoint',args.avse_checkpoint,'--avse-source',args.avse_source,
            '--out',str(output),'--device',args.device]
        print(f'Evaluating {kind}',flush=True);subprocess.run(command,env=env,check=True)
        with output.open(newline='',encoding='utf-8-sig') as f:metrics=list(csv.DictReader(f))
        indexed={(r['episode_id'],r['step']):r for r in metrics}
        if len(metrics)!=len(keys) or set(indexed)!=set(keys):raise ValueError('Evaluation keys differ from manifest')
        if kind=='clean':baseline=indexed
        else:
            for key,r in indexed.items():
                for a in ['aose','nse']:
                    for m in ['pesq','stoi','sisdr']:
                        k=f'{m}_{a}';v,b=r.get(k,''),baseline[key].get(k,'')
                        if bool(v)!=bool(b) or (v and not np.isclose(float(v),float(b),atol=1e-5,rtol=1e-5)):
                            raise ValueError(f'Audio-only result changed under visual corruption: {kind} {key} {k}')
        for m in ['pesq','stoi','sisdr']:
            # Identical rows for all actions within each condition/metric.
            eligible=[r for r in metrics if all(r.get(f'{m}_valid_{a}')=='1' and r.get(f'{m}_{a}','') and np.isfinite(float(r[f'{m}_{a}'])) for a in ['aose','avse','nse'])]
            for a in ['aose','avse','nse']:
                values=[float(r[f'{m}_{a}']) for r in eligible]
                summary.append({'condition':kind,'metric':m,'action':a,'valid_segments':len(values),
                                'total_segments':len(metrics),'mean':float(np.mean(values)) if values else ''})
    with (root/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    print(f'Done: {root / "summary.csv"}')
    print('Segment diagnostics only. No router, confidence calibration, true pose or full-utterance evaluation yet.')

if __name__=='__main__':main()
