import torch
import soundfile as sf
import numpy as np


def load_and_test_model():
    """Load and test the exported model"""

    # Load the TorchScript model
    model = torch.jit.load("speech_enhancer.pt")
    model.eval()

    print("Model loaded successfully!")

    # Test with random audio
    print("\nTesting with random audio...")
    test_audio = torch.randn(1, 16000)  # 1 second of random audio
    enhanced_audio = model(test_audio, test_audio)

    print(f"Input shape: {test_audio.shape}")
    print(f"Output shape: {enhanced_audio.shape}")
    print(f"Input range: [{test_audio.min():.3f}, {test_audio.max():.3f}]")
    print(f"Output range: [{enhanced_audio.min():.3f}, {enhanced_audio.max():.3f}]")

    # Test with a real audio file (if you have one)
    # audio, sr = sf.read("your_audio.wav")
    # audio_tensor = torch.from_numpy(audio).float().unsqueeze(0)
    # enhanced = model(audio_tensor, audio_tensor)
    # enhanced_np = enhanced.squeeze().numpy()
    # sf.write("enhanced_audio.wav", enhanced_np, sr)

    return model


if __name__ == "__main__":
    model = load_and_test_model()