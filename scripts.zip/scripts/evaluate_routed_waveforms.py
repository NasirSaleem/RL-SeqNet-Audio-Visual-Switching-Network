"""Evaluate reconstructed 3-second validation clips, NOT full source utterances.

Uses saved decisions and reruns frozen experts to obtain aligned waveforms.
Cross-fade is a post-processing ablation, not part of PPO's cached reward.
This runs all experts, so it is NOT a measurement of conditional-routing cost.
"""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path,PureWindowsPath
import numpy as np
import soundfile as sf
import torch
from rl_msnet.experts.adapters import AOSEExpert,load_avse_checkpoint,run_avse
from precompute_candidates import read_mono,score_pair
ACTIONS=('aose','avse','nse')
STATIC=('clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout')
DYNAMIC=('clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean')


def resolve_file(value,prepared_root):
    path=Path(value)
    if path.is_file():return path
    parts=PureWindowsPath(value).parts
    if 'rl_msnet_prepared' in parts:
        candidate=Path(prepared_root).joinpath(*parts[parts.index('rl_msnet_prepared')+1:])
        if candidate.is_file():return candidate
    raise FileNotFoundError(f'{value}; also checked prepared root {prepared_root}')


def reconstruct(experts,actions,fade_samples):
    if len(actions)!=3 or any(len(x)!=48000 for x in experts.values()):raise ValueError('Expected three one-second decisions and 48000 samples')
    y=np.concatenate([experts[a][i*16000:(i+1)*16000] for i,a in enumerate(actions)]).copy()
    if fade_samples:
        left=fade_samples//2;right=fade_samples-left
        for i in (1,2):
            if actions[i-1]==actions[i]:continue
            boundary=i*16000;start=boundary-left;end=boundary+right
            weight=np.linspace(0,1,end-start,dtype=np.float32)
            y[start:end]=(1-weight)*experts[actions[i-1]][start:end]+weight*experts[actions[i]][start:end]
    return y.astype(np.float32)


def read_decisions(path):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    result={}
    for r in rows:
        key=(r['episode_id'],int(r['step']),r['condition'])
        if key in result or r['action'] not in ACTIONS:raise ValueError(f'Invalid decisions in {path}')
        result[key]=r['action']
    return result


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def summarize(rows):
    base={(r['condition'],r['episode_id']):r for r in rows if r['model']=='always_avse'}
    result=[]
    variants=sorted({(r['model'],r['seed'],r['reconstruction']) for r in rows})
    for model,seed,reconstruction in variants:
        own=[r for r in rows if (r['model'],r['seed'],r['reconstruction'])==(model,seed,reconstruction)]
        for condition in ['all']+sorted({r['condition'] for r in own}):
            subset=[r for r in own if condition=='all' or r['condition']==condition]
            for metric in ('pesq','stoi','sisdr'):
                valid=[r for r in subset if r[metric+'_valid']==1 and base[(r['condition'],r['episode_id'])][metric+'_valid']==1]
                entry=dict(model=model,seed=seed,reconstruction=reconstruction,condition=condition,metric=metric,total_clips=len(subset),paired_valid_clips=len(valid),mean_score='',mean_always_avse='',paired_delta='',clip_mean_delta='',ci_low='',ci_high='')
                if valid:
                    vals=np.array([r[metric] for r in valid]);b=np.array([base[(r['condition'],r['episode_id'])][metric] for r in valid])
                    delta=vals-b;ids=np.array([r['episode_id'] for r in valid])
                    grouped=np.array([delta[ids==g].mean() for g in np.unique(ids)])
                    rng=np.random.default_rng(12345);draws=rng.choice(grouped,size=(2000,len(grouped)),replace=True).mean(axis=1)
                    lo,hi=np.quantile(draws,[.025,.975])
                    entry.update(mean_score=float(vals.mean()),mean_always_avse=float(b.mean()),paired_delta=float(delta.mean()),clip_mean_delta=float(grouped.mean()),ci_low=float(lo),ci_high=float(hi))
                result.append(entry)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--static-root',default='outputs/visual_corruption_validation')
    p.add_argument('--dynamic-root',default='outputs/dynamic_visual_validation')
    p.add_argument('--prepared-root',default='data/rl_msnet_prepared')
    p.add_argument('--ppo-dir',default='outputs/ppo_router_combined')
    p.add_argument('--utility-dir',default='outputs/utility_router_combined')
    p.add_argument('--out-dir',default='outputs/waveform_validation_combined')
    p.add_argument('--seeds',type=int,nargs='+',default=[11,22,33])
    p.add_argument('--crossfade-ms',type=float,default=10.0)
    p.add_argument('--audio-examples',type=int,default=1,help='Save first N clips per condition for listening')
    p.add_argument('--aose',default='outputs/aose_finetune/AOSE_adapted.ckpt');p.add_argument('--aose-source',default='third_party/aose')
    p.add_argument('--avse-checkpoint',default='weights/avse/AVSE.ckpt');p.add_argument('--avse-source',default='third_party/cross_avse')
    p.add_argument('--device',default='cuda');args=p.parse_args()
    fade=int(round(args.crossfade_ms*16))
    if not 2<=fade<=16000 or args.audio_examples<0:p.error('Crossfade must be 2..16000 samples; audio examples nonnegative')
    out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Choose an empty output directory')
    jobs=[];allkeys=set()
    for condition in STATIC+DYNAMIC:
        root=args.static_root if condition in STATIC else args.dynamic_root
        with (Path(root)/condition/'manifest.csv').open(newline='',encoding='utf-8-sig') as f:manifest=list(csv.DictReader(f))
        groups={}
        for r in manifest:groups.setdefault(r['episode_id'],[]).append(r)
        for number,(episode,group) in enumerate(sorted(groups.items())):
            group.sort(key=lambda r:int(r['step']))
            if [int(r['step']) for r in group]!=[0,1,2]:raise ValueError('Expected full three-step validation clips')
            for i,r in enumerate(group):
                if int(r['center_start_sample'])!=i*16000 or int(r['center_end_sample'])!=(i+1)*16000:raise ValueError('Incorrect segment bounds')
                allkeys.add((episode,i,condition))
            paths=[]
            for field in ['noisy_wav','clean_wav','video_npy']:
                resolved=[resolve_file(r[field],args.prepared_root).resolve() for r in group]
                if len(set(resolved))!=1:raise ValueError('Mixed source files within a clip')
                paths.append(resolved[0])
            jobs.append((condition,episode,number<args.audio_examples,paths))
    policies={}
    for name,folder in [('ppo',args.ppo_dir),('utility_router',args.utility_dir)]:
        for seed in args.seeds:
            decisions=read_decisions(Path(folder)/f'validation_predictions_seed_{seed}.csv')
            if set(decisions)!=allkeys:raise ValueError(f'{name} seed {seed}: prediction keys do not match all 10 conditions')
            policies[(name,seed)]=decisions
    aose=AOSEExpert(args.aose,args.device,source_dir=args.aose_source)
    avse=load_avse_checkpoint(args.avse_checkpoint,args.avse_source,args.device)
    out.mkdir(parents=True,exist_ok=True);results=[];cache={}
    for job_number,(condition,episode,save,paths) in enumerate(jobs,1):
        audio_path,clean_path,video_path=paths;cachekey=(str(audio_path),str(clean_path))
        if cachekey not in cache:
            noisy=read_mono(str(audio_path));clean=read_mono(str(clean_path))
            if len(noisy)!=48000 or len(clean)!=48000:raise ValueError('Expected 3-second prepared clips')
            with torch.inference_mode():ao=aose(noisy)
            cache[cachekey]=(noisy,clean,ao)
        noisy,clean,ao=cache[cachekey]
        frames=np.load(video_path,allow_pickle=False)
        with torch.inference_mode():av=run_avse(avse,noisy,frames)
        experts=dict(aose=ao,avse=av,nse=noisy)
        if any(not np.isfinite(x).all() or len(x)!=48000 for x in experts.values()):raise ValueError('Invalid expert waveform')
        variants=[('always_'+a,-1,'fixed',[a]*3,experts[a]) for a in ACTIONS]
        for (name,seed),decisions in policies.items():
            actions=[decisions[(episode,i,condition)] for i in range(3)]
            variants.append((name,seed,'hard',actions,reconstruct(experts,actions,0)))
            variants.append((name,seed,'crossfade',actions,reconstruct(experts,actions,fade)))
        if save:
            directory=out/'audio'/condition/episode;directory.mkdir(parents=True,exist_ok=True)
            sf.write(directory/'clean.wav',clean,16000,subtype='FLOAT')
        for name,seed,mode,actions,waveform in variants:
            measured=score_pair(clean,waveform,1e-6)
            boundaries=[16000,32000];switches=[i for i in [1,2] if actions[i]!=actions[i-1]]
            jump=[abs(float(waveform[b]-waveform[b-1])) for b in boundaries]
            error=[abs(float((waveform[b]-waveform[b-1])-(clean[b]-clean[b-1]))) for b in boundaries]
            row=dict(condition=condition,episode_id=episode,model=name,seed=seed,reconstruction=mode,
                actions='|'.join(actions),switches=len(switches),duration_seconds=3.0,
                mean_boundary_jump=float(np.mean(jump)),mean_boundary_reference_jump_error=float(np.mean(error)),
                peak=float(np.max(np.abs(waveform))),samples_above_one=int(np.sum(np.abs(waveform)>1)))
            for metric,(value,valid,reason) in measured.items():
                row[metric]=value;row[metric+'_valid']=valid;row[metric+'_reason']=reason
            results.append(row)
            if save:sf.write(directory/f'{name}_seed_{seed}_{mode}.wav',waveform,16000,subtype='FLOAT')
        if job_number%10==0:print(f'Waveforms scored: {job_number}/{len(jobs)} clips',flush=True)
    write_csv(out/'clip_metrics.csv',results);write_csv(out/'waveform_summary.csv',summarize(results))
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),scope='whole prepared 3-second clips, not complete source utterances',
        gain_policy='existing adapters, AVSE mixture_projection, no output clipping or additional peak normalization',
        crossfade='linear convex blend of time-aligned expert waveforms centered on each action boundary',
        crossfade_duration_samples=fade,crossfade_scope='posthoc ablation; no new router decisions',
        boundary_diagnostics='sample jump proxies only; not a validated perceptual artifact measure',
        timing='all experts run; no conditional-execution efficiency claim',
        padding='prepared 48000 samples retained; original utterance durations not available',
        statistics='paired source-clip bootstrap with corruption variants grouped; 2000 draws',
        selection='all three predetermined seeds; no best-seed selection'),indent=2),encoding='utf-8')
    print(f'Wrote {out}/waveform_summary.csv and clip_metrics.csv')
    print('Clip-level waveform validation complete. No model retraining performed.')


if __name__=='__main__':main()
