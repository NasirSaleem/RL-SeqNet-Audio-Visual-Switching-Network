from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from rl_msnet.experts.adapters import load_avse_checkpoint
from rl_msnet.reliability.visual_confidence import VisualReliabilityEstimator


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--manifest", required=True)
    p.add_argument("--confidence-checkpoint", required=True)
    p.add_argument("--avse-checkpoint", required=True)
    p.add_argument("--avse-source", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--mc-samples", type=int, default=20)
    p.add_argument("--device", default="cuda")
    args = p.parse_args()
    device = torch.device(args.device if args.device != "auto" else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    ckpt = torch.load(args.confidence_checkpoint, map_location=device, weights_only=False)
    avse = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, str(device))
    estimator = VisualReliabilityEstimator(ckpt["input_dim"], ckpt["hidden_dim"], ckpt["dropout"]).to(device)
    estimator.load_state_dict(ckpt["state_dict"])
    estimator.eval()
    mean = torch.as_tensor(ckpt["feature_mean"], dtype=torch.float32, device=device)
    std = torch.as_tensor(ckpt["feature_std"], dtype=torch.float32, device=device)
    with open(args.manifest, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    by_episode = defaultdict(list)
    for row in rows:
        frames = np.load(row["video_npy"], allow_pickle=False).astype(np.float32)
        x = torch.as_tensor(frames[None], dtype=torch.float32, device=device)
        with torch.inference_mode():
            emb = avse.model.visual_encoder(x).mean(dim=1)[0]
        audio = torch.tensor([float(row["snr_est_db"]), float(row["snr_delta_db"])],
                             dtype=torch.float32, device=device)
        features = torch.cat((emb, audio)).unsqueeze(0)
        features = torch.clamp((features - mean) / std, -10.0, 10.0)
        conf, uncertainty = estimator.predict_with_uncertainty(features, args.mc_samples)
        by_episode[row["episode_id"]].append((int(row["step"]), float(conf[0]), float(uncertainty[0])))
    output = Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["episode_id", "step", "visual_confidence", "visual_uncertainty", "visual_confidence_delta"])
        for episode, values in by_episode.items():
            values.sort()
            prev = None
            for step, conf, unc in values:
                writer.writerow([episode, step, conf, unc, 0.0 if prev is None else conf - prev])
                prev = conf
    print(f"Wrote confidence predictions: {output}")


if __name__ == "__main__":
    main()
