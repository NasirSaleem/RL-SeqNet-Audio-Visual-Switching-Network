from __future__ import annotations

import csv


DECISION_FIELDS = {
    "episode_id", "step", "noisy_wav", "clean_wav", "video_npy",
    "center_start_sample", "center_end_sample", "snr_est_db", "snr_delta_db",
    "visual_confidence", "visual_uncertainty", "visual_confidence_delta",
}


def read_decision_manifest(path: str):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = DECISION_FIELDS - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Manifest missing required fields: {sorted(missing)}")
        rows = list(reader)
    return rows
