from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
COLORS=['#0072B2','#D55E00','#009E73']
rows=list(csv.DictReader((ROOT/'data/ppo_training_log.csv').open()))
def save(fig,name):
 for ext in ('png','pdf','svg'):fig.savefig(ROOT/(name+'.'+ext),dpi=600,bbox_inches='tight',pad_inches=.1)
 plt.close(fig)
def smooth(v):return np.array([np.mean(v[max(0,i-9):i+1]) for i in range(len(v))])
def curves(ax,key):
 for seed,color in zip((11,22,33),COLORS):
  r=sorted([x for x in rows if int(x['seed'])==seed],key=lambda x:int(x['update']))
  x=np.array([int(a['update']) for a in r]);y=np.array([float(a[key]) for a in r]);assert len(x)==300 and np.isfinite(y).all()
  ax.plot(x,y,color=color,lw=.6,alpha=.22)
  ax.plot(x,smooth(y),color=color,lw=1.8,label=f'Seed {seed}')
 ax.set_xlabel('PPO update');ax.grid(alpha=.18);ax.set_xlim(1,300)
fig,axs=plt.subplots(1,2,figsize=(7.16,2.9),layout='constrained')
curves(axs[0],'rollout_mean_net_reward');curves(axs[1],'entropy')
axs[0].set_ylabel('Mean rollout net reward');axs[0].set_title('a) Training objective',loc='left',fontweight='bold');axs[0].axhline(0,ls=':',color='#888888',lw=.8)
axs[1].set_ylabel('Policy entropy (nats)');axs[1].set_title('b) Action uncertainty',loc='left',fontweight='bold');axs[1].axhline(np.log(3),ls='--',lw=.8,color='#777777')
axs[0].legend(frameon=False,loc='lower right')
fig.suptitle('Sequential router learning across three random seeds',fontsize=11,fontweight='bold')
save(fig,'PPO_Reward_and_Entropy')
fig,ax=plt.subplots(figsize=(7.16,2.6),layout='constrained');curves(ax,'loss');ax.set_ylabel('Logged combined PPO loss');ax.legend(frameon=False,ncol=3)
ax.set_title('PPO optimization diagnostic',fontweight='bold',loc='left')
save(fig,'PPO_Combined_Loss')
# Small timeline export prepared from observed predictions and saved observations.
r=list(csv.DictReader((ROOT/'data/timeline.csv').open()))
fig,axs=plt.subplots(3,1,figsize=(7.16,4.3),sharex=True,layout='constrained',gridspec_kw={'height_ratios':[1.7,1,1]})
conditions=['clean','dropout_clean_dropout'];labels=['Clean video','Dropout / clean / dropout']
for c,label,color in zip(conditions,labels,[COLORS[0],COLORS[1]]):
 q=sorted([a for a in r if a['condition']==c],key=lambda a:int(a['step']))
 axs[0].plot([.5,1.5,2.5],[float(a['visual_confidence']) for a in q],marker='o',lw=1.8,color=color,label=label)
axs[0].set_ylim(0,1.04);axs[0].set_ylabel('Predicted AVSE benefit');axs[0].legend(frameon=False,ncol=2,fontsize=8,loc='upper center',bbox_to_anchor=(.5,1.38));axs[0].grid(alpha=.18)
ac={'aose':0,'avse':1,'nse':2};palette={'aose':'#009E73','avse':'#0072B2','nse':'#737B85'}
for ax,c,label in zip(axs[1:],conditions,labels):
 q=sorted([a for a in r if a['condition']==c],key=lambda a:int(a['step']))
 for a in q:
  step=int(a['step']);action=a['action']
  ax.broken_barh([(step,1)],(0,.8),facecolors=palette[action],edgecolor='white',linewidth=1)
  ax.text(step+.5,.4,{'nse':'Bypass','avse':'AVSE','aose':'AOSE'}[action],ha='center',va='center',color='white',fontsize=10,fontweight='bold')
 ax.set_yticks([]);ax.set_ylim(0,.8);ax.set_ylabel('Clean' if c=='clean' else 'Changing',rotation=0,labelpad=30,va='center')
 if c!='clean':
  for step,t in enumerate(['Vision absent','Vision present','Vision absent']):ax.text(step+.5,-.30,t,ha='center',va='top',fontsize=8)
axs[2].set_xlabel('Decision interval within the prepared clip (s)',labelpad=28)
for ax in axs:ax.set_xlim(0,3);ax.set_xticks([0,1,2,3])
fig.suptitle('Observed routing example: S03627, PPO seed 11',fontsize=11,fontweight='bold')
save(fig,'PPO_Observed_Confidence_and_Actions')
