from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parents[1];O=P/'figures';O.mkdir(exist_ok=True)
r=list(csv.DictReader((P/'sources/waveform_summary(1).csv').open()))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
colors=['#0072B2','#D55E00','#009E73']
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(O/(name+'.'+ext),dpi=600,bbox_inches='tight',pad_inches=.12)
 plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(7.16,3.55),sharey=True,layout='constrained')
for ax,met,title in zip(axs,['pesq','stoi','sisdr'],['PESQ difference','STOI difference','SI-SDR difference (dB)']):
 for j,m in enumerate(['ppo','clip_router','utility_router']):
  for k,seed in enumerate([11,22,33]):
   row=next(a for a in r if a['model']==m and a['seed']==str(seed) and a['condition']=='all' and a['metric']==met and a['reconstruction']=='crossfade')
   y=2-j+(k-1)*.15;d=float(row['paired_delta']);lo=float(row['ci_low']);hi=float(row['ci_high'])
   ax.plot([lo,hi],[y,y],c=colors[k],lw=1.3);ax.plot(d,y,'o',c=colors[k],ms=4,label=f'Seed {seed}' if j==0 else None)
 ax.axvline(0,c='#555555',ls='--',lw=.9);ax.set_xlabel(title,fontsize=8);ax.grid(axis='x',alpha=.17);ax.tick_params(axis='x',labelsize=7)
axs[0].set_yticks([2,1,0],['PPO','Clip router','Utility router']);axs[0].set_ylim(-.45,3.05)
axs[1].legend(loc='upper center',frameon=False,ncol=1,fontsize=7)
fig.suptitle('Held-out differences versus always-AVSE',fontsize=11,fontweight='bold')
save(fig,'Heldout_Paired_Differences')
r=list(csv.DictReader((P/'sources/routing_proportions.csv').open()))
conditions=['clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout','clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean']
labels=['Clean','Occlusion','Motion blur','Low light','Frame drop','Visual dropout','Clean / dropout / clean','Dropout / clean / dropout','Clean / low light / clean','Clean / blur / clean']
fig,axs=plt.subplots(1,2,figsize=(7.16,4.3),sharey=True,layout='constrained')
for ax,m,title in zip(axs,['ppo','utility'],['PPO','Utility regression']):
 bottom=np.zeros(10)
 for key,label,col in zip(['p_aose','p_avse','p_nse'],['AOSE','AVSE','Bypass'],['#009E73','#0072B2','#939BA5']):
  v=np.array([np.mean([float(x[key]) for x in r if x['model']==m and x['condition']==c])*100 for c in conditions])
  ax.barh(np.arange(10),v,left=bottom,color=col,label=label,height=.7)
  for i,a in enumerate(v):
   if a>=10:ax.text(bottom[i]+a/2,i,f'{a:.0f}',ha='center',va='center',fontsize=7,color='white')
  bottom+=v
 ax.set_xlim(0,100);ax.set_xlabel('Nonempty decisions (%)');ax.set_title(title,fontweight='bold');ax.set_xticks([0,50,100])
axs[0].set_yticks(np.arange(10),labels,fontsize=8);axs[0].invert_yaxis();axs[1].legend(frameon=False,ncol=3,loc='lower center',bbox_to_anchor=(.35,1.12),fontsize=7)
fig.suptitle('Held-out pathway selection across visual conditions',fontsize=11,fontweight='bold')
save(fig,'Heldout_Routing_Allocation')
