from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','axes.titlesize':10,'xtick.labelsize':8,'ytick.labelsize':8})
BLUE='#0072B2';ORANGE='#D55E00';TEAL='#009E73'
# Exact epoch aggregates transcribed from the user's 30-epoch terminal log.
train=[.271172,.247805,.232781,.221550,.212377,.207892,.203762,.201652,.198153,.197550,.195823,.193071,.193936,.193590,.192040,.191592,.189501,.190238,.187440,.187627,.188124,.188280,.186245,.185762,.184510,.184749,.184737,.184784,.183218,.182703]
val=[.289539,.268059,.250735,.237918,.230978,.226364,.223412,.221533,.219108,.217528,.215998,.213980,.214539,.212272,.212207,.211076,.210549,.208774,.209340,.207666,.207104,.206478,.206633,.206216,.206034,.206131,.205543,.206291,.205212,.204289]
with (ROOT/'data'/'adaptation_loss_transcribed.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['epoch','training_loss','validation_loss']);w.writerow([0,'',.325492]);w.writerows(zip(range(1,31),train,val))
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(ROOT/(name+'.'+ext),dpi=600,bbox_inches='tight',pad_inches=.1)
 plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.16,2.8),layout='constrained')
for ax in axs:
 ax.plot(range(1,31),train,color=BLUE,lw=1.8,marker='o',ms=2.5,label='Training')
 ax.plot(range(31),[.325492]+val,color=ORANGE,lw=1.8,marker='s',ms=2.5,label='Validation')
 ax.grid(alpha=.18);ax.set_xlabel('Epoch');ax.set_ylabel('Reconstruction loss')
axs[0].set_title('a) Full adaptation trajectory',loc='left',fontweight='bold');axs[0].legend(frameon=False)
axs[0].annotate('Before adaptation: 0.3255',xy=(0,.325492),xytext=(5,.315),fontsize=8,arrowprops={'arrowstyle':'-','color':ORANGE})
axs[1].set_xlim(10,30.5);axs[1].set_ylim(.175,.225);axs[1].set_title('b) Later epochs (expanded scale)',loc='left',fontweight='bold')
fig.suptitle('AOSE adaptation: recorded training and validation losses',fontsize=11,fontweight='bold')
save(fig,'AOSE_Adaptation_Learning_Curves')
def read(n):return list(csv.DictReader((ROOT/'data'/n).open()))
a=read('validation_levelmatched.csv');b=read('validation_aose_adapted.csv');ai={(r['episode_id'],r['step']):r for r in a}
fig,axs=plt.subplots(1,3,figsize=(7.16,3.05),layout='constrained')
export=[]
for j,(ax,m) in enumerate(zip(axs,['pesq','stoi','sisdr'])):
 grouped={}
 for r in b:
  orig=ai[r['episode_id'],r['step']]
  if r[m+'_valid_aose']=='1' and orig[m+'_valid_aose']=='1':grouped.setdefault(r['episode_id'],[]).append((float(orig[m+'_aose']),float(r[m+'_aose'])))
 vals=np.array([np.mean(v,axis=0) for v in grouped.values()])
 for e,v in zip(grouped,vals):export.append([e,m,len(grouped[e]),*v,v[1]-v[0]])
 lo=float(vals.min());hi=float(vals.max());pad=(hi-lo)*.08
 ax.plot([lo-pad,hi+pad],[lo-pad,hi+pad],ls='--',color='#777777',lw=1,zorder=1)
 better=vals[:,1]>vals[:,0]
 ax.scatter(vals[better,0],vals[better,1],c=TEAL,s=30,edgecolor='white',linewidth=.5,label='Improved',zorder=2)
 ax.scatter(vals[~better,0],vals[~better,1],c=ORANGE,s=30,marker='s',edgecolor='white',linewidth=.5,label='Not improved',zorder=2)
 ax.set_xlim(lo-pad,hi+pad);ax.set_ylim(lo-pad,hi+pad);ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.15)
 ax.set_xlabel('Before adaptation');ax.set_ylabel('After adaptation' if j==0 else '')
 ax.set_title(['a) PESQ','b) STOI','c) SI-SDR (dB)'][j],loc='left',fontweight='bold')
 ax.text(.03,.97,f'{better.sum()}/{len(vals)} clips improved',transform=ax.transAxes,va='top',fontsize=8)
fig.suptitle('AOSE before and after adaptation: paired validation diagnostics',fontsize=10.5,fontweight='bold')
save(fig,'AOSE_Paired_Adaptation_Scores')
with (ROOT/'data'/'paired_clip_segment_means.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['episode_id','metric','paired_valid_segments','original_segment_mean','adapted_segment_mean','delta']);w.writerows(export)
print('Metric improvement counts:')
for m in ['pesq','stoi','sisdr']:
 v=[r for r in export if r[1]==m];print(m,sum(r[-1]>0 for r in v),'/',len(v))
