from __future__ import annotations

import argparse
import csv
from collections import defaultdict

import numpy as np

STATE_COLUMNS = (
    "snr_est_db",
    "snr_delta_db",
    "visual_confidence",
    "visual_uncertainty",
    "visual_confidence_delta",
)
ACTION_NAMES = ("aose", "avse", "nse")


def main():
    p = argparse.ArgumentParser(description="Pack per-segment metrics/features into PPO episode arrays")
    p.add_argument("--csv", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--sisdr-scale-db", type=float, required=True,
                   help="Validation-selected scale for SI-SDR gain")
    p.add_argument("--stoi-scale", type=float, required=True,
                   help="Validation-selected scale for STOI gain")
    p.add_argument("--stoi-weight", type=float, default=1.0)
    args = p.parse_args()
    if args.sisdr_scale_db <= 0 or args.stoi_scale <= 0:
        p.error("Metric scales must be positive")

    grouped = defaultdict(list)
    with open(args.csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        required = {"episode_id", "step", *STATE_COLUMNS}
        for name in ACTION_NAMES:
            required.update((f"sisdr_gain_{name}", f"stoi_gain_{name}"))
        missing = required - set(reader.fieldnames or [])
        if missing:
            p.error(f"Missing CSV columns: {sorted(missing)}")
        for row in reader:
            episode = row["episode_id"]
            step = int(row["step"])
            state = [float(row[k]) for k in STATE_COLUMNS]
            quality = []
            for name in ACTION_NAMES:
                sisdr = float(row[f"sisdr_gain_{name}"])
                stoi = float(row[f"stoi_gain_{name}"])
                quality.append(sisdr / args.sisdr_scale_db + args.stoi_weight * stoi / args.stoi_scale)
            grouped[episode].append((step, state, quality))

    if not grouped:
        p.error("CSV contains no transition rows")
    ordered = []
    for episode, rows in grouped.items():
        rows.sort(key=lambda x: x[0])
        if [x[0] for x in rows] != list(range(len(rows))):
            p.error(f"Episode {episode!r} must have contiguous zero-based steps")
        ordered.append(rows)
    max_steps = max(map(len, ordered))
    states = np.zeros((len(ordered), max_steps, len(STATE_COLUMNS)), dtype=np.float32)
    utilities = np.zeros((len(ordered), max_steps, 3), dtype=np.float32)
    lengths = np.zeros(len(ordered), dtype=np.int64)
    for i, rows in enumerate(ordered):
        lengths[i] = len(rows)
        for j, (_, state, quality) in enumerate(rows):
            states[i, j] = state
            utilities[i, j] = quality
    np.savez_compressed(args.out, states=states, utilities=utilities, lengths=lengths)
    print(f"Wrote {args.out}: episodes={len(ordered)}, max_steps={max_steps}, state_dim={states.shape[-1]}")


if __name__ == "__main__":
    main()
