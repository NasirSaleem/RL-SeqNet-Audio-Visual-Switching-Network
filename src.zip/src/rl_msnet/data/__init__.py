"""Manifest and segment helpers."""
