"""Frozen held-out inference. Saves small features/CSV decisions only.
No expert scoring, waveform copies, corruption generation, or model fitting.
Retains all three steps, including invalid-proxy/padded steps with explicit flags.
"""
import argparse,csv,json
from pathlib import Path
import numpy as np
import torch
from rl_msnet.experts.adapters import load_avse_checkpoint
from train_corruption_confidence import ConfidenceMLP
from train_supervised_router import Router as SupervisedRouter
from train_utility_router import Router as UtilityRouter
from train_ppo_router import ActorCritic, select
from train_clip_router import ClipRouter

ACTIONS=('aose','avse','nse')
STATIC=('clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout')
DYNAMIC=('clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean')


def read(path):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))


def write(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def load(path,model,device):
    ck=torch.load(path,map_location='cpu',weights_only=True)
    model.load_state_dict(ck['state_dict'],strict=True);model.to(device).eval()
    mean=ck['mean'].cpu().numpy();std=ck['std'].cpu().numpy()
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std<=0):raise ValueError('Invalid normalization')
    return model,ck,mean,std


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--static-root',default='outputs/visual_corruption_heldout')
    p.add_argument('--dynamic-root',default='outputs/dynamic_visual_heldout')
    p.add_argument('--audio-manifest',default='data/heldout_prepared_v2/manifests/test_features.csv')
    p.add_argument('--audit',default='data/heldout_prepared_v2/media_audit.csv')
    p.add_argument('--confidence',default='outputs/confidence_training_combined/visual_confidence.ckpt')
    p.add_argument('--supervised-dir',default='outputs/supervised_router_combined')
    p.add_argument('--utility-dir',default='outputs/utility_router_combined')
    p.add_argument('--ppo-dir',default='outputs/ppo_router_combined')
    p.add_argument('--clip-dir',default='outputs/supervised_clip_router')
    p.add_argument('--avse-checkpoint',default='weights/avse/AVSE.ckpt')
    p.add_argument('--avse-source',default='third_party/cross_avse')
    p.add_argument('--out-dir',default='outputs/heldout_predictions')
    p.add_argument('--device',default='cuda')
    args=p.parse_args();out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Choose an empty output folder')
    audio_rows=read(args.audio_manifest)
    audio={(r['episode_id'],int(r['step'])):r for r in audio_rows}
    if len(audio)!=len(audio_rows):raise ValueError('Duplicate audio keys')
    audit={r['episode_id']:r for r in read(args.audit)}
    jobs=[];rows=[]
    for condition in STATIC+DYNAMIC:
        root=args.static_root if condition in STATIC else args.dynamic_root
        manifest=read(Path(root)/condition/'manifest.csv')
        index={(r['episode_id'],int(r['step'])):r for r in manifest}
        if len(index)!=len(manifest) or set(index)!=set(audio):raise ValueError('Manifest key mismatch: '+condition)
        for episode in sorted({k[0] for k in index}):
            if sorted(k[1] for k in index if k[0]==episode)!=[0,1,2]:raise ValueError('Missing steps')
            group=[]
            for step in range(3):
                r=dict(index[episode,step]);a=audio[episode,step]
                for name in ('snr_est_db','snr_delta_db','snr_proxy_valid'):r[name]=a[name]
                if (int(r['center_start_sample']),int(r['center_end_sample']))!=(step*16000,(step+1)*16000):raise ValueError('Invalid bounds')
                seconds=min(3.,float(audit[episode]['noisy_seconds']))
                r.update(condition=condition,valid_audio_samples=max(0,min(16000,round(seconds*16000)-step*16000)),
                         full_context_unpadded=int(min(float(audit[episode]['noisy_seconds']),float(audit[episode]['video_seconds']))>=3))
                group.append(r)
            if len({r['video_npy'] for r in group})!=1:raise ValueError('Mixed video paths')
            if not Path(group[0]['video_npy']).is_file():raise FileNotFoundError(group[0]['video_npy'])
            jobs.append(group);rows.extend(group)
    meta=torch.load(args.confidence,map_location='cpu',weights_only=True)
    if meta['feature_definition']!='full_context_visual_encoder_segment_mean_plus_audio_proxy_v2':raise ValueError('Unexpected confidence features')
    if meta['target_definition']!='avse_utility_gt_max_aose_nse_binary_v1':raise ValueError('Unexpected confidence target')
    if {r['episode_id'] for r in rows}&set(meta['training_episode_ids']):raise ValueError('Confidence training overlap')
    specs=[]
    for seed in (11,22,33):
        for name,folder,filename,cls in [('supervised',args.supervised_dir,f'router_seed_{seed}.ckpt',SupervisedRouter),
            ('utility',args.utility_dir,f'utility_router_seed_{seed}.ckpt',UtilityRouter),
            ('ppo',args.ppo_dir,f'ppo_seed_{seed}.ckpt',ActorCritic),
            ('clip',args.clip_dir,f'clip_router_seed_{seed}.ckpt',ClipRouter)]:
            path=Path(folder)/filename
            if not path.is_file():raise FileNotFoundError(path)
            specs.append((name,seed,path,cls))
    cm,_,cm_mean,cm_std=load(args.confidence,ConfidenceMLP(meta['input_dim']),args.device)
    encoder=load_avse_checkpoint(args.avse_checkpoint,args.avse_source,args.device);encoder.eval()
    features=[]
    for n,group in enumerate(jobs,1):
        frames=np.load(group[0]['video_npy'],allow_pickle=False).astype(np.float32)
        if frames.shape!=(1,75,224,224) or not np.isfinite(frames).all():raise ValueError('Invalid frames')
        with torch.inference_mode():
            encoded=encoder.model.visual_encoder(torch.as_tensor(frames[None],device=args.device))[0].cpu().numpy()
        for step,r in enumerate(group):
            f=np.concatenate([encoded[step*25:(step+1)*25].mean(0),[float(r['snr_est_db']),float(r['snr_delta_db'])]]).astype(np.float32)
            if f.shape!=(meta['input_dim'],) or not np.isfinite(f).all():raise ValueError('Invalid features')
            features.append(f)
        if n%25==0 or n==len(jobs):print(f'Frozen visual features: {n}/{len(jobs)} clips',flush=True)
    del encoder
    if args.device.startswith('cuda'):torch.cuda.empty_cache()
    features=np.asarray(features);confidence=[]
    with torch.inference_mode():
        for start in range(0,len(features),256):
            x=(features[start:start+256]-cm_mean)/cm_std
            confidence.extend(torch.sigmoid(cm(torch.as_tensor(x,device=args.device))).cpu().numpy().tolist())
    obs=np.column_stack([features[:,-2:],confidence]).astype(np.float32)
    d=dict(offsets=np.arange(0,len(rows)+1,3),lengths=np.full(len(jobs),3))
    out.mkdir(parents=True,exist_ok=True)
    feature_rows=[]
    for i,r in enumerate(rows):
        feature_rows.append(dict(episode_id=r['episode_id'],step=int(r['step']),condition=r['condition'],
            snr_proxy=float(obs[i,0]),snr_proxy_delta=float(obs[i,1]),visual_confidence=float(obs[i,2]),
            snr_proxy_valid=int(r['snr_proxy_valid']),valid_audio_samples=r['valid_audio_samples'],
            full_context_unpadded=r['full_context_unpadded']))
    write(out/'state_features.csv',feature_rows)
    np.savez_compressed(out/'frozen_features.npz',features=features,observations=obs,
        episode_ids=np.array([r['episode_id'] for r in rows]),steps=np.array([int(r['step']) for r in rows]),
        conditions=np.array([r['condition'] for r in rows]),**d)
    summary=[]
    for name,seed,path,cls in specs:
        model,ck,mean,std=load(path,cls(),args.device)
        if list(ck['action_order'])!=list(ACTIONS):raise ValueError('Action order mismatch')
        x=obs.reshape(-1,9) if name=='clip' else obs
        normal=((x-mean)/std).astype(np.float32)
        if name=='ppo':actions=select(model,d,normal,args.device)
        else:
            with torch.inference_mode():pred=model(torch.as_tensor(normal,device=args.device)).cpu().numpy()
            if name=='utility':pred=np.column_stack([pred,np.zeros(len(pred))])
            actions=pred.argmax(1)
            if name=='clip':actions=np.repeat(actions,3)
        decisions=[dict(r,action=ACTIONS[int(a)]) for r,a in zip(feature_rows,actions)]
        write(out/name/f'test_predictions_seed_{seed}.csv',decisions)
        for condition in STATIC+DYNAMIC:
            ix=np.array([r['condition']==condition for r in rows])
            active=ix & np.array([r['valid_audio_samples']>0 for r in rows])
            a=actions[active]
            summary.append(dict(model=name,seed=seed,condition=condition,nonempty_segments=len(a),
                p_aose=float(np.mean(a==0)),p_avse=float(np.mean(a==1)),p_nse=float(np.mean(a==2))))
        print(f'Applied {name}, seed={seed}',flush=True)
    write(out/'routing_proportions.csv',summary)
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),training='none; saved checkpoints and normalization',
        scope='Predictions only. All three steps retained; no quality metrics or clean targets used for decisions.',
        padding='Existing finite audio-proxy placeholders retained and flagged. Pure padding excluded from routing proportions. Quality scoring must trim padding separately.',
        timing='Offline full-context visual features; no causal or execution-speed claim',
        primary_cohort='Report all clips with duration-aware scoring, plus unpadded-clip sensitivity analysis; do not delete short clips based on quality scores'),indent=2),encoding='utf-8')
    print(f'Finished: {out}. No training; no new videos or waveforms saved.')


if __name__=='__main__':main()
