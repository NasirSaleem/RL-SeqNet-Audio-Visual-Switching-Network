import logging
import os
import random
from os.path import join, isfile
import cv2
import numpy as np
import torch
from decord import VideoReader, cpu
from pytorch_lightning import LightningDataModule
from scipy.io import wavfile
from torch.utils.data import Dataset, DataLoader
from config import *

class AVSEDataset(Dataset):
    def __init__(self, scenes_root, shuffle=True, seed=SEED, subsample=1,
                 lips=False, rgb=False, test_set=False):
        super().__init__()
        self.img_width, self.img_height = (96, 96) if lips else (224, 224)
        self.lips = lips
        self.rgb = rgb
        self.test_set = test_set
        self.scenes_root = scenes_root
        self.files_list = self._build_files_list()
        if shuffle:
            random.seed(seed)
            random.shuffle(self.files_list)
        if subsample != 1:
            self.files_list = self._subsample_list(self.files_list, sample_rate=subsample)
        logging.info(f"Found {len(self.files_list)} utterances")

    def _build_files_list(self):
        files_list = []
        for file in os.listdir(self.scenes_root):
            if file.endswith("mixed.wav"):
                clean_file = join(self.scenes_root, file.replace("mixed", "target"))
                noise_file = join(self.scenes_root, file.replace("mixed", "interferer"))
                noisy_file = join(self.scenes_root, file)
                mp4_file = join(self.scenes_root.replace("scenes", "lips") if self.lips else self.scenes_root,
                                file.replace("_mixed.wav", "_silent.mp4"))
                if self.test_set or all(isfile(f) for f in [clean_file, noise_file, noisy_file, mp4_file]):
                    files_list.append((clean_file, noise_file, noisy_file, mp4_file))
        return files_list

    def _subsample_list(self, inp_list, sample_rate):
        random.shuffle(inp_list)
        return [inp_list[i] for i in range(int(len(inp_list) * sample_rate))]

    def __len__(self):
        return len(self.files_list)

    def __getitem__(self, idx):
        while True:
            try:
                clean_file, noise_file, noisy_file, mp4_file = self.files_list[idx]
                noisy, clean, frames = self._get_data(clean_file, noise_file, noisy_file, mp4_file)
                scene_name = clean_file.replace(self.scenes_root, "").replace("_target.wav", "").replace("/", "")
                return {"noisy_audio": noisy, "clean": clean, "video_frames": frames, "scene": scene_name}
            except Exception as e:
                logging.error(f"Error loading data: {e}")

    def _load_wav(self, wav_path):
        rate, data = wavfile.read(wav_path)
        data = data.astype(np.float32) / (2 ** 15)
        # Convert stereo to mono if needed
        if len(data.shape) == 2:
            data = data.mean(axis=1)
        # Clip or pad to max_audio_len
        if len(data) < max_audio_len:
            data = np.pad(data, (0, max_audio_len - len(data)))
        else:
            data = data[:max_audio_len]
        return data

    def _get_data(self, clean_file, noise_file, noisy_file, mp4_file):
        # ----------------------
        # Load audio
        # ----------------------
        noisy = self._load_wav(noisy_file)
        clean = self._load_wav(clean_file) if isfile(clean_file) else np.zeros_like(noisy)

        # ----------------------
        # Load video frames
        # ----------------------
        vr = VideoReader(mp4_file, ctx=cpu(0))
        num_frames = min(len(vr), max_frames)
        frames = vr.get_batch(list(range(num_frames))).asnumpy()  # [T, H, W, C]

        if not self.rgb:
            # Convert to grayscale and add channel dimension
            frames = np.array([cv2.cvtColor(f, cv2.COLOR_RGB2GRAY) for f in frames], dtype=np.float32)
            frames = frames[:, np.newaxis, :, :]  # [T, 1, H, W]
        else:
            # RGB: move channels first
            frames = frames.astype(np.float32).transpose(0, 3, 1, 2)  # [T, C, H, W]

        # ----------------------
        # Pad frames if less than max_frames
        # ----------------------
        if len(frames) < max_frames:
            pad_shape = (max_frames - len(frames), *frames.shape[1:])
            frames = np.concatenate([frames, np.zeros(pad_shape, dtype=frames.dtype)], axis=0)

        # ----------------------
        # Normalize to [0,1]
        # ----------------------
        frames /= 255.0

        # ----------------------
        # Fix shape for Conv3D: [T, C, H, W] -> [C, T, H, W]
        # ----------------------
        frames = frames.transpose(1, 0, 2, 3)

        # ----------------------
        # Convert to torch tensors410
        # ----------------------
        return torch.tensor(noisy), torch.tensor(clean), torch.tensor(frames)


class AVSEDataModule(LightningDataModule):
    def __init__(self, batch_size=16, lips=False, rgb=False, num_workers=4):
        super().__init__()
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.lips = lips
        self.rgb = rgb

        self.train_dataset = AVSEDataset(join(DATA_ROOT, "train/scenes"), lips=lips, rgb=rgb)
        self.val_dataset = AVSEDataset(join(DATA_ROOT, "dev/scenes"), lips=lips, rgb=rgb)
        self.test_dataset = AVSEDataset(join(DATA_ROOT, "eval/scenes"), lips=lips, rgb=rgb, test_set=True)

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=True,
            persistent_workers=True
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=True,
            persistent_workers=True
        )

    def test_dataloader(self):
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers
        )


if __name__ == '__main__':
    # Quick test to verify dataset shapes
    datamodule = AVSEDataModule(batch_size=2, lips=False, rgb=False, num_workers=0)

    print("\n=== Testing Training Dataset ===")
    train_dataset = datamodule.train_dataset
    for i in range(min(3, len(train_dataset))):
        data = train_dataset[i]
        print(f"\nSample {i}:")
        for k, v in data.items():
            if isinstance(v, (np.ndarray, torch.Tensor)):
                print(f"{k:>15}: shape={v.shape}, range=[{v.min():.4f}, {v.max():.4f}]")
            else:
                print(f"{k:>15}: {v}")

    print("\n=== Testing Validation Dataset ===")
    val_dataset = datamodule.val_dataset
    for i in range(min(3, len(val_dataset))):
        data = val_dataset[i]
        print(f"\nSample {i}:")
        for k, v in data.items():
            if isinstance(v, (np.ndarray, torch.Tensor)):
                print(f"{k:>15}: shape={v.shape}, range=[{v.min():.4f}, {v.max():.4f}]")
            else:
                print(f"{k:>15}: {v}")

    # Optional: test DataLoader
    print("\n=== Testing DataLoader ===")
    train_loader = datamodule.train_dataloader()
    batch = next(iter(train_loader))
    for k, v in batch.items():
        if isinstance(v, torch.Tensor):
            print(f"{k:>15}: shape={v.shape}, dtype={v.dtype}")
