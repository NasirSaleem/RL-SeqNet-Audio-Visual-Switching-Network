from __future__ import annotations

import argparse
import csv

import numpy as np
import torch

from rl_msnet.experts.adapters import load_avse_checkpoint


def pooled_visual_embedding(model, video_path, device):
    frames = np.load(video_path, allow_pickle=False).astype(np.float32)
    if frames.ndim != 4 or frames.shape[0] != 1:
        raise ValueError(f"Expected grayscale frames [1,T,H,W], got {frames.shape}")
    x = torch.as_tensor(frames[None], dtype=torch.float32, device=device)
    with torch.inference_mode():
        embedding = model.model.visual_encoder(x)
    return embedding.mean(dim=1)[0].detach().cpu().numpy()


def main():
    p = argparse.ArgumentParser(description="Create task-conditioned confidence-estimator arrays")
    p.add_argument("--manifest", required=True)
    p.add_argument("--candidate-csv", required=True)
    p.add_argument("--avse-checkpoint", required=True)
    p.add_argument("--avse-source", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--sisdr-scale-db", type=float, required=True)
    p.add_argument("--stoi-scale", type=float, required=True)
    p.add_argument("--stoi-weight", type=float, default=1.0)
    p.add_argument("--temperature", type=float, required=True)
    p.add_argument("--device", default="cuda")
    args = p.parse_args()
    if min(args.sisdr_scale_db, args.stoi_scale, args.temperature) <= 0:
        p.error("Metric scales and temperature must be positive")
    device = torch.device(args.device if args.device != "auto" else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    avse = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, str(device))
    with open(args.manifest, newline="", encoding="utf-8") as f:
        manifest = list(csv.DictReader(f))
    with open(args.candidate_csv, newline="", encoding="utf-8") as f:
        candidates = {(r["episode_id"], r["step"]): r for r in csv.DictReader(f)}
    features, targets = [], []
    for row in manifest:
        key = (row["episode_id"], row["step"])
        if key not in candidates:
            raise ValueError(f"No candidate metrics for {key}")
        metric = candidates[key]
        emb = pooled_visual_embedding(avse, row["video_npy"], device)
        audio_context = np.asarray([float(row["snr_est_db"]), float(row["snr_delta_db"])], dtype=np.float32)
        feat = np.concatenate((emb.astype(np.float32), audio_context))
        qa = (float(metric["sisdr_gain_aose"]) / args.sisdr_scale_db
              + args.stoi_weight * float(metric["stoi_gain_aose"]) / args.stoi_scale)
        qv = (float(metric["sisdr_gain_avse"]) / args.sisdr_scale_db
              + args.stoi_weight * float(metric["stoi_gain_avse"]) / args.stoi_scale)
        z = np.clip((qv - qa) / args.temperature, -30.0, 30.0)
        features.append(feat)
        targets.append(1.0 / (1.0 + np.exp(-z)))
    np.savez_compressed(args.out, features=np.asarray(features, dtype=np.float32),
                        target=np.asarray(targets, dtype=np.float32))
    print(f"Wrote confidence training arrays: {args.out}; rows={len(features)}")


if __name__ == "__main__":
    main()
