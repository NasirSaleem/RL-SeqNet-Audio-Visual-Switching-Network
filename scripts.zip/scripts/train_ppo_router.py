"""On-policy PPO pilot on cached, short, fixed-corruption decision episodes.

Reward = cached utility improvement over NSE - switch_cost * action_change.
First decisions have no switching penalty. No compute saving is claimed.
External validation is evaluated only after the fixed training budget.
"""
from __future__ import annotations
import argparse,csv,json,random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
ACTIONS=('aose','avse','nse')


def load(path):
    with np.load(path,allow_pickle=False) as z:d={k:z[k].copy() for k in z.files}
    n=len(d['observations']); offsets=d['offsets']
    if d['observations'].shape!=(n,3) or d['action_rewards'].shape!=(n,3):raise ValueError('Invalid array shapes')
    if not np.isfinite(d['observations']).all() or not np.isfinite(d['action_rewards']).all():raise ValueError('Nonfinite episode arrays')
    if offsets[0]!=0 or offsets[-1]!=n or not np.all(np.diff(offsets)>0):raise ValueError('Invalid run offsets')
    if not np.array_equal(np.diff(offsets),d['lengths']):raise ValueError('Run lengths differ')
    if d['action_order'].tolist()!=list(ACTIONS):raise ValueError('Wrong action order')
    if not np.allclose(d['action_rewards'][:,2],0):raise ValueError('Expected rewards relative to NSE')
    if not np.allclose(d['action_rewards'],d['utilities']-d['utilities'][:,2:3],atol=1e-5):raise ValueError('Utility/reward mismatch')
    for start,end in zip(offsets[:-1],offsets[1:]):
        if len(set(d['episode_ids'][start:end]))!=1 or len(set(d['conditions'][start:end]))!=1:raise ValueError('Mixed source run')
        if not np.all(np.diff(d['steps'][start:end])==1):raise ValueError('Gap inside run')
    return d


class ActorCritic(nn.Module):
    def __init__(self):
        super().__init__()
        self.trunk=nn.Sequential(nn.Linear(6,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh())
        self.actor=nn.Linear(64,3);self.critic=nn.Linear(64,1)
    def forward(self,x):
        h=self.trunk(x);return self.actor(h),self.critic(h).squeeze(-1)


def gae(rewards,values,lengths,gamma,lam):
    """Complete episodes only; padded positions are ignored, terminals bootstrap zero."""
    advantage=np.zeros_like(rewards); running=np.zeros(len(lengths),dtype=np.float32)
    for t in reversed(range(rewards.shape[1])):
        active=t<lengths; continuing=(t+1)<lengths
        following=values[:,t+1] if t+1<values.shape[1] else np.zeros(len(lengths))
        delta=rewards[:,t]+gamma*following*continuing-values[:,t]
        running=np.where(active,delta+gamma*lam*running*continuing,0)
        advantage[:,t]=running
    return advantage,advantage+values


def rollout(model,d,normal,args,rng):
    chosen=rng.integers(0,len(d['lengths']),size=args.episodes_per_update)
    lengths=d['lengths'][chosen];starts=d['offsets'][chosen];b=len(chosen);h=int(lengths.max())
    states=np.zeros((b,h,6),dtype=np.float32);actions=np.zeros((b,h),dtype=np.int64)
    logprobs=np.zeros((b,h),dtype=np.float32);values=np.zeros((b,h),dtype=np.float32);rewards=np.zeros((b,h),dtype=np.float32)
    prev=np.full(b,-1,dtype=np.int64); model.eval()
    for t in range(h):
        active=np.flatnonzero(t<lengths);idx=starts[active]+t
        state=np.zeros((len(active),6),dtype=np.float32);state[:,:3]=normal[idx]
        known=prev[active]>=0;state[np.flatnonzero(known),3+prev[active][known]]=1
        with torch.no_grad():
            logits,v=model(torch.as_tensor(state,device=args.device));dist=Categorical(logits=logits);a=dist.sample();lp=dist.log_prob(a)
        an=a.cpu().numpy();sw=(prev[active]>=0)&(an!=prev[active])
        states[active,t]=state;actions[active,t]=an;logprobs[active,t]=lp.cpu().numpy();values[active,t]=v.cpu().numpy()
        rewards[active,t]=d['action_rewards'][idx,an]-args.switch_cost*sw
        prev[active]=an
    advantages,returns=gae(rewards,values,lengths,args.gamma,args.gae_lambda)
    mask=np.arange(h)[None,:]<lengths[:,None]
    adv=advantages[mask];adv=(adv-adv.mean())/(adv.std()+1e-8)
    tensors=[torch.as_tensor(x,device=args.device) for x in [states[mask],actions[mask],logprobs[mask],adv.astype(np.float32),returns[mask].astype(np.float32)]]
    return tensors,float(rewards[mask].mean())


def select(model,d,normal,device):
    actions=np.zeros(len(normal),dtype=np.int64);model.eval()
    starts=d['offsets'][:-1];lengths=d['lengths'];prev=np.full(len(starts),-1)
    for t in range(int(lengths.max())):
        active=np.flatnonzero(t<lengths);idx=starts[active]+t
        state=np.zeros((len(active),6),dtype=np.float32);state[:,:3]=normal[idx]
        known=prev[active]>=0;state[np.flatnonzero(known),3+prev[active][known]]=1
        with torch.no_grad():logits,_=model(torch.as_tensor(state,device=device))
        a=logits.argmax(dim=1).cpu().numpy();actions[idx]=a;prev[active]=a
    return actions


def oracle_actions(d,cost):
    """Nondeployable DP upper bound for undiscounted net utility in each run."""
    result=np.zeros(len(d['observations']),dtype=np.int64)
    for start,end in zip(d['offsets'][:-1],d['offsets'][1:]):
        q=d['action_rewards'][start:end];v=q[0].copy();back=[]
        for t in range(1,len(q)):
            candidates=v[:,None]-cost*(np.arange(3)[:,None]!=np.arange(3)[None,:])
            previous=candidates.argmax(axis=0);back.append(previous);v=q[t]+candidates[previous,np.arange(3)]
        a=int(v.argmax());result[end-1]=a
        for t in reversed(range(len(back))):a=int(back[t][a]);result[start+t]=a
    return result


def external_actions(path,d):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    index={}
    for row in rows:
        key=(row['episode_id'],int(row['step']),row['condition'])
        if key in index:raise ValueError(f'Duplicate baseline key in {path}')
        index[key]=ACTIONS.index(row['action'])
    keys=list(zip(d['episode_ids'].astype(str),d['steps'].astype(int),d['conditions'].astype(str)))
    if set(index)!=set(keys):raise ValueError(f'Baseline predictions do not match PPO validation: {path}')
    return np.asarray([index[k] for k in keys])


def outcomes(d,actions,cost):
    changed=np.zeros(len(actions),dtype=bool);eligible=np.ones(len(actions),dtype=bool);eligible[d['offsets'][:-1]]=False
    changed[1:]=actions[1:]!=actions[:-1];changed &= eligible
    base=d['action_rewards'][np.arange(len(actions)),actions]
    return base,base-cost*changed,changed,eligible


def report(d,actions,cost,name,seed):
    base,net,changed,eligible=outcomes(d,actions,cost);rows=[]
    for condition in ['all']+sorted(set(d['conditions'].tolist())):
        mask=np.ones(len(actions),dtype=bool) if condition=='all' else d['conditions']==condition
        delta=net-d['action_rewards'][:,1]
        groups=d['episode_ids'][mask];vals=delta[mask]
        clip=np.asarray([vals[groups==g].mean() for g in np.unique(groups)])
        rng=np.random.default_rng(12345);draws=rng.choice(clip,size=(2000,len(clip)),replace=True).mean(axis=1)
        low,high=np.quantile(draws,[.025,.975])
        rows.append(dict(model=name,seed=seed,condition=condition,segments=int(mask.sum()),clips=len(clip),
            mean_utility=float(d['utilities'][np.arange(len(actions)),actions][mask].mean()),
            mean_gain_vs_nse=float(base[mask].mean()),mean_net_gain_vs_nse=float(net[mask].mean()),
            switch_cost=cost,switches=int(changed[mask].sum()),eligible_transitions=int(eligible[mask].sum()),
            switch_rate=float(changed[mask].sum()/max(1,eligible[mask].sum())),
            p_aose=float(np.mean(actions[mask]==0)),p_avse=float(np.mean(actions[mask]==1)),p_nse=float(np.mean(actions[mask]==2)),
            clip_mean_net_delta_vs_avse=float(clip.mean()),ci_low=float(low),ci_high=float(high)))
    return rows


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',required=True);p.add_argument('--validation',required=True);p.add_argument('--out-dir',required=True)
    p.add_argument('--supervised-dir',required=True);p.add_argument('--utility-dir',required=True)
    p.add_argument('--seeds',type=int,nargs='+',default=[11,22,33]);p.add_argument('--updates',type=int,default=300)
    p.add_argument('--episodes-per-update',type=int,default=128);p.add_argument('--ppo-epochs',type=int,default=4)
    p.add_argument('--batch-size',type=int,default=256);p.add_argument('--lr',type=float,default=3e-4)
    p.add_argument('--clip',type=float,default=.2);p.add_argument('--entropy-coef',type=float,default=.01)
    p.add_argument('--value-coef',type=float,default=.5);p.add_argument('--switch-cost',type=float,default=.05)
    p.add_argument('--gamma',type=float,default=1.0);p.add_argument('--gae-lambda',type=float,default=.95)
    p.add_argument('--device',default='cuda');args=p.parse_args()
    if min(args.updates,args.episodes_per_update,args.ppo_epochs,args.batch_size,args.lr,args.clip)<=0: p.error('Invalid training settings')
    if args.gamma!=1.0:p.error('This pilot compares undiscounted net utility; use --gamma 1.0')
    if not 0<=args.gae_lambda<=1 or min(args.switch_cost,args.entropy_coef,args.value_coef)<0:p.error('Invalid coefficients')
    if len(set(args.seeds))!=len(args.seeds):p.error('Duplicate seeds')
    out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()):p.error('Choose an empty output directory')
    train,val=load(args.train),load(args.validation)
    if set(train['episode_ids'])&set(val['episode_ids']):raise ValueError('Train/validation clips overlap')
    for k in ['sisdr_scale_db','stoi_scale','reward_definition','observation_names']:
        if not np.array_equal(train[k],val[k]):raise ValueError(f'Mismatched {k}')
    baseline={}
    for seed in args.seeds:
        for name,folder in [('supervised_mlp',args.supervised_dir),('utility_regression_mlp',args.utility_dir)]:
            baseline[(name,seed)]=external_actions(Path(folder)/f'validation_predictions_seed_{seed}.csv',val)
    if args.device.startswith('cuda') and not torch.cuda.is_available():raise ValueError('CUDA unavailable')
    torch.set_num_threads(2)
    mean=train['observations'].mean(axis=0,dtype=np.float64).astype(np.float32)
    std=train['observations'].std(axis=0,dtype=np.float64).astype(np.float32);std[std<1e-6]=1
    normal=(train['observations']-mean)/std;vnormal=(val['observations']-mean)/std
    out.mkdir(parents=True,exist_ok=True);results=[];history=[]
    for a,name in enumerate(ACTIONS):results.extend(report(val,np.full(len(vnormal),a),args.switch_cost,'always_'+name,-1))
    results.extend(report(val,oracle_actions(val,args.switch_cost),args.switch_cost,'reference_dp_oracle',-1))
    for (name,seed),a in baseline.items():results.extend(report(val,a,args.switch_cost,name,seed))
    for seed in args.seeds:
        random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
        if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
        rng=np.random.default_rng(seed);model=ActorCritic().to(args.device);opt=torch.optim.Adam(model.parameters(),lr=args.lr)
        for update in range(1,args.updates+1):
            (states,actions,old_logp,advantages,returns),rollout_reward=rollout(model,train,normal,args,rng)
            model.train();losses=[];entropies=[]
            for _ in range(args.ppo_epochs):
                order=torch.randperm(len(states),device=args.device)
                for start in range(0,len(states),args.batch_size):
                    idx=order[start:start+args.batch_size];logits,values=model(states[idx]);dist=Categorical(logits=logits)
                    ratio=torch.exp(dist.log_prob(actions[idx])-old_logp[idx])
                    policy=-torch.minimum(ratio*advantages[idx],ratio.clamp(1-args.clip,1+args.clip)*advantages[idx]).mean()
                    value_loss=.5*(values-returns[idx]).pow(2).mean();entropy=dist.entropy().mean()
                    loss=policy+args.value_coef*value_loss-args.entropy_coef*entropy
                    if not torch.isfinite(loss):raise ValueError('Nonfinite PPO loss')
                    opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),.5);opt.step()
                    losses.append(loss.item());entropies.append(entropy.item())
            history.append(dict(seed=seed,update=update,rollout_mean_net_reward=rollout_reward,loss=float(np.mean(losses)),entropy=float(np.mean(entropies))))
            if update==1 or update%25==0:print(f'seed={seed} update={update}/{args.updates} rollout_reward={rollout_reward:.4f} entropy={np.mean(entropies):.3f}',flush=True)
        selected=select(model,val,vnormal,args.device);results.extend(report(val,selected,args.switch_cost,'ppo',seed))
        torch.save(dict(state_dict={k:v.detach().cpu() for k,v in model.state_dict().items()},mean=torch.from_numpy(mean),std=torch.from_numpy(std),
            architecture='6-64-64 shared tanh trunk; actor3 critic1',action_order=list(ACTIONS),switch_cost=args.switch_cost,
            seed=seed,updates=args.updates,sisdr_scale_db=float(train['sisdr_scale_db']),stoi_scale=float(train['stoi_scale'])),out/f'ppo_seed_{seed}.ckpt')
        base,net,changed,_=outcomes(val,selected,args.switch_cost)
        write_csv(out/f'validation_predictions_seed_{seed}.csv',[dict(episode_id=str(val['episode_ids'][i]),step=int(val['steps'][i]),condition=str(val['conditions'][i]),action=ACTIONS[a],utility_gain=float(base[i]),net_reward=float(net[i]),switched=int(changed[i])) for i,a in enumerate(selected)])
        print(f'Completed PPO seed {seed}',flush=True)
    write_csv(out/'validation_summary.csv',results);write_csv(out/'training_log.csv',history)
    (out/'protocol.json').write_text(json.dumps(dict(**vars(args),state='three standardized observations + previous action one-hot; all-zero initial previous action',
        optimizer='Adam',gradient_clip_norm=.5,value_loss='0.5*MSE times value_coef',advantage='GAE, standardized per on-policy rollout',
        rollout='uniformly sampled full runs with replacement; no replay across updates',first_step_switch_penalty=0,
        selection='fixed updates, no validation checkpoint selection; deterministic argmax at evaluation',
        compute_penalty='none; no measured computation savings',
        bootstrap='paired source-clip resampling, all variants grouped; 2000 draws, percentile 95%',
        scope='filtered 1-3-step offline static-corruption pilot, not full-utterance waveform performance',
        limitations=['baselines are rescored with identical switch cost but were trained without it',
                     'confidence and experts held fixed across PPO seeds',
                     'no fitted probability calibration','no speaker-disjointness verification',
                     'switching penalty is a pilot surrogate, not measured boundary distortion']),indent=2),encoding='utf-8')
    for r in results:
        if r['condition']=='all':print(f'{r["model"]} seed={r["seed"]}: net_gain={r["mean_net_gain_vs_nse"]:.4f}, switches={r["switch_rate"]:.3f}, delta_vs_AVSE={r["clip_mean_net_delta_vs_avse"]:.4f}')
    print(f'Wrote {out / "validation_summary.csv"}. PPO training completed; validation pilot only.')


if __name__=='__main__':main()
