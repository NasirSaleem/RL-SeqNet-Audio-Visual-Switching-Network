"""Supervised generator-only domain adaptation of the archived AOSE expert.

Uses unique prepared 3-second clips, not repeated per-decision rows. Saves an
adapter-compatible generator checkpoint; this is not a Lightning Trainer resume.
"""
from __future__ import annotations
import argparse
import csv
import json
import random
from pathlib import Path
import numpy as np
import soundfile as sf
import torch
from torch.nn import functional as F
from torch.utils.data import Dataset, DataLoader
from rl_msnet.experts.adapters import AOSEExpert

SR = 16000


def read_pairs(manifest):
    pairs, seen, episodes = [], {}, set()
    with open(manifest, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not {'episode_id','noisy_wav','clean_wav'}.issubset(reader.fieldnames or []):
            raise ValueError(f'Missing paired-audio columns: {manifest}')
        for row in reader:
            noisy, clean = str(Path(row['noisy_wav']).resolve()), str(Path(row['clean_wav']).resolve())
            if noisy in seen:
                if seen[noisy] != clean: raise ValueError(f'Conflicting targets for {noisy}')
                continue
            seen[noisy] = clean
            episodes.add(row['episode_id'])
            pairs.append((noisy,clean))
    if not pairs: raise ValueError(f'No pairs in {manifest}')
    return pairs, episodes


def read_audio(path):
    x,sr = sf.read(path,dtype='float32',always_2d=False)
    if sr != SR: raise ValueError(f'{path}: expected 16000 Hz, got {sr}')
    if x.ndim==2: x=x.mean(axis=1)
    if x.ndim!=1 or not np.isfinite(x).all(): raise ValueError(f'Invalid audio: {path}')
    return x


class PairedClips(Dataset):
    def __init__(self,pairs,training):
        self.clips=[];self.training=training
        for noisy,clean in pairs:
            x,y=read_audio(noisy),read_audio(clean)
            if x.shape!=y.shape or len(x)!=48000:
                raise ValueError(f'Expected equal 3-second prepared clips: {noisy}, {clean}')
            if np.std(x)<1e-8 or np.std(y)<1e-8:
                raise ValueError(f'Silent/constant full clip; audit before training: {noisy}')
            self.clips.append((x,y))
    def __len__(self): return len(self.clips)
    def __getitem__(self,i):
        x,y=self.clips[i]
        if self.training:
            start=random.randint(0,len(x)-32000)
            x,y=x[start:start+32000],y[start:start+32000]
        scale=float(x.std())+1e-8
        return torch.from_numpy((x/scale).copy()),torch.from_numpy((y/scale).copy())


def reconstruction_loss(model,noisy,clean):
    # Feed only the noisy waveform to the generator at train and validation.
    # The clean reference is used exclusively to construct the loss targets.
    result=model(noisy,noisy)
    target=model.power_compress(model.apply_stft(clean))
    complex_loss=F.mse_loss(result['est_spec'].real,target.real)+F.mse_loss(result['est_spec'].imag,target.imag)
    magnitude_loss=F.mse_loss(result['est_mag'],target.abs())
    return 0.1*complex_loss+0.9*magnitude_loss


@torch.no_grad()
def validate(model,loader,device):
    model.eval();total=0.;count=0
    for x,y in loader:
        loss=reconstruction_loss(model,x.to(device),y.to(device))
        if not torch.isfinite(loss): raise ValueError('Nonfinite validation loss')
        total+=float(loss)*len(x);count+=len(x)
    return total/count


def save_checkpoint(path,model,config,args,epoch,val_loss):
    payload={'state_dict':{'generator.'+k:v.detach().cpu().clone() for k,v in model.state_dict().items()},
             'hyper_parameters':{'config':config},
             'epoch':epoch,'validation_reconstruction_loss':val_loss,
             'adaptation':{'method':'generator_only_supervised_reconstruction',
                           'complex_weight':0.1,'magnitude_weight':0.9,'adversarial_weight':0.0,
                           'train_crop_samples':32000,'validation_samples':48000,
                           'initial_checkpoint':str(Path(args.checkpoint).resolve()),
                           'seed':args.seed,'learning_rate':args.lr,
                           'train_manifest':str(Path(args.train_manifest).resolve()),
                           'validation_manifest':str(Path(args.validation_manifest).resolve())}}
    temporary=path.with_suffix('.tmp');torch.save(payload,temporary);temporary.replace(path)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train-manifest',default='data/rl_msnet_prepared/manifests/train.csv')
    p.add_argument('--validation-manifest',default='data/rl_msnet_prepared/manifests/validation.csv')
    p.add_argument('--checkpoint',default='weights/aose/AOSE.ckpt')
    p.add_argument('--source',default='third_party/aose')
    p.add_argument('--out-dir',default='outputs/aose_finetune')
    p.add_argument('--epochs',type=int,default=30)
    p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--lr',type=float,default=1e-5)
    p.add_argument('--patience',type=int,default=8)
    p.add_argument('--seed',type=int,default=11)
    p.add_argument('--device',default='cuda')
    args=p.parse_args()
    if min(args.epochs,args.batch_size,args.patience)<1 or not np.isfinite(args.lr) or args.lr<=0:
        p.error('Epochs, batch size, patience and learning rate must be positive')
    random.seed(args.seed);np.random.seed(args.seed);torch.manual_seed(args.seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.benchmark=False
    device=torch.device(args.device)
    if device.type=='cuda' and not torch.cuda.is_available():p.error('CUDA unavailable')
    out=Path(args.out_dir);out.mkdir(parents=True,exist_ok=True)
    if (out/'history.csv').exists():p.error('Output already contains a run; choose another --out-dir')
    train_pairs,train_ids=read_pairs(args.train_manifest)
    val_pairs,val_ids=read_pairs(args.validation_manifest)
    train_paths={p for pair in train_pairs for p in pair};val_paths={p for pair in val_pairs for p in pair}
    if train_ids & val_ids or train_paths & val_paths:
        p.error('Training and validation IDs or file paths overlap')
    print(f'Unique training clips: {len(train_pairs)}; validation clips: {len(val_pairs)}',flush=True)
    print('Episode/path separation checked; speaker/source-recording separation must be verified independently.',flush=True)
    train_data=PairedClips(train_pairs,True);val_data=PairedClips(val_pairs,False)
    loader=DataLoader(train_data,batch_size=args.batch_size,shuffle=True,num_workers=0,
                      generator=torch.Generator().manual_seed(args.seed))
    val_loader=DataLoader(val_data,batch_size=1,shuffle=False,num_workers=0)
    expert=AOSEExpert(args.checkpoint,str(device),source_dir=args.source)
    if Path(args.checkpoint).suffix.lower()!='.ckpt':p.error('Fine-tuning requires a .ckpt, not TorchScript')
    model=expert.model;model.requires_grad_(True)
    # Reuse the architecture loaded from the checkpoint, without guessing defaults.
    config={'model_config':{'num_channels':model.encoder.conv_1[0].out_channels*4,
                           'n_blocks':len(model.blocks),'n_fft':model.n_fft,
                           'hop_length':model.hop_length,'compress_factor':model.compress_factor}}
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,betas=(0.8,0.99),weight_decay=0.01)
    (out/'run_config.json').write_text(json.dumps(vars(args),indent=2),encoding='utf-8')
    best=validate(model,val_loader,device);stale=0;best_epoch=0
    save_checkpoint(out/'AOSE_adapted.ckpt',model,config,args,0,best)
    print(f'Baseline epoch=0 validation_loss={best:.6f}',flush=True)
    with (out/'history.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['epoch','train_loss','validation_loss','best_epoch'])
        writer.writerow([0,'',best,0]);f.flush()
        for epoch in range(1,args.epochs+1):
            model.train();total=0.;count=0
            for batch,(x,y) in enumerate(loader,1):
                optimizer.zero_grad(set_to_none=True)
                loss=reconstruction_loss(model,x.to(device),y.to(device))
                if not torch.isfinite(loss):raise ValueError('Nonfinite training loss')
                loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.0,error_if_nonfinite=True)
                optimizer.step();total+=float(loss.detach())*len(x);count+=len(x)
                if batch%25==0:print(f'epoch={epoch} batch={batch}/{len(loader)} train_loss={total/count:.6f}',flush=True)
            value=validate(model,val_loader,device)
            save_checkpoint(out/'AOSE_last.ckpt',model,config,args,epoch,value)
            if value<best:
                best=value;best_epoch=epoch;stale=0
                save_checkpoint(out/'AOSE_adapted.ckpt',model,config,args,epoch,value)
            else:stale+=1
            writer.writerow([epoch,total/count,value,best_epoch]);f.flush()
            print(f'epoch={epoch} train_loss={total/count:.6f} validation_loss={value:.6f} best_epoch={best_epoch}',flush=True)
            if stale>=args.patience:
                print('Early stopping: no validation improvement.');break
    print(f'Selected epoch {best_epoch}: {out / "AOSE_adapted.ckpt"}')
    print('Evaluate PESQ/STOI/SI-SDR against the original checkpoint before adopting this model.')

if __name__=='__main__':main()
