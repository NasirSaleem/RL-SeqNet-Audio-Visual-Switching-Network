from __future__ import annotations

import numpy as np
from scipy.signal import stft


def estimate_snr_db(noisy_audio: np.ndarray, sample_rate: int = 16000,
                    n_fft: int = 512, hop_length: int = 256) -> float:
    """Noisy-only minimum-statistics proxy; not the manuscript's refined SNR model.

    Estimate a per-frequency noise floor with a low temporal quantile, then
    aggregate estimated speech and noise power. Validate against the intended
    noise conditions before using as a policy state feature.
    """
    x = np.asarray(noisy_audio, dtype=np.float32).reshape(-1)
    if x.size < n_fft:
        x = np.pad(x, (0, n_fft - x.size))
    _, _, z = stft(x, fs=sample_rate, nperseg=n_fft,
                   noverlap=n_fft - hop_length, boundary=None, padded=False)
    power = np.abs(z).astype(np.float64) ** 2
    floor = np.quantile(power, 0.10, axis=1)
    noise_power = float(floor.sum())
    speech_power = float(np.maximum(power.mean(axis=1) - floor, 0.0).sum())
    return float(10.0 * np.log10((speech_power + 1e-12) / (noise_power + 1e-12)))
