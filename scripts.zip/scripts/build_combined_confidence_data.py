"""Combine cached static features with newly extracted dynamic features; no enhancement reruns.

Target: AVSE utility exceeds BOTH AOSE and unprocessed audio, without compute cost.
Utility scales are pilot choices. Binary outputs require held-out calibration.
All variants retain source episode IDs for later grouped cross-fitting.
"""
from __future__ import annotations
import argparse
import csv
from pathlib import Path
import numpy as np
import torch
from rl_msnet.experts.adapters import load_avse_checkpoint

CONDITIONS = ('clean_dropout_clean', 'dropout_clean_dropout', 'clean_low_light_clean', 'clean_motion_blur_clean')
ACTIONS = ('aose', 'avse', 'nse')


def read_index(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    result = {}
    for row in rows:
        key = (row['episode_id'], int(row['step']))
        if key in result:
            raise ValueError(f'Duplicate key {key} in {path}')
        result[key] = row
    if not result:
        raise ValueError(f'Empty file: {path}')
    return result


def utility(metric, sisdr_scale, stoi_scale):
    values = []
    for action in ACTIONS:
        for name in ('sisdr', 'stoi'):
            if metric.get(f'{name}_valid_{action}') != '1':
                raise ValueError(f'invalid_{name}_{action}')
        s, t = float(metric[f'sisdr_{action}']), float(metric[f'stoi_{action}'])
        if not np.isfinite([s, t]).all():
            raise ValueError('nonfinite_metric')
        values.append(s / sisdr_scale + t / stoi_scale)
    return values


def merge_arrays(static, features, target, utilities, episodes, steps, conditions):
    if features.shape[1:] != static['features'].shape[1:]:
        raise ValueError('Feature dimension mismatch')
    additions=dict(features=features,target=target,utilities=utilities,episode_ids=episodes,steps=steps,conditions=conditions)
    combined=dict(static)
    for k,v in additions.items():
        combined[k]=np.concatenate([static[k],v],axis=0)
    keys=list(zip(combined['episode_ids'].tolist(),combined['steps'].tolist(),combined['conditions'].tolist()))
    if len(keys)!=len(set(keys)):raise ValueError('Duplicate clip/step/condition; clean must appear only once')
    if not np.isfinite(combined['features']).all() or not np.isfinite(combined['utilities']).all():raise ValueError('Invalid combined arrays')
    return combined


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', required=True, help='Dynamic corruption experiment directory')
    p.add_argument('--static-npz', required=True, help='Existing six-condition feature dataset')
    p.add_argument('--audio-manifest', required=True, help='Updated *_features.csv')
    p.add_argument('--out', required=True)
    p.add_argument('--avse-checkpoint', default='weights/avse/AVSE.ckpt')
    p.add_argument('--avse-source', default='third_party/cross_avse')
    p.add_argument('--sisdr-scale-db', type=float, default=10.0)
    p.add_argument('--stoi-scale', type=float, default=0.1)
    p.add_argument('--device', default='cuda')
    args = p.parse_args()
    if min(args.sisdr_scale_db, args.stoi_scale) <= 0:
        p.error('Scales must be positive')
    out = Path(args.out)
    if out.suffix != '.npz':
        p.error('--out must end in .npz')
    if out.exists():
        p.error('Output exists; choose a new name to preserve it')
    with np.load(args.static_npz, allow_pickle=False) as saved:
        static = {k:saved[k].copy() for k in saved.files}
    for key, expected in [('sisdr_scale_db',args.sisdr_scale_db),('stoi_scale',args.stoi_scale)]:
        if float(static[key]) != expected: raise ValueError('Static utility scale differs: '+key)
    if static['action_order'].tolist() != list(ACTIONS): raise ValueError('Static action order differs')
    if str(static['target_definition']) != 'avse_utility_gt_max_aose_nse_binary_v1': raise ValueError('Static target definition differs')
    if str(static['feature_definition']) != 'full_context_visual_encoder_segment_mean_plus_audio_proxy_v2': raise ValueError('Static features differ')
    expected_conditions = {'clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout'}
    if set(static['conditions'].tolist()) != expected_conditions: raise ValueError('Expected original six-condition static dataset')
    if not np.isfinite(static['features']).all() or not np.isfinite(static['utilities']).all(): raise ValueError('Nonfinite static arrays')
    base = read_index(args.audio_manifest)
    if not set(static['episode_ids'].tolist()) <= {k[0] for k in base}: raise ValueError('Static clips not in audio manifest')
    eligible, skipped = [], []
    for condition in CONDITIONS:
        folder = Path(args.root) / condition
        manifest = read_index(folder / 'manifest.csv')
        metrics = read_index(folder / 'metrics.csv')
        if set(base) != set(manifest) or set(base) != set(metrics):
            raise ValueError(f'{condition}: manifest/metric/audio keys do not match')
        for key, row in manifest.items():
            audio = base[key]
            # Noisy-input proxy validity differs from reference-metric validity.
            reason = ''
            if audio.get('snr_proxy_valid') != '1':
                reason = 'silent_noisy_segment_or_missing_proxy_validity'
            try:
                q = utility(metrics[key], args.sisdr_scale_db, args.stoi_scale)
            except (ValueError, KeyError) as error:
                reason = reason or str(error)
            if reason:
                skipped.append(dict(condition=condition, episode_id=key[0], step=key[1], reason=reason))
                continue
            af = np.asarray([float(audio['snr_est_db']), float(audio['snr_delta_db'])], dtype=np.float32)
            if not np.isfinite(af).all():
                raise ValueError(f'Nonfinite audio features: {key}')
            if not Path(row['video_npy']).is_file():
                raise FileNotFoundError(row['video_npy'])
            for field in ('center_start_sample', 'center_end_sample'):
                if int(row[field]) != int(audio[field]) or int(metrics[key][field]) != int(audio[field]):
                    raise ValueError(f'Segment bounds differ: {condition} {key}')
            eligible.append((condition, key, row, af, q))
    if not eligible:
        raise ValueError('No usable rows')
    print(f'Eligible rows: {len(eligible)}; audited exclusions: {len(skipped)}', flush=True)
    model = load_avse_checkpoint(args.avse_checkpoint, args.avse_source, args.device)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    features, targets, utilities, episodes, steps, conditions = [], [], [], [], [], []
    cached_path, embeddings = None, None
    for number, (condition, key, row, af, q) in enumerate(eligible, 1):
        path = row['video_npy']
        if path != cached_path:
            frames = np.load(path, allow_pickle=False).astype(np.float32)
            if frames.ndim != 4 or frames.shape[:2] != (1, 75):
                raise ValueError(f'Expected [1,75,H,W], got {frames.shape}')
            if not np.isfinite(frames).all() or frames.min() < 0 or frames.max() > 1:
                raise ValueError(f'Invalid video range: {path}')
            with torch.inference_mode():
                encoded = model.model.visual_encoder(torch.as_tensor(frames[None], device=args.device))
            if encoded.ndim != 3 or encoded.shape[0] != 1 or encoded.shape[1] != 75:
                raise ValueError(f'Expected visual encoder [1,75,D], got {tuple(encoded.shape)}')
            embeddings = encoded[0].detach().cpu().numpy()
            cached_path = path
        start, end = int(row['center_start_sample']), int(row['center_end_sample'])
        if not 0 <= start < end <= 48000:
            raise ValueError(f'Invalid bounds: {key}')
        first, last = int(np.floor(start*25/16000)), int(np.ceil(end*25/16000))
        feat = np.concatenate([embeddings[first:last].mean(axis=0), af]).astype(np.float32)
        if not np.isfinite(feat).all():
            raise ValueError(f'Invalid features: {condition} {key}')
        features.append(feat)
        targets.append(float(q[1] > max(q[0], q[2])))
        utilities.append(q)
        episodes.append(key[0]); steps.append(key[1]); conditions.append(condition)
        if number % 250 == 0:
            print(f'Extracted {number}/{len(eligible)} rows', flush=True)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.with_suffix('.skipped.csv').open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['condition', 'episode_id', 'step', 'reason'])
        writer.writeheader(); writer.writerows(skipped)
    combined = merge_arrays(static, np.asarray(features, dtype=np.float32),
        np.asarray(targets, dtype=np.float32), np.asarray(utilities, dtype=np.float32),
        np.asarray(episodes), np.asarray(steps), np.asarray(conditions))
    temporary = out.with_suffix('.npz.partial')
    with temporary.open('wb') as f:
        np.savez_compressed(f, **combined)
    temporary.replace(out)
    print(f'Static rows reused: {len(static["target"])}; dynamic rows added: {len(targets)}; combined rows: {len(combined["target"])}')
    for condition in CONDITIONS:
        indices=[i for i,c in enumerate(conditions) if c==condition]
        rate=float(np.mean([targets[i] for i in indices])) if indices else float('nan')
        print(f'{condition}: rows={len(indices)}, AVSE-benefit fraction={rate:.3f}')
    print(f'Wrote {out}; feature dimension={len(features[0])}')
    print('Preparation only. Use grouped cross-fitting before router training; keep all conditions of a source clip together.')
    print('Exclusions apply to confidence supervision only; do not use these filtered rows as contiguous RL episodes.')


if __name__ == '__main__':
    main()
