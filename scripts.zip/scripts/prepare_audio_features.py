"""Fill decision-local noisy-only SNR proxy features; never read clean audio."""
from __future__ import annotations
import argparse
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import stft


def estimate_proxy(audio):
    """Provisional spectral contrast, not calibrated physical mixture SNR.

    Exclude exactly zero-energy STFT frames (including zero padding).
    A relative numerical floor limits singular ratios; this is not calibration.
    Fully silent segments get a finite placeholder and an explicit validity flag.
    """
    x = np.asarray(audio, dtype=np.float64)
    if len(x) < 512:
        x = np.pad(x, (0, 512-len(x)))
    _, _, z = stft(x, fs=16000, nperseg=512, noverlap=256,
                   boundary=None, padded=False)
    power = np.abs(z)**2
    active = power.sum(axis=0) > 0
    zero_fraction = float(1-active.mean())
    if not active.any():
        return 0.0, 0, zero_fraction
    power = power[:, active]
    floor = np.quantile(power, 0.10, axis=1)
    noise = float(floor.sum())
    speech = float(np.maximum(power.mean(axis=1)-floor, 0).sum())
    epsilon = max(float(power.mean(axis=1).sum())*1e-6, 1e-12)
    return float(10*np.log10((speech+epsilon)/(noise+epsilon))), 1, zero_fraction



def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    with open(args.manifest, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        fields = list(reader.fieldnames or [])
        rows = list(reader)
    required = {'episode_id', 'step', 'noisy_wav', 'center_start_sample', 'center_end_sample'}
    if not required.issubset(fields) or not rows:
        p.error('Manifest is empty or missing columns: ' + str(sorted(required-set(fields))))
    for name in ['snr_est_db','snr_delta_db','snr_method','snr_scope','snr_proxy_valid','zero_stft_frame_fraction']:
        if name not in fields: fields.append(name)
    groups = defaultdict(list)
    seen = set()
    cached_path, cached_audio = None, None
    for row in rows:
        key = row['episode_id'], int(row['step'])
        if key in seen: raise ValueError(f'Duplicate decision: {key}')
        seen.add(key)
        path = Path(row['noisy_wav'])
        if str(path) != cached_path:
            x, sr = sf.read(path, dtype='float32', always_2d=False)
            if sr != 16000: raise ValueError(f'{path}: expected 16000 Hz, got {sr}')
            if x.ndim == 2: x = x.mean(axis=1)
            if x.ndim != 1 or not np.isfinite(x).all(): raise ValueError(f'Invalid audio: {path}')
            cached_path, cached_audio = str(path), x
        start,end = int(row['center_start_sample']),int(row['center_end_sample'])
        if not 0 <= start < end <= len(cached_audio): raise ValueError(f'Invalid crop: {key}')
        value, valid, zero_fraction = estimate_proxy(cached_audio[start:end])
        if not np.isfinite(value): raise ValueError(f'Nonfinite SNR proxy: {key}')
        row.update(snr_est_db=value,snr_method='nonzero_frame_spectral_proxy_v2',snr_scope='decision_segment',
                   snr_proxy_valid=valid, zero_stft_frame_fraction=zero_fraction)
        groups[key[0]].append(row)
    for episode, group in groups.items():
        group.sort(key=lambda r:int(r['step']))
        if [int(r['step']) for r in group] != list(range(len(group))):
            raise ValueError(f'Noncontiguous steps: {episode}')
        previous = None
        for row in group:
            value = row['snr_est_db']
            row['snr_delta_db'] = 0.0 if previous is None else value-previous
            previous = value
    out = Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    temporary = out.with_suffix(out.suffix+'.partial')
    with temporary.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
    temporary.replace(out)
    values=np.asarray([r['snr_est_db'] for r in rows])
    print(f'Wrote {len(rows)} rows: {out}; proxy range {values.min():.3f} to {values.max():.3f} dB')
    print('This is an UNCALIBRATED SNR PROXY, not ground-truth mixture SNR or the refined SNR model.')
    print('Fully silent segments (proxy placeholder=0, validity=0):', sum(int(r['snr_proxy_valid']) == 0 for r in rows))
    print('Visual features remain unchanged. First-step delta=0 is an episode-boundary convention.')

if __name__ == '__main__': main()
