"""Profile the existing RL-SeqNet experts and seed-selected PPO on prepared media.
No training, corrupted-media creation, clean references, or waveform exports.
Place in scripts/. Run from project root with .venv312 Python.
MACs are declared dense module estimates, NOT total-operation FLOPs.
"""
from __future__ import annotations
import argparse,csv,json,hashlib,platform,time,math,random,sys
from pathlib import Path
from collections import defaultdict
import numpy as np
import torch
from torch import nn
from scipy.signal import stft
from rl_msnet.experts.adapters import AOSEExpert,load_avse_checkpoint,run_avse
import soundfile as sf

ACTIONS=('aose','avse','nse')
STATIC=('clean','occlusion','motion_blur','low_light','frame_drop','visual_dropout')
DYNAMIC=('clean_dropout_clean','dropout_clean_dropout','clean_low_light_clean','clean_motion_blur_clean')

class Confidence(nn.Module):
    def __init__(self,d):
        super().__init__();self.network=nn.Sequential(nn.Linear(d,128),nn.ReLU(),nn.Dropout(.2),nn.Linear(128,64),nn.ReLU(),nn.Dropout(.2),nn.Linear(64,1))
    def forward(self,x):return self.network(x).squeeze(-1)
class Policy(nn.Module):
    def __init__(self):
        super().__init__();self.trunk=nn.Sequential(nn.Linear(6,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh());self.actor=nn.Linear(64,3);self.critic=nn.Linear(64,1)
    def forward(self,x):
        h=self.trunk(x);return self.actor(h),self.critic(h).squeeze(-1)

def read(p):
    with Path(p).open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def write(p,rows):
    if not rows:return
    with Path(p).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def acoustic(x):
    q=[]
    for t in range(3):
        _,_,z=stft(np.asarray(x[t*16000:(t+1)*16000],dtype=np.float64),fs=16000,nperseg=512,noverlap=256,boundary=None,padded=False)
        power=np.abs(z)**2;active=power.sum(axis=0)>0
        if not active.any():q.append(0.);continue
        power=power[:,active];floor=np.quantile(power,.10,axis=1);mean=power.mean(axis=1)
        eps=max(float(mean.sum())*1e-6,1e-12)
        q.append(float(10*np.log10((np.maximum(mean-floor,0).sum()+eps)/(floor.sum()+eps))))
    return np.column_stack([q,[0.,q[1]-q[0],q[2]-q[1]]]).astype(np.float32)
def reconstruct(experts,actions):
    y=np.concatenate([experts[a][i*16000:(i+1)*16000] for i,a in enumerate(actions)]).copy()
    for i in (1,2):
        if actions[i]==actions[i-1]:continue
        start=i*16000-80;end=start+160;w=np.linspace(0,1,160,dtype=np.float32)
        y[start:end]=(1-w)*experts[actions[i-1]][start:end]+w*experts[actions[i]][start:end]
    return y

def load_small(path,model,device):
    ck=torch.load(path,map_location='cpu',weights_only=True);model.load_state_dict(ck['state_dict'],strict=True);model.to(device).eval()
    mu=ck['mean'].cpu().numpy();sd=ck['std'].cpu().numpy()
    if not np.isfinite(mu).all() or not np.isfinite(sd).all() or np.any(sd<=0):raise ValueError('Invalid normalization')
    return model,ck,mu,sd

class ModuleMACs:
    """Dense conv/transpose/linear and GRU/LSTM matrix MAC estimates.
    Excludes FFT, activation, normalization, interpolation, reductions, bias,
    elementwise/gating ops, CPU work and functional operators outside modules.
    Transpose counts full kernel contributions including cropped edges.
    """
    def __init__(self,roots):self.roots=roots;self.hooks=[];self.rows=[]
    def __enter__(self):
        seen=set()
        for rootname,root in self.roots:
            for name,m in root.named_modules():
                if id(m) in seen:continue
                seen.add(id(m));label=rootname+'.'+name
                if isinstance(m,(nn.Linear,nn.Conv1d,nn.Conv2d,nn.Conv3d,nn.ConvTranspose1d,nn.ConvTranspose2d,nn.ConvTranspose3d,nn.GRU,nn.LSTM)):
                    self.hooks.append(m.register_forward_hook(self.hook(label)))
        return self
    def hook(self,label):
        def h(m,ins,out):
            x=ins[0];kind=type(m).__name__
            if isinstance(m,nn.Linear):n=out.numel()*m.in_features
            elif isinstance(m,(nn.Conv1d,nn.Conv2d,nn.Conv3d)):n=out.numel()*(m.in_channels//m.groups)*math.prod(m.kernel_size)
            elif isinstance(m,(nn.ConvTranspose1d,nn.ConvTranspose2d,nn.ConvTranspose3d)):n=x.numel()*(m.out_channels//m.groups)*math.prod(m.kernel_size)
            else:
                if not isinstance(x,torch.Tensor):raise ValueError('Packed RNN counting unsupported')
                if getattr(m,'proj_size',0):raise ValueError('Projected LSTM counting unsupported')
                b,t=(x.shape[0],x.shape[1]) if m.batch_first else (x.shape[1],x.shape[0]);dirs=2 if m.bidirectional else 1;gates=3 if isinstance(m,nn.GRU) else 4
                n=0
                for layer in range(m.num_layers):
                    d=m.input_size if layer==0 else dirs*m.hidden_size
                    n+=int(b*t*dirs*gates*m.hidden_size*(d+m.hidden_size))
            self.rows.append(dict(module=label,kind=kind,macs=int(n)))
        return h
    def __exit__(self,*args):
        for h in self.hooks:h.remove()
    def total(self):return sum(r['macs'] for r in self.rows)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--device',default='cuda');p.add_argument('--seed',type=int,default=11)
    p.add_argument('--static-root',default='outputs/visual_corruption_heldout');p.add_argument('--dynamic-root',default='outputs/dynamic_visual_heldout')
    p.add_argument('--aose',default='outputs/aose_finetune/AOSE_adapted.ckpt');p.add_argument('--aose-source',default='third_party/aose')
    p.add_argument('--avse',default='weights/avse/AVSE.ckpt');p.add_argument('--avse-source',default='third_party/cross_avse')
    p.add_argument('--confidence',default='outputs/confidence_training_combined/visual_confidence.ckpt')
    p.add_argument('--ppo-dir',default='outputs/ppo_router_combined');p.add_argument('--predictions-dir',default='outputs/heldout_predictions/ppo')
    p.add_argument('--out-dir',default='outputs/computational_profile');p.add_argument('--clips-per-condition',type=int,default=10,help='0 means all sources; otherwise first sorted IDs, same IDs in each condition')
    p.add_argument('--repeats',type=int,default=3);p.add_argument('--warmup',type=int,default=3);p.add_argument('--threads',type=int,default=2)
    args=p.parse_args();out=Path(args.out_dir)
    if min(args.repeats,args.warmup,args.threads)<1 or args.clips_per_condition<0:p.error('Invalid profile settings')
    if out.exists() and any(out.iterdir()):p.error('Use an empty output directory; earlier profiles are preserved')
    device=torch.device(args.device)
    if device.type=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA is unavailable in this environment')
    torch.set_num_threads(args.threads);torch.manual_seed(12345);np.random.seed(12345)
    if device.type=='cuda':torch.cuda.set_device(device)
    out.mkdir(parents=True,exist_ok=True)
    def sync():
        if device.type=='cuda':torch.cuda.synchronize(device)
    predictions=Path(args.predictions_dir)/f'test_predictions_seed_{args.seed}.csv'
    reference={(r['episode_id'],r['condition'],int(r['step'])):r['action'] for r in read(predictions)}
    jobs=[];ids=None
    for condition in STATIC+DYNAMIC:
        folder=Path(args.static_root if condition in STATIC else args.dynamic_root)/condition
        rows=read(folder/'manifest.csv');group=defaultdict(list)
        for r in rows:group[r['episode_id']].append(r)
        if ids is None:ids=sorted(group);ids=ids[:args.clips_per_condition] if args.clips_per_condition else ids
        for eid in ids:
            q=sorted(group[eid],key=lambda r:int(r['step']))
            if [int(r['step']) for r in q]!=[0,1,2] or len({r['video_npy'] for r in q})!=1:raise ValueError('Incomplete/misaligned context')
            jobs.append((condition,eid,q[0]))
    cmmeta=torch.load(args.confidence,map_location='cpu',weights_only=True)
    if cmmeta['input_dim']!=130 or cmmeta['feature_definition']!='full_context_visual_encoder_segment_mean_plus_audio_proxy_v2':raise ValueError('Unexpected confidence architecture/features')
    cm,_,cmu,csd=load_small(args.confidence,Confidence(130),device)
    ppath=Path(args.ppo_dir)/f'ppo_seed_{args.seed}.ckpt';policy,pk,pmu,psd=load_small(ppath,Policy(),device)
    if list(pk['action_order'])!=list(ACTIONS):raise ValueError('Wrong policy action order')
    print('Loading trusted expert checkpoints...',flush=True)
    ao=AOSEExpert(args.aose,str(device),source_dir=args.aose_source)
    av=load_avse_checkpoint(args.avse,args.avse_source,str(device))
    encoder=av.model.visual_encoder
    allroots=[('aose',ao.model),('avse',av),('confidence',cm),('ppo',policy)]
    def size(name,mods):
        ps={id(x):x for m in mods for x in m.parameters()};bs={id(x):x for m in mods for x in m.buffers()}
        return dict(component=name,parameters=sum(x.numel() for x in ps.values()),parameter_bytes=sum(x.numel()*x.element_size() for x in ps.values()),buffer_bytes=sum(x.numel()*x.element_size() for x in bs.values()))
    sizes=[size('AOSE_generator',[ao.model]),size('AVSE_total',[av]),size('visual_encoder_SUBSET_of_AVSE',[encoder]),size('confidence',[cm]),size('PPO_actor_critic',[policy]),size('PPO_actor_only_SUBSET',[policy.trunk,policy.actor]),size('unique_resident_total',[m for _,m in allroots])]
    write(out/'parameters.csv',sizes)
    info=dict(arguments=vars(args),python=sys.version,platform=platform.platform(),processor=platform.processor(),torch=torch.__version__,cuda_runtime=torch.version.cuda,
        gpu=torch.cuda.get_device_name(device) if device.type=='cuda' else None,threads=torch.get_num_threads(),dtype='float32',batch=1,
        cudnn_benchmark=torch.backends.cudnn.benchmark,tf32_matmul=torch.backends.cuda.matmul.allow_tf32,tf32_cudnn=torch.backends.cudnn.allow_tf32,
        checkpoints={str(f):sha(f) for f in [args.aose,args.avse,args.confidence,ppath]},
        source_hashes={str(f):sha(f) for f in [Path(__file__),Path(args.avse_source)/'model.py']},
        timing='synchronized wall time; prepared CPU arrays resident before each run; includes model transfers, proxy, normalization, CPU output and stitching; excludes media decoding/loading, checkpoint loading and cold start',
        memory='CUDA allocator peak, with all models resident for every scenario; not isolated per-model deployment footprint; reserved memory is allocator-cache dependent',
        conditional='Run full-context AOSE/AVSE at most once each only if selected by any interval. Visual encoder always runs for confidence and runs again inside AVSE if selected; no encoder reuse optimization.',
        mac_scope=ModuleMACs.__doc__,seeds_scope='one selected frozen PPO seed; this is not model training or 3-seed average',
        context_seconds=3,causal_streaming=False,reference_predictions=str(predictions))
    (out/'protocol.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
    samples=[];checks=[];components=[];macrows=[];rng=random.Random(4143)
    @torch.inference_mode()
    def visual(v):return encoder(torch.as_tensor(v[None],device=device))[0].cpu().numpy()
    @torch.inference_mode()
    def benefit(a,h):
        f=np.asarray([np.concatenate([h[t*25:(t+1)*25].mean(0),a[t]]) for t in range(3)],dtype=np.float32)
        c=torch.sigmoid(cm(torch.as_tensor((f-cmu)/csd,device=device))).cpu().numpy()
        return np.column_stack([a,c]).astype(np.float32)
    @torch.inference_mode()
    def decide(obs):
        norm=((obs-pmu)/psd).astype(np.float32);prev=-1;result=[]
        for t in range(3):
            s=np.zeros((1,6),dtype=np.float32);s[0,:3]=norm[t]
            if prev>=0:s[0,3+prev]=1
            logits,_=policy(torch.as_tensor(s,device=device));prev=int(logits.argmax(1).item());result.append(ACTIONS[prev])
        return result
    def route(x,v):return decide(benefit(acoustic(x),visual(v)))
    def pipeline(x,v,full):
        a=route(x,v);experts={'nse':x}
        if full or 'aose' in a:experts['aose']=ao(x)
        if full or 'avse' in a:experts['avse']=run_avse(av,x,v)
        return reconstruct(experts,a),a
    def measured(fn):
        sync()
        if device.type=='cuda':
            torch.cuda.reset_peak_memory_stats(device);base=torch.cuda.memory_allocated(device)
        else:base=0
        start=time.perf_counter();result=fn();sync();elapsed=(time.perf_counter()-start)*1000
        peak=torch.cuda.max_memory_allocated(device) if device.type=='cuda' else None
        mem=dict(peak_allocated_mib=peak/2**20 if peak is not None else '',peak_increment_mib=(peak-base)/2**20 if peak is not None else '',peak_reserved_mib=torch.cuda.max_memory_reserved(device)/2**20 if peak is not None else '')
        return result,elapsed,mem
    def record_component(name,fn):
        for _ in range(args.warmup):fn()
        for rep in range(max(10,args.repeats)):
            _,ms,mem=measured(fn);components.append(dict(component=name,repeat=rep,latency_ms=ms,**mem))
    with torch.inference_mode():
        for j,(condition,eid,row) in enumerate(jobs):
            x,sr=sf.read(row['noisy_wav'],dtype='float32',always_2d=False)
            if x.ndim==2:x=x.mean(1)
            v=np.load(row['video_npy'],allow_pickle=False).astype(np.float32)
            if sr!=16000 or x.shape!=(48000,) or v.shape!=(1,75,224,224):raise ValueError('Unexpected prepared input shape')
            if not np.isfinite(x).all() or not np.isfinite(v).all():raise ValueError('Nonfinite input')
            callbacks={'always_nse':lambda:x.copy(),'always_aose':lambda:ao(x),'always_avse':lambda:run_avse(av,x,v),
                'feature_and_router_only':lambda:route(x,v),'routed_lazy_fullcontext':lambda:pipeline(x,v,False),'all_candidates_plus_router':lambda:pipeline(x,v,True)}
            if j==0:
                print('Warming up and measuring components...',flush=True)
                a=acoustic(x);h=visual(v);obs=benefit(a,h)
                component_fns={'audio_proxy_three_intervals':lambda:acoustic(x),'visual_encoder_CPU_to_CPU':lambda:visual(v),
                    'confidence_three_intervals':lambda:benefit(a,h),'PPO_three_decisions_including_critic':lambda:decide(obs),'AOSE_adapter':callbacks['always_aose'],'AVSE_adapter':callbacks['always_avse']}
                for name,fn in component_fns.items():record_component(name,fn)
                write(out/'component_samples.csv',components)
                for name,fn in component_fns.items():
                    with ModuleMACs(allroots) as count:fn()
                    by=defaultdict(int)
                    for r in count.rows:by[(r['module'],r['kind'])]+=r['macs']
                    for (mod,kind),n in by.items():macrows.append(dict(component=name,module=mod,kind=kind,dense_module_macs=n))
                write(out/'module_macs.csv',macrows)
                for fn in callbacks.values():
                    for _ in range(args.warmup):fn()
            full,actions=pipeline(x,v,True);lazy,la=pipeline(x,v,False)
            expected=[reference[eid,condition,t] for t in range(3)]
            gap=float(np.max(np.abs(full-lazy)));ok=actions==expected and actions==la and np.allclose(full,lazy,atol=1e-6,rtol=1e-5)
            checks.append(dict(condition=condition,episode_id=eid,actions='|'.join(actions),reference_actions='|'.join(expected),matches_reference=int(actions==expected),conditional_matches_full=int(np.allclose(full,lazy,atol=1e-6,rtol=1e-5)),max_waveform_difference=gap,aose_invoked=int('aose' in actions),avse_invoked=int('avse' in actions)))
            write(out/'routing_checks.csv',checks)
            if not ok:raise RuntimeError('Runtime outputs do not match recorded evaluation. See routing_checks.csv; do not publish timing as equivalent.')
            for rep in range(args.repeats):
                order=list(callbacks);rng.shuffle(order)
                for mode in order:
                    _,ms,mem=measured(callbacks[mode]);samples.append(dict(condition=condition,episode_id=eid,repeat=rep,mode=mode,latency_ms=ms,rtf_prepared=ms/3000,**mem))
            if (j+1)%5==0 or j+1==len(jobs):
                write(out/'timing_samples.csv',samples);print(f'Profiled {j+1}/{len(jobs)} contexts',flush=True)
    summary=[]
    for scope in ['all']+list(STATIC+DYNAMIC):
        for mode in sorted({r['mode'] for r in samples}):
            q=[r for r in samples if r['mode']==mode and (scope=='all' or r['condition']==scope)];v=np.array([r['latency_ms'] for r in q]);ids={(r['condition'],r['episode_id']) for r in q}
            entry=dict(condition=scope,mode=mode,contexts=len(ids),timing_repetitions=len(q),mean_ms=float(v.mean()),median_ms=float(np.median(v)),p95_ms=float(np.percentile(v,95)),mean_rtf_prepared=float(v.mean()/3000),throughput_contexts_per_second=float(1000/v.mean()),peak_allocated_mib=max(r['peak_allocated_mib'] for r in q),peak_increment_mib=max(r['peak_increment_mib'] for r in q))
            summary.append(entry)
    write(out/'runtime_summary.csv',summary)
    comp=[]
    for name in sorted({r['component'] for r in components}):
        v=np.array([r['latency_ms'] for r in components if r['component']==name]);mac=sum(r['dense_module_macs'] for r in macrows if r['component']==name)
        comp.append(dict(component=name,mean_ms=float(v.mean()),median_ms=float(np.median(v)),p95_ms=float(np.percentile(v,95)),dense_module_MACs_per_context=mac,MAC_equivalent_FLOPs_2x=2*mac))
    write(out/'component_summary.csv',comp)
    contrasts=[]
    for base in ['always_avse','all_candidates_plus_router']:
        idx={(r['condition'],r['episode_id'],r['repeat']):r['latency_ms'] for r in samples if r['mode']==base}
        q=[r for r in samples if r['mode']=='routed_lazy_fullcontext'];bt=np.array([idx[r['condition'],r['episode_id'],r['repeat']] for r in q]);rt=np.array([r['latency_ms'] for r in q])
        contrasts.append(dict(reference=base,reference_mean_ms=float(bt.mean()),routed_mean_ms=float(rt.mean()),speedup=float(bt.mean()/rt.mean()),time_reduction_percent=float(100*(1-rt.mean()/bt.mean()))))
    write(out/'measured_comparisons.csv',contrasts)
    call_rates={k:sum(r[k] for r in checks)/len(checks) for k in ['aose_invoked','avse_invoked']}
    # Context-level operation budget: invocation frequency, not segment fractions.
    costs={r['component']:r['dense_module_MACs_per_context'] for r in comp}
    frontend=costs['visual_encoder_CPU_to_CPU']+costs['confidence_three_intervals']+costs['PPO_three_decisions_including_critic']
    budget=[dict(mode='always_aose',mean_dense_module_MACs=costs['AOSE_adapter']),
        dict(mode='always_avse',mean_dense_module_MACs=costs['AVSE_adapter']),
        dict(mode='feature_and_router_only',mean_dense_module_MACs=frontend),
        dict(mode='routed_lazy_fullcontext',mean_dense_module_MACs=frontend+call_rates['aose_invoked']*costs['AOSE_adapter']+call_rates['avse_invoked']*costs['AVSE_adapter']),
        dict(mode='all_candidates_plus_router',mean_dense_module_MACs=frontend+costs['AOSE_adapter']+costs['AVSE_adapter'])]
    for r in budget:
        r['MAC_equivalent_FLOPs_2x']=2*r['mean_dense_module_MACs'];r['GMACs_per_prepared_second']=r['mean_dense_module_MACs']/3e9
    write(out/'complexity_summary.csv',budget)
    (out/'operation_coverage.json').write_text(json.dumps(dict(counted='Conv1d/2d/3d, ConvTranspose1d/2d/3d, Linear and GRU/LSTM dense matrix MACs',
        excluded='STFT/ISTFT, bias, normalization, nonlinearities, gate products, interpolation, pooling, reductions, elementwise ops, CPU signal processing, functional ops outside counted modules',
        transposed_convolution='dense full-kernel convention includes contributions cropped at boundaries',
        not_total_flops=True,not_hardware_instruction_count=True,context_counts_assume_fixed_shapes=True),indent=2))
    def tex_table(title,headers,body):
        esc=lambda x:str(x).replace('_',r'\_').replace('%',r'\%')
        return '\n'.join([r'\begin{table*}[t]',r'\centering\small',r'\caption{'+title+'}',r'\begin{tabular}{'+'l'*len(headers)+'}',r'\toprule',
            ' & '.join(esc(x) for x in headers)+r' \\',r'\midrule']+[' & '.join(esc(x) for x in row)+r' \\' for row in body]+[r'\bottomrule',r'\end{tabular}',r'\end{table*}',''])
    tab=tex_table('Parameter counts and FP32 parameter storage. Subset rows must not be added again to their parent model.',
        ['Component','Parameters','Parameter MiB'],[[r['component'],r['parameters'],f"{r['parameter_bytes']/2**20:.3f}"] for r in sizes])
    tab+=tex_table('Measured warm runtime, batch size one, prepared inputs in CPU memory. RTF uses three-second context duration. All models remain resident; memory is process CUDA allocation, not standalone baseline deployment memory.',
        ['Mode','Mean ms','Median ms','P95 ms','RTF','Peak CUDA MiB'],
        [[r['mode'],f"{r['mean_ms']:.3f}",f"{r['median_ms']:.3f}",f"{r['p95_ms']:.3f}",f"{r['mean_rtf_prepared']:.4f}",r['peak_allocated_mib']] for r in summary if r['condition']=='all'])
    tab+=tex_table('Dense module MAC estimates per three-second context. Excludes Fourier transforms, normalization, activations, interpolation and other operations documented in operation coverage; this is not total FLOPs.',
        ['Mode','GMAC/context','MAC-equivalent GFLOP/context'],[[r['mode'],f"{r['mean_dense_module_MACs']/1e9:.5f}",f"{r['MAC_equivalent_FLOPs_2x']/1e9:.5f}"] for r in budget])
    (out/'profile_tables.tex').write_text(tab,encoding='utf-8')
    (out/'completion.json').write_text(json.dumps(dict(status='complete',contexts=len(jobs),unique_sources=len(set(r['episode_id'] for r in checks)),call_rates_per_context=call_rates,reference_actions_match=True,notes='RTF divides by prepared 3-second duration; not causal latency or padding-trimmed throughput. Component timings are first-context diagnostics; pipeline timings span selected contexts. Dense module MACs exclude documented operators.'),indent=2))
    print(f'Completed: {out}. Upload runtime_summary.csv, component_summary.csv, parameters.csv, measured_comparisons.csv, routing_checks.csv, protocol.json and completion.json.',flush=True)
if __name__=='__main__':main()
